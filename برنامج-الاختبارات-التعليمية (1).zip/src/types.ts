export interface StudentMessage {
  id: string;
  text: string;
  type: 'warning' | 'congratulations' | 'info' | 'alert';
  created_at: string;
}

export interface Student {
  id: string;
  display_name: string;
  created_at: string;
  banned_until?: string | null;
  banned_reason?: string | null;
  messages?: StudentMessage[];
  warning_attempts?: number;
  password?: string;
  session_token?: string;
  entry_code?: string;
  expires_at?: string;
  max_devices?: number;
  registered_devices?: string[];
  last_active_at?: string;
}

export interface Section {
  id: string;
  slug: string;
  title: string;
  icon: string;
  color: string;
  sort: number;
  is_custom: boolean;
}

export interface QuestionOption {
  key: string;
  text: string;
}

export interface QuestionParsed {
  questionText: string;
  options: QuestionOption[];
  correctAnswer: string;
  image_url?: string;
  video_url?: string;
}

export interface Question {
  id: string;
  section_id: string;
  raw_text: string;
  parsed_json: QuestionParsed;
  points_correct: number;
  points_wrong: number;
  sort: number;
}

export interface Progress {
  id: string; // student_id + "_" + section_id
  student_id: string;
  section_id: string;
  xp: number;
  answered: number;
  correct: number;
}

export interface AchievementCondition {
  type: 'total_xp' | 'answered_count' | 'correct_count' | 'section_xp';
  value: number;
  section_id?: string;
}

export interface Achievement {
  id: string;
  title: string;
  condition_json: AchievementCondition;
  xp_reward: number;
  icon: string;
  is_daily: boolean;
}

export interface StudentAchievement {
  student_id: string;
  achievement_id: string;
  unlocked_at: string;
}

export interface Ad {
  id: string;
  title: string;
  body: string;
  image_url: string;
  link: string;
  placement: string;
  active: boolean;
}

export interface News {
  id: string;
  title: string;
  body: string;
  published_at: string;
}

export interface UISetting {
  key: string;
  value: string;
}

export interface StudentNote {
  id: string;
  student_id: string;
  section_id: string;
  section_title: string;
  note_text: string;
  created_at: string;
}

export interface PreRegisteredCode {
  id: string;
  student_name: string;
  code: string;
  registered_device_id?: string | null;
  created_at: string;
  is_used?: boolean;
  registered_name?: string;
  registered_student_id?: string;
  activated_at?: string;
  max_devices?: number;
  duration_days?: number;
  duration_months?: number;
  duration_years?: number;
}

export interface CodeShareConflict {
  id: string;
  student_name: string;
  code: string;
  original_device_id: string;
  intruder_device_id: string;
  intruder_name: string;
  created_at: string;
}

export interface DeviceBlock {
  id: string;
  device_id: string;
  blocked_until: string;
  reason: string;
  created_at: string;
}

export interface PaymentReceipt {
  id: string;
  student_name: string;
  card_holder: string;
  card_digits: string;
  amount: number;
  generated_code: string;
  created_at: string;
}

export interface PaymentRequest {
  id: string;
  student_name: string;
  card_holder: string;
  card_digits: string;
  amount: number;
  status: 'pending' | 'approved' | 'rejected';
  generated_code?: string;
  created_at: string;
}

export interface PrivateMessage {
  id: string;
  student_id: string;
  sender: 'student' | 'developer';
  text: string;
  created_at: string;
}

export interface QRCodeEntity {
  id: string;
  section_type?: 1 | 2 | 3;
  type?: 'one_time' | 'multi_use';
  max_devices: number;
  duration_months?: number;
  duration_days?: number;
  is_used: boolean;
  registered_student_id?: string;
  registered_name?: string;
  created_at: string;
}

export interface CommunityGroup {
  id: string;
  name: string;
  creator_id: string;
  creator_name: string;
  is_frozen: boolean;
  allow_images: boolean;
  allow_audio: boolean;
  allow_videos?: boolean;
  created_at: string;
}

export interface CommunityMessage {
  id: string;
  group_id: string; // 'general' or custom group id
  sender_id: string;
  sender_name: string;
  text: string;
  image_url?: string;
  audio_url?: string;
  video_url?: string;
  created_at: string;
}

export interface IntrusionLog {
  id: string;
  student_id?: string;
  student_name: string;
  attempted_gate: 'supervisor_gate' | 'master_gate';
  attempted_password?: string;
  action_taken: 'warning' | 'banned_automatically' | 'kicked';
  banned_duration_minutes?: number;
  created_at: string;
}

export interface DBState {
  students: Student[];
  sections: Section[];
  questions: Question[];
  progress: Progress[];
  achievements: Achievement[];
  student_achievements: StudentAchievement[];
  ads: Ad[];
  news: News[];
  ui_settings: UISetting[];
  student_notes?: StudentNote[];
  pre_registered_codes?: PreRegisteredCode[];
  intrusion_logs?: IntrusionLog[];
  code_share_conflicts?: CodeShareConflict[];
  device_blocks?: DeviceBlock[];
  payment_receipts?: PaymentReceipt[];
  payment_requests?: PaymentRequest[];
  private_messages?: PrivateMessage[];
  qr_codes?: QRCodeEntity[];
  community_groups?: CommunityGroup[];
  community_messages?: CommunityMessage[];
  kicked_students?: Student[];
  deleted_ids?: string[];
}
