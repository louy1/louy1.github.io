import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../context/AppContext';
import { MessageSquare, Send, X, Shield, RefreshCw } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { PrivateMessage } from '../types';

export default function StudentSupportChat() {
  const { student, privateMessages, refreshData } = useApp();
  const [isOpen, setIsOpen] = useState(false);
  const [text, setText] = useState('');
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  const studentId = student?.id;

  // Filter messages for this student from global privateMessages
  const messages = React.useMemo(() => {
    if (!studentId) return [];
    return (privateMessages || []).filter(m => m.student_id === studentId);
  }, [privateMessages, studentId]);

  // Optionally perform manual refresh when clicking reload
  const fetchMessages = async () => {
    setRefreshing(true);
    try {
      await refreshData();
    } catch (err) {
      console.error('Failed to retrieve support chat messages', err);
    } finally {
      setRefreshing(false);
    }
  };

  // Scroll to bottom
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (messages.length > 0) {
      scrollToBottom();
    }
  }, [messages.length, isOpen]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim() || !studentId) return;

    setLoading(true);
    const textToSend = text.trim();
    setText('');

    try {
      const res = await fetch('/api/private-messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          studentId,
          sender: 'student',
          text: textToSend
        })
      });
      if (res.ok) {
        // No manual append needed, SSE handles it automatically.
      }
    } catch (err) {
      console.error('Failed to dispatch private message', err);
    } finally {
      setLoading(false);
    }
  };

  if (!student) return null;

  return (
    <div className="fixed bottom-6 left-6 z-40 font-bold" dir="rtl">
      {/* Floating Toggle Button */}
      <motion.button
        id="student-chat-floating-toggle"
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 px-5 py-3.5 bg-gradient-to-r from-blue-600 to-indigo-650 hover:from-blue-700 hover:to-indigo-750 text-white rounded-full shadow-2xl shadow-indigo-500/25 cursor-pointer relative"
      >
        <MessageSquare className="w-5 h-5 shrink-0" />
        <span className="text-sm font-black">غرفة دعم المطور المغلقة</span>
        
        {/* Simple live pill */}
        <span className="w-2.5 h-2.5 bg-emerald-500 rounded-full animate-ping absolute top-0.5 right-1" />
      </motion.button>

      {/* Slide-Up Chat Drawer Container */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 40, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 40, scale: 0.95 }}
            transition={{ type: 'spring', damping: 20, stiffness: 200 }}
            className="absolute bottom-16 left-0 w-80 sm:w-96 h-[460px] bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl shadow-3xl flex flex-col overflow-hidden my-2"
          >
            {/* Header */}
            <div className="p-4 bg-slate-900 text-white flex items-center justify-between border-b border-slate-850">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center text-white text-xs font-black">
                  <Shield className="w-4.5 h-4.5 text-amber-400" />
                </div>
                <div>
                  <h4 className="text-xs font-black">مطور ومسؤول البوابة</h4>
                  <span className="text-[9px] text-emerald-400 block font-bold">● تواصل خاص ومباشر آمن</span>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => fetchMessages()}
                  disabled={refreshing}
                  className="p-1 hover:bg-slate-800 rounded text-slate-400 hover:text-white"
                  title="تحديث المحادثة"
                >
                  <RefreshCw className={`w-4 h-4 ${refreshing ? 'animate-spin' : ''}`} />
                </button>
                <button
                  type="button"
                  onClick={() => setIsOpen(false)}
                  className="p-1 hover:bg-slate-800 rounded text-slate-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Hint bar */}
            <div className="bg-amber-500/10 p-2 text-center text-[10px] text-amber-700 dark:text-amber-450 border-b border-amber-500/10 leading-relaxed">
              💡 هذه محادثة خاصة وسرية 1-على-1 لا تظهر لبقية الطلاب.
            </div>

            {/* Chat Messages Log */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-slate-50 dark:bg-slate-950">
              {messages.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-2 text-slate-400">
                  <MessageSquare className="w-10 h-10 text-slate-350 dark:text-slate-800" />
                  <p className="text-xs font-bold text-slate-500">مرحباً بك في المحادثة المباشرة!</p>
                  <p className="text-[10px] text-slate-450">اكتب استفسارك أو مشكلتك للمطور بالأسفل وسيرد عليك بإشعار فوري.</p>
                </div>
              ) : (
                messages.map((m) => {
                  const isMe = m.sender === 'student';
                  return (
                    <div 
                      key={m.id} 
                      className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
                    >
                      <div className={`px-3.5 py-2 rounded-2xl max-w-[85%] text-xs shadow-xs font-medium leading-relaxed ${
                        isMe
                          ? 'bg-gradient-to-l from-blue-600 to-indigo-650 text-white rounded-br-none text-right'
                          : 'bg-slate-200 dark:bg-slate-800 text-slate-800 dark:text-slate-200 rounded-bl-none text-right'
                      }`}>
                        {m.text}
                      </div>
                      <span className="text-[9px] text-slate-400 mt-0.5 font-normal px-1">
                        {new Date(m.created_at).toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                  );
                })
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Input Form Footer */}
            <form onSubmit={handleSendMessage} className="p-3 bg-white dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800 flex gap-2">
              <input
                type="text"
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="اكتب رسالتك للمطور هنا..."
                disabled={loading}
                className="flex-1 px-4 py-2 bg-slate-50 dark:bg-slate-950 text-xs text-slate-800 dark:text-slate-100 border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-none focus:ring-1 focus:ring-blue-500"
              />
              <button
                type="submit"
                disabled={loading || !text.trim()}
                className="p-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl disabled:opacity-40 shrink-0 transition cursor-pointer"
              >
                <Send className="w-4 h-4 transform rotate-180" />
              </button>
            </form>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
