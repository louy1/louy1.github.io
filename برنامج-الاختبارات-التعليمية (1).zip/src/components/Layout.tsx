import React from 'react';
import { useApp } from '../context/AppContext';
import { Trophy, Home, BarChart2, Settings, User, Compass, Moon, Sun, ShieldAlert, Crown, Medal, MessageSquare, Users } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import Leaderboard from './Leaderboard';

interface LayoutProps {
  children: React.ReactNode;
  activePage: 'home' | 'subject' | 'progress' | 'chat' | 'settings' | 'developer' | 'community_chat';
  setActivePage: (p: 'home' | 'subject' | 'progress' | 'chat' | 'settings' | 'developer' | 'community_chat') => void;
}

export default function Layout({ children, activePage, setActivePage }: LayoutProps) {
  const { student, setTheme, theme, progress, uiSettings } = useApp();
  const [isLeaderboardOpen, setIsLeaderboardOpen] = React.useState(false);

  const totalXp = progress.reduce((sum, p) => sum + p.xp, 0);
  const appTitle = uiSettings['app_title_ar'] || 'أكاديمية الاختبارات التعليمية';

  const devEmail = uiSettings['dev_email']?.trim() || 'Developer060@gmail.com';
  const isDev = student?.id === 'developer_main' || student?.display_name === devEmail;

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 font-sans flex flex-col transition-colors duration-300" dir="rtl">
      {/* Top Header navbar */}
      <header className="sticky top-0 z-30 bg-white/80 dark:bg-slate-950/60 backdrop-blur-md border-b border-slate-100 dark:border-slate-800/80 shadow-sm transition-colors duration-300">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          
          {/* Logo Title project */}
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => setActivePage('home')}>
            <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-blue-500/20">
              <Compass className="w-5.5 h-5.5" />
            </div>
            <span className="font-bold text-lg text-slate-810 dark:text-white tracking-tight">
              {appTitle}
            </span>
          </div>

          {/* Navigation tabs for desktop */}
          <nav className="hidden md:flex items-center gap-2">
            <button
              id="nav-home"
              onClick={() => setActivePage('home')}
              className={`px-4 py-2 rounded-xl text-sm font-semibold transition-all flex items-center gap-1.5 cursor-pointer border ${
                activePage === 'home' || activePage === 'subject'
                  ? 'bg-blue-50 dark:bg-blue-600/10 text-blue-600 dark:text-blue-400 border-blue-100 dark:border-blue-500/20 font-bold shadow-sm shadow-blue-900/5'
                  : 'text-slate-500 dark:text-slate-400 border-transparent hover:text-slate-900 dark:hover:text-white hover:bg-slate-100/50 dark:hover:bg-slate-900/30'
              }`}
            >
              <Home className="w-4 h-4" />
              <span>الرئيسية</span>
            </button>

            <button
              id="nav-progress"
              onClick={() => setActivePage('progress')}
              className={`px-4 py-2 rounded-xl text-sm font-semibold transition-all flex items-center gap-1.5 cursor-pointer border ${
                activePage === 'progress'
                  ? 'bg-blue-50 dark:bg-blue-600/10 text-blue-600 dark:text-blue-400 border-blue-100 dark:border-blue-500/20 font-bold shadow-sm shadow-blue-900/5'
                  : 'text-slate-500 dark:text-slate-400 border-transparent hover:text-slate-900 dark:hover:text-white hover:bg-slate-100/50 dark:hover:bg-slate-900/30'
              }`}
            >
              <BarChart2 className="w-4 h-4" />
              <span>تقدمي الأكاديمي</span>
            </button>

            {/* If normal Student - show messaging */}
            {!isDev ? (
              <button
                id="nav-chat"
                onClick={() => setActivePage('chat')}
                className={`px-4 py-2 rounded-xl text-sm font-semibold transition-all flex items-center gap-1.5 cursor-pointer border ${
                  activePage === 'chat'
                    ? 'bg-blue-50 dark:bg-blue-600/10 text-blue-600 dark:text-blue-400 border-blue-100 dark:border-blue-500/20 font-bold shadow-sm shadow-blue-900/5'
                    : 'text-slate-500 dark:text-slate-400 border-transparent hover:text-slate-900 dark:hover:text-white hover:bg-slate-100/50 dark:hover:bg-slate-900/30'
                }`}
              >
                <MessageSquare className="w-4 h-4" />
                <span>دعم وبث المطور</span>
              </button>
            ) : null}

            {/* General Chat / Groups - Visible to ALL users and developers */}
            <button
              id="nav-community-chat"
              onClick={() => setActivePage('community_chat')}
              className={`px-4 py-2 rounded-xl text-sm font-semibold transition-all flex items-center gap-1.5 cursor-pointer border ${
                activePage === 'community_chat'
                  ? 'bg-blue-50 dark:bg-blue-600/10 text-blue-600 dark:text-blue-400 border-blue-100 dark:border-blue-500/20 font-bold shadow-sm shadow-blue-900/5'
                  : 'text-slate-500 dark:text-slate-400 border-transparent hover:text-slate-900 dark:hover:text-white hover:bg-slate-100/50 dark:hover:bg-slate-900/30'
              }`}
            >
              <Users className="w-4 h-4 text-amber-500" />
              <span>الدردشة العامة والمجموعات</span>
            </button>

            {/* If developer - show user messages list directly and control panel */}
            {isDev && (
              <>
                <button
                  id="nav-dev-chat"
                  onClick={() => setActivePage('chat')}
                  className={`px-4 py-2 rounded-xl text-sm font-semibold transition-all flex items-center gap-1.5 cursor-pointer border ${
                    activePage === 'chat'
                      ? 'bg-rose-50 dark:bg-rose-600/10 text-rose-600 border-rose-100 dark:border-rose-500/20 font-bold shadow-sm'
                      : 'text-slate-500 dark:text-slate-400 border-transparent hover:text-slate-900 dark:hover:text-white hover:bg-slate-100/50 dark:hover:bg-slate-900/30'
                  }`}
                >
                  <MessageSquare className="w-4 h-4 text-rose-550" />
                  <span>قسم مراسلة المستخدمين</span>
                </button>

                <button
                  id="nav-dev-panel"
                  onClick={() => setActivePage('developer')}
                  className={`px-4 py-2 rounded-xl text-sm font-semibold transition-all flex items-center gap-1.5 cursor-pointer border ${
                    activePage === 'developer'
                      ? 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-200/30 dark:border-amber-500/20 font-bold shadow-sm'
                      : 'text-slate-500 dark:text-slate-400 border-transparent hover:text-slate-900 dark:hover:text-white hover:bg-slate-100/50 dark:hover:bg-slate-900/30'
                  }`}
                >
                  <ShieldAlert className="w-4 h-4 text-amber-500" />
                  <span>لوحة التحكم الشاملة</span>
                </button>
              </>
            )}

            <button
              id="nav-settings"
              onClick={() => setActivePage('settings')}
              className={`px-4 py-2 rounded-xl text-sm font-semibold transition-all flex items-center gap-1.5 cursor-pointer border ${
                activePage === 'settings'
                  ? 'bg-blue-50 dark:bg-blue-600/10 text-blue-600 dark:text-blue-400 border-blue-100 dark:border-blue-500/20 font-bold shadow-sm shadow-blue-900/5'
                  : 'text-slate-500 dark:text-slate-400 border-transparent hover:text-slate-900 dark:hover:text-white hover:bg-slate-100/50 dark:hover:bg-slate-900/30'
              }`}
            >
              <Settings className="w-4 h-4" />
              <span>الإعدادات</span>
            </button>
          </nav>

          {/* User Score XP Badge & Settings */}
          <div className="flex items-center gap-3">
            {/* Leaderboard toggle */}
            <button
              id="header-leaderboard-btn"
              onClick={() => setIsLeaderboardOpen(true)}
              className="p-2 text-amber-500 hover:text-amber-600 dark:text-amber-400 dark:hover:text-amber-350 hover:bg-slate-50 dark:hover:bg-slate-900 rounded-xl transition flex items-center gap-1.5 cursor-pointer"
              title="قائمة المتصدرين"
            >
              <Trophy className="w-5 h-5 text-amber-500" />
              <span className="hidden sm:inline text-xs font-black">المتصدرون</span>
            </button>

            {/* Theme toggle */}
            <button
              onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
              className="p-2 text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-900 rounded-xl transition"
              title={theme === 'dark' ? 'الوضع المضيء' : 'الوضع المظلم'}
            >
              {theme === 'dark' ? <Sun className="w-5 h-5 text-amber-400" /> : <Moon className="w-5 h-5 text-indigo-500" />}
            </button>

            {student && (
              <div className="flex items-center gap-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-100 dark:border-slate-900 pl-4 pr-3 py-1.5 rounded-2xl shadow-sm">
                <div className="w-8 h-8 bg-amber-500 rounded-lg flex items-center justify-center text-white shadow shadow-amber-500/20">
                  <Trophy className="w-4 h-4" />
                </div>
                <div className="text-right">
                  <div className="text-xs font-bold text-slate-800 dark:text-white">{student.display_name}</div>
                  <div className="text-[10px] font-mono font-bold text-amber-500 mt-0.5">{totalXp} XP</div>
                </div>
              </div>
            )}
          </div>

        </div>
      </header>

      {/* Primary content area */}
      <main className="flex-grow max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12 relative">
        <AnimatePresence mode="wait">
          <motion.div
            key={activePage}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.25, ease: 'easeInOut' }}
          >
            {children}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Mobile Sticky Navigation Footer tab bars */}
      <footer className="md:hidden sticky bottom-0 z-30 bg-white/95 dark:bg-slate-950/95 backdrop-blur border-t border-slate-100 dark:border-slate-800/80 shadow-2xl">
        <div className={`grid ${isDev ? 'grid-cols-6' : 'grid-cols-5'} h-16`}>
          <button
            onClick={() => setActivePage('home')}
            className={`flex flex-col items-center justify-center gap-1 cursor-pointer transition ${
              activePage === 'home' || activePage === 'subject' ? 'text-blue-600 dark:text-blue-400 font-semibold' : 'text-slate-400 dark:text-slate-500'
            }`}
          >
            <Home className="w-5 h-5" />
            <span className="text-[10px]">الرئيسية</span>
          </button>

          <button
            onClick={() => setActivePage('progress')}
            className={`flex flex-col items-center justify-center gap-1 cursor-pointer transition ${
              activePage === 'progress' ? 'text-blue-600 dark:text-blue-400 font-semibold' : 'text-slate-400 dark:text-slate-500'
            }`}
          >
            <BarChart2 className="w-5 h-5" />
            <span className="text-[10px]">تقدمي</span>
          </button>

          <button
            onClick={() => setActivePage('chat')}
            className={`flex flex-col items-center justify-center gap-1 cursor-pointer transition ${
              activePage === 'chat' ? 'text-blue-600 dark:text-blue-400 font-semibold' : 'text-slate-400 dark:text-slate-500'
            }`}
          >
            <MessageSquare className="w-5 h-5" />
            <span className="text-[10px]">{isDev ? 'المراسلات' : 'الرسائل'}</span>
          </button>

          <button
            onClick={() => setActivePage('community_chat')}
            className={`flex flex-col items-center justify-center gap-1 cursor-pointer transition ${
              activePage === 'community_chat' ? 'text-blue-600 dark:text-blue-400 font-semibold' : 'text-slate-400 dark:text-slate-500'
            }`}
          >
            <Users className="w-5 h-5 text-amber-500" />
            <span className="text-[10px]">الدردشة</span>
          </button>

          {isDev && (
            <button
              onClick={() => setActivePage('developer')}
              className={`flex flex-col items-center justify-center gap-1 cursor-pointer transition ${
                activePage === 'developer' ? 'text-amber-500 font-semibold' : 'text-slate-400 dark:text-slate-500'
              }`}
            >
              <ShieldAlert className="w-5 h-5 text-amber-500" />
              <span className="text-[10px]">المشرف</span>
            </button>
          )}

          <button
            onClick={() => setActivePage('settings')}
            className={`flex flex-col items-center justify-center gap-1 cursor-pointer transition ${
              activePage === 'settings' ? 'text-blue-600 dark:text-blue-400 font-semibold' : 'text-slate-400 dark:text-slate-500'
            }`}
          >
            <Settings className="w-5 h-5" />
            <span className="text-[10px]">الإعدادات</span>
          </button>
        </div>
      </footer>

      <Leaderboard isOpen={isLeaderboardOpen} onClose={() => setIsLeaderboardOpen(false)} />
    </div>
  );
}
