import { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Achievement } from '../types';
import * as LucideIcons from 'lucide-react';
import { 
  Award, Trophy, Flame, Cpu, Zap, Compass, Heart, Atom, Brain, 
  Crown, Star, Sparkles, Check, Lock, X, Medal, ShieldAlert 
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// Dynamic resolver for icons in Badges
const resolveIcon = (iconName: string) => {
  const iconMap: Record<string, any> = {
    'Award': Award,
    'Trophy': Trophy,
    'Flame': Flame,
    'Cpu': Cpu,
    'Zap': Zap,
    'Compass': Compass,
    'Heart': Heart,
    'Atom': Atom,
    'Brain': Brain,
    'Crown': Crown,
    'Star': Star,
    'Sparkles': Sparkles,
    'Medal': Medal
  };
  return iconMap[iconName] || Award;
};

export default function BadgesPortfolio() {
  const { achievements, studentAchievements, student } = useApp();
  const [activeTab, setActiveTab] = useState<'all' | 'unlocked' | 'locked'>('all');
  const [selectedBadge, setSelectedBadge] = useState<Achievement | null>(null);

  if (!student) return null;

  // Find student's unlocked achievements IDs and date records
  const myUnlockedList = studentAchievements.filter(sa => sa.student_id === student.id);
  const unlockedIds = myUnlockedList.map(sa => sa.achievement_id);

  // Compute stats
  const totalBadgesCount = achievements.length;
  const unlockedCount = achievements.filter(a => unlockedIds.includes(a.id)).length;
  const completionPercent = totalBadgesCount > 0 ? Math.round((unlockedCount / totalBadgesCount) * 100) : 0;

  // Filter badges
  const filteredBadges = achievements.filter(ach => {
    const isUnlocked = unlockedIds.includes(ach.id);
    if (activeTab === 'unlocked') return isUnlocked;
    if (activeTab === 'locked') return !isUnlocked;
    return true; // value 'all'
  });

  const handleSelectBadge = (badge: Achievement) => {
    setSelectedBadge(badge);
  };

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 p-6 rounded-3xl shadow-sm space-y-6 text-right" dir="rtl">
      
      {/* Header and completion gauge */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-100 dark:border-slate-800">
        <div>
          <h4 className="text-base font-black text-slate-800 dark:text-white flex items-center gap-2">
            <Trophy className="w-5.5 h-5.5 text-amber-500 animate-pulse" />
            <span>محفظة الشارات الرقمية وملف الإنجازات</span>
          </h4>
          <p className="text-xs text-slate-400 dark:text-slate-500 mt-1">
            لقد تم تنظيم الأوسمة للتكريم التلقائي وبث نقاط XP الإضافية فورياً بالخادم:
          </p>
        </div>

        {/* Dynamic score circular/progress preview */}
        <div className="flex items-center gap-3 bg-slate-50 dark:bg-slate-950 px-4 py-2.5 rounded-2xl border border-slate-100 dark:border-slate-900/50">
          <div className="relative w-10 h-10 flex items-center justify-center font-bold text-xs text-slate-700 dark:text-slate-350">
            <span className="font-mono">{completionPercent}%</span>
          </div>
          <div className="flex flex-col">
            <span className="text-[11px] font-bold text-slate-600 dark:text-slate-355">شارات مكتملة</span>
            <span className="text-[10px] text-slate-400 font-mono">{unlockedCount} من أصل {totalBadgesCount} شارة</span>
          </div>
        </div>
      </div>

      {/* Progress horizontal line indicator */}
      <div className="space-y-1.5">
        <div className="w-full bg-slate-100 dark:bg-slate-950 rounded-full h-2 overflow-hidden">
          <div 
            className="h-full bg-gradient-to-r from-amber-500 to-yellow-400 rounded-full transition-all duration-500"
            style={{ width: `${completionPercent}%` }}
          />
        </div>
        <div className="flex justify-between text-[10px] text-slate-400 font-semibold px-0.5">
          <span>المستوى الأساسي البسيط</span>
          <span>لقب النخبة المكتمل</span>
        </div>
      </div>

      {/* Filter tab buttons */}
      <div className="flex items-center gap-2 p-1 bg-slate-50 dark:bg-slate-950 rounded-xl w-fit border border-slate-100 dark:border-slate-900/30">
        <button
          onClick={() => setActiveTab('all')}
          className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
            activeTab === 'all'
              ? 'bg-white dark:bg-slate-900 text-amber-500 shadow-sm'
              : 'text-slate-400 hover:text-slate-600'
          }`}
        >
          الكل ({totalBadgesCount})
        </button>
        <button
          onClick={() => setActiveTab('unlocked')}
          className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
            activeTab === 'unlocked'
              ? 'bg-green-500 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-605'
          }`}
        >
          شاراتي المفتوحة ({unlockedCount})
        </button>
        <button
          onClick={() => setActiveTab('locked')}
          className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
            activeTab === 'locked'
              ? 'bg-rose-500/10 text-rose-500 shadow-sm border border-rose-500/10'
              : 'text-slate-400 hover:text-slate-600'
          }`}
        >
          مغلقة ({totalBadgesCount - unlockedCount})
        </button>
      </div>

      {/* Badges shelves list rendering grid layout */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
        {filteredBadges.length === 0 ? (
          <div className="col-span-full py-8 text-center text-xs text-slate-400">
            لا توجد شارات تطابق الفلتر المحدد حالياً.
          </div>
        ) : (
          filteredBadges.map(badge => {
            const isUnlocked = unlockedIds.includes(badge.id);
            const iconComp = resolveIcon(badge.icon);
            const Icon = iconComp;

            return (
              <motion.div
                key={badge.id}
                whileHover={{ scale: 1.02, y: -2 }}
                onClick={() => handleSelectBadge(badge)}
                className={`p-4 rounded-2xl border cursor-pointer transition-all flex flex-col items-center justify-center text-center space-y-3 relative overflow-hidden group select-none ${
                  isUnlocked
                    ? 'bg-gradient-to-b from-amber-500/10 to-yellow-500/5 hover:from-amber-500/15 hover:to-yellow-500/10 border-amber-300 dark:border-amber-900/40 shadow-sm'
                    : 'bg-slate-50/50 dark:bg-slate-900/20 border-slate-150 dark:border-slate-850/60 opacity-60 hover:opacity-80'
                }`}
              >
                {/* Shine spark overlay */}
                {isUnlocked && (
                  <div className="absolute top-1 left-1 animate-pulse">
                    <Sparkles className="w-3 h-3 text-amber-500" />
                  </div>
                )}

                {/* Badge graphical medallion symbol */}
                <div className={`w-14 h-14 rounded-full flex items-center justify-center border-2 shadow-inner transition-transform group-hover:scale-105 duration-300 ${
                  isUnlocked
                    ? 'bg-gradient-to-tr from-amber-500 to-yellow-400 text-white border-yellow-250 shadow-amber-500/20'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-405 border-slate-200 dark:border-slate-705'
                }`}>
                  <Icon className="w-7 h-7" />
                </div>

                {/* Informative labels */}
                <div className="space-y-1">
                  <h5 className={`text-xs font-bold leading-tight ${isUnlocked ? 'text-amber-700 dark:text-yellow-500' : 'text-slate-500 dark:text-slate-400'}`}>
                    {badge.title}
                  </h5>
                  <span className="inline-flex items-center gap-0.5 text-[8.5px] font-bold text-slate-400 font-mono">
                    {badge.condition_json.type === 'total_xp' && `مجموع ${badge.condition_json.value} XP`}
                    {badge.condition_json.type === 'answered_count' && `حل ${badge.condition_json.value} كويز`}
                    {badge.condition_json.type === 'correct_count' && `إجابة ${badge.condition_json.value} صح`}
                    {badge.condition_json.type === 'section_xp' && `معدل ${badge.condition_json.value} مادة`}
                  </span>
                </div>

                {/* Floating lock badge */}
                <div className="absolute -bottom-1 -right-1">
                  {isUnlocked ? (
                    <div className="w-5 h-5 bg-green-500 text-white rounded-full border-2 border-white dark:border-slate-900 flex items-center justify-center transform scale-75">
                      <Check className="w-3 h-3" />
                    </div>
                  ) : (
                    <div className="w-5 h-5 bg-slate-200 dark:bg-slate-700 text-slate-400 rounded-full border-2 border-white dark:border-slate-900 flex items-center justify-center transform scale-75">
                      <Lock className="w-2.5 h-2.5" />
                    </div>
                  )}
                </div>
              </motion.div>
            );
          })
        )}
      </div>

      {/* Prestige Inspector Modal certificate */}
      <AnimatePresence>
        {selectedBadge && (
          <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="w-full max-w-sm bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 rounded-3xl text-center space-y-6 relative shadow-2xl"
            >
              <button 
                onClick={() => setSelectedBadge(null)}
                className="absolute top-4 right-4 p-1 rounded-lg text-slate-400 hover:text-slate-600 transition cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>

              {/* Medallion full spotlight display */}
              <div className="relative inline-block mt-4">
                <div className={`w-24 h-24 rounded-full mx-auto flex items-center justify-center border-4 shadow-xl ${
                  unlockedIds.includes(selectedBadge.id)
                    ? 'bg-gradient-to-tr from-amber-500 via-yellow-400 to-amber-600 text-white border-yellow-300 animate-pulse'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-305 border-slate-200 dark:border-slate-700'
                }`}>
                  {(() => {
                    const Icon = resolveIcon(selectedBadge.icon);
                    return <Icon className="w-12 h-12" />;
                  })()}
                </div>
                {unlockedIds.includes(selectedBadge.id) && (
                  <div className="absolute -top-1 -right-1">
                    <Sparkles className="w-5 h-5 text-yellow-400 animate-bounce" />
                  </div>
                )}
              </div>

              {/* Badges specifications and description label */}
              <div className="space-y-2">
                <span className={`text-[10px] font-bold px-2.5 py-1 rounded-full uppercase ${
                  unlockedIds.includes(selectedBadge.id)
                    ? 'bg-green-500/10 text-green-500'
                    : 'bg-slate-100 dark:bg-slate-950 text-slate-450'
                }`}>
                  {unlockedIds.includes(selectedBadge.id) ? 'إنجاز مكتمل ومسجل بالحقيبة' : 'غير مفتوح بعد - قيد التقدم'}
                </span>
                <h4 className="text-base font-black text-slate-900 dark:text-white mt-1">{selectedBadge.title}</h4>
                <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed max-w-xs mx-auto">
                  {selectedBadge.condition_json.type === 'answered_count' && `يتلقى الطالب هذا الوسام فور إجابة عدد ${selectedBadge.condition_json.value} من الأسئلة في الفصول التعليمية الكلية بالمنصة.`}
                  {selectedBadge.condition_json.type === 'total_xp' && `يتلقى الطالب الشارة بمجرد مراكمة عدد ${selectedBadge.condition_json.value} من نقاط XP الكلية للخبرات الذكية.`}
                  {selectedBadge.condition_json.type === 'correct_count' && `يتلقى الطالب الشارة بمجرد إحراز ${selectedBadge.condition_json.value} إجابات صحيحة متميزة بالأنشطة السريعة.`}
                  {selectedBadge.condition_json.type === 'section_xp' && `يتلقى الطالب الشارة عند الوصول لكفاءة ومستوى خبرة عالية في مادة الرياضيات وبورصة المناهج.`}
                </p>
              </div>

              {/* Status and values points bonuses */}
              <div className="bg-slate-50 dark:bg-slate-950 p-4 rounded-2xl border border-slate-100 dark:border-slate-800/60 leading-relaxed">
                <div className="flex justify-between text-xs text-slate-500 font-semibold mb-2">
                  <span>قيمة البونص المستحق:</span>
                  <span className="text-amber-500 font-extrabold font-mono">+{selectedBadge.xp_reward} XP</span>
                </div>
                {unlockedIds.includes(selectedBadge.id) ? (
                  <div className="flex items-center justify-between text-xs text-green-500 font-bold">
                    <span>حالة الاستحقاق:</span>
                    <span className="flex items-center gap-1">
                      <Check className="w-4 h-4 text-green-500" />
                      <span>تمت الإضافة مسبقاً لحسابك</span>
                    </span>
                  </div>
                ) : (
                  <div className="flex items-center justify-between text-xs text-amber-500 font-bold">
                    <span>حالة استيفاء الشرط:</span>
                    <span className="font-semibold text-[10px] text-slate-405">يتطلب مواصلة حل الكويزات لترسيخ المعرفة</span>
                  </div>
                )}
              </div>

              <button
                onClick={() => setSelectedBadge(null)}
                className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-xs transition cursor-pointer"
              >
                تأكيد وقبول التحدي
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
