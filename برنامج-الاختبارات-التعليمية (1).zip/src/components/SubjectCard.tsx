import { Section, Question, Progress } from '../types';
import * as LucideIcons from 'lucide-react';
import { motion } from 'motion/react';

interface SubjectCardProps {
  key?: string | number;
  section: Section;
  questions: Question[];
  progress: Progress[];
  onSelect: () => void;
}

export const colorMap: Record<string, { bg: string; text: string; border: string; hover: string; accent: string }> = {
  blue: { bg: 'bg-blue-50/50 dark:bg-slate-900/50', text: 'text-blue-600 dark:text-blue-400', border: 'border-blue-100/50 dark:border-slate-800/80', hover: 'hover:border-blue-400 dark:hover:border-blue-500/30', accent: 'bg-blue-600' },
  green: { bg: 'bg-green-50/50 dark:bg-slate-900/50', text: 'text-green-600 dark:text-green-400', border: 'border-green-100/50 dark:border-slate-800/80', hover: 'hover:border-green-400 dark:hover:border-green-500/30', accent: 'bg-green-600' },
  purple: { bg: 'bg-purple-50/50 dark:bg-slate-900/50', text: 'text-purple-600 dark:text-purple-400', border: 'border-purple-100/50 dark:border-slate-800/80', hover: 'hover:border-purple-400 dark:hover:border-purple-500/30', accent: 'bg-purple-600' },
  orange: { bg: 'bg-orange-50/50 dark:bg-slate-900/50', text: 'text-orange-600 dark:text-orange-400', border: 'border-orange-100/50 dark:border-slate-800/80', hover: 'hover:border-orange-400 dark:hover:border-orange-500/30', accent: 'bg-orange-600' },
  rose: { bg: 'bg-rose-50/50 dark:bg-slate-900/50', text: 'text-rose-600 dark:text-rose-400', border: 'border-rose-100/50 dark:border-slate-800/80', hover: 'hover:border-rose-400 dark:hover:border-rose-500/30', accent: 'bg-rose-600' },
  teal: { bg: 'bg-teal-50/50 dark:bg-slate-900/50', text: 'text-teal-600 dark:text-teal-400', border: 'border-teal-100/50 dark:border-slate-800/80', hover: 'hover:border-teal-400 dark:hover:border-teal-500/30', accent: 'bg-teal-600' },
  amber: { bg: 'bg-amber-50/50 dark:bg-slate-900/50', text: 'text-amber-600 dark:text-amber-400', border: 'border-amber-100/50 dark:border-slate-800/80', hover: 'hover:border-amber-400 dark:hover:border-amber-500/30', accent: 'bg-amber-600' },
};

export default function SubjectCard({ section, questions, progress, onSelect }: SubjectCardProps) {
  // Extract Lucide Icon dynamically
  const IconComponent = (LucideIcons as any)[section.icon] || LucideIcons.Compass;

  // Resolve specific progression metadata
  const sectionQuestions = questions.filter(q => q.section_id === section.id);
  const qCount = sectionQuestions.length;

  // Find user's progress for this section
  const userProgress = progress.find(p => p.section_id === section.id);
  const sectionXp = userProgress ? userProgress.xp : 0;
  const answeredCount = userProgress ? userProgress.answered : 0;
  const correctCount = userProgress ? userProgress.correct : 0;

  const styleSet = colorMap[section.color] || colorMap.blue;

  return (
    <motion.div
      onClick={onSelect}
      whileHover={{ y: -4, scale: 1.01 }}
      whileTap={{ scale: 0.99 }}
      className={`p-6 border rounded-2xl cursor-pointer ${styleSet.bg} ${styleSet.border} ${styleSet.hover} flex flex-col justify-between transition-all shadow-sm group min-h-[180px]`}
    >
      <div className="flex items-start justify-between">
        {/* Color Accent Pill icon */}
        <div className={`p-3.5 rounded-xl ${styleSet.accent} text-white shadow-md shadow-slate-900/5`}>
          <IconComponent className="w-6 h-6" />
        </div>

        {section.is_custom && (
          <span className="text-[10px] font-bold px-2 py-1 bg-slate-100 dark:bg-slate-900 text-slate-500 dark:text-slate-400 rounded-lg">
            قسم مخصص
          </span>
        )}
      </div>

      <div className="mt-4 text-right">
        <h3 className="text-lg font-bold text-slate-800 dark:text-white mb-1 group-hover:text-blue-600 dark:group-hover:text-amber-400 transition-colors">
          {section.title}
        </h3>
        
        <p className="text-xs text-slate-500 dark:text-slate-400">
          عدد الأسئلة: <span className="font-bold">{qCount}</span>
        </p>
      </div>

      {/* Progress status card bar */}
      <div className="mt-5 pt-4 border-t border-slate-100 dark:border-slate-800/40 flex items-center justify-between text-xs">
        <div className="text-right">
          <div className="text-[10px] uppercase font-semibold text-slate-400 dark:text-slate-500">النقاط الكلية</div>
          <div className={`text-sm font-black font-mono ${styleSet.text}`}>{sectionXp} XP</div>
        </div>

        {answeredCount > 0 && (
          <div className="text-left">
            <div className="text-[10px] uppercase font-semibold text-slate-400 dark:text-slate-500">نسبة الإجابة</div>
            <div className="text-sm font-bold text-slate-700 dark:text-slate-200">
              {correctCount}/{answeredCount}
            </div>
          </div>
        )}
      </div>
    </motion.div>
  );
}
