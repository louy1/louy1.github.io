import { Ad } from '../types';
import { ExternalLink, Megaphone } from 'lucide-react';
import { motion } from 'motion/react';

interface AdBlockProps {
  key?: string | number;
  ad: Ad;
}

export default function AdBlock({ ad }: AdBlockProps) {
  return (
    <motion.div
      whileHover={{ scale: 1.008 }}
      className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-3xl overflow-hidden shadow-sm flex flex-col md:flex-row items-stretch"
      dir="rtl"
    >
      {ad.image_url && (
        <div className="w-full md:w-48 h-32 md:h-auto shrink-0 relative bg-slate-100 dark:bg-slate-950">
          <img
            src={ad.image_url}
            alt={ad.title}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
          />
          <div className="absolute top-2 right-2 px-2 py-1 bg-amber-500 text-white rounded text-[9px] font-bold uppercase tracking-wide flex items-center gap-1 shadow-sm">
            <Megaphone className="w-3.5 h-3.5" />
            <span>مميز</span>
          </div>
        </div>
      )}

      <div className="p-6 text-right flex-grow flex flex-col justify-between">
        <div>
          <h4 className="text-base font-bold text-slate-800 dark:text-white mb-1.5 leading-snug">
            {ad.title}
          </h4>
          <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
            {ad.body}
          </p>
        </div>

        {ad.link && (
          <div className="mt-4 text-left">
            <a
              href={ad.link}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 text-xs font-bold text-blue-600 dark:text-blue-400 hover:underline"
            >
              <span>استكشف العرض الآن</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
        )}
      </div>
    </motion.div>
  );
}
