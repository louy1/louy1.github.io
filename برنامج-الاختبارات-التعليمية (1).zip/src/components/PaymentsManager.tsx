import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { CreditCard, Check, X, ShieldAlert, Coins, RefreshCw, Layers, AlertCircle, ToggleLeft, ToggleRight } from 'lucide-react';
import { motion } from 'motion/react';

export default function PaymentsManager() {
  const { uiSettings, students, paymentRequests, paymentReceipts, refreshData } = useApp();
  const [activeSubTab, setActiveSubTab] = useState<'pending' | 'approved' | 'rejected'>('pending');
  const [loading, setLoading] = useState(false);
  const [feedback, setFeedback] = useState('');
  
  // Local settings states
  const requireAccessCode = uiSettings['require_access_code'] !== 'off';
  const customCardInfo = uiSettings['payment_card_info'] || 'الرجاء التحويل إلى رقم الحساب البنكي أو البطاقة لإتمام الطلب';
  
  const [cardInfoInput, setCardInfoInput] = useState(customCardInfo);

  const handleToggleCode = async () => {
    setLoading(true);
    try {
      const devToken = localStorage.getItem('school_dev_token') || 'awdrgyjilplouyking-devms-token';
      const res = await fetch('/api/dev-action', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          token: devToken,
          action: 'toggle_access_code',
          payload: { value: requireAccessCode ? 'off' : 'on' }
        })
      });
      if (res.ok) {
        setFeedback('تم التبديل وتعديل ميزة كود الدخول العام ومخيمات المطور بنجاح.');
        await refreshData();
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateCardInfo = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const devToken = localStorage.getItem('school_dev_token') || 'awdrgyjilplouyking-devms-token';
      const res = await fetch('/api/dev-action', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          token: devToken,
          action: 'update_payment_card_info',
          payload: { value: cardInfoInput }
        })
      });
      if (res.ok) {
        setFeedback('تم تحديث معلومات بطاقة الدفع ورقم التحويل للإدارة بنجاح.');
        await refreshData();
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleAction = async (action: 'approve_payment' | 'reject_payment', requestId: string) => {
    setLoading(true);
    setFeedback('');
    try {
      const devToken = localStorage.getItem('school_dev_token') || 'awdrgyjilplouyking-devms-token';
      const res = await fetch('/api/dev-action', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          token: devToken,
          action,
          payload: { requestId }
        })
      });
      if (res.ok) {
        setFeedback(action === 'approve_payment' ? '✅ تم اعتماد التحويل وتوليد الكود بنجاح!' : '❌ تم رفض وتوثيق الرفض للطلب.');
        await refreshData();
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleClearAll = async () => {
    if (!window.confirm('🚨 تحذير: هل أنت متأكد من رغبتك في حذف كافة طلبات وتراخيص الدفع والأكواد السابقة نهائياً؟')) return;
    setLoading(true);
    try {
      const devToken = localStorage.getItem('school_dev_token') || 'awdrgyjilplouyking-devms-token';
      await fetch('/api/dev-action', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token: devToken, action: 'clear_payment_requests', payload: {} })
      });
      await fetch('/api/dev-action', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token: devToken, action: 'clear_payment_receipts', payload: {} })
      });
      setFeedback('🧺 تم إفراغ كافة سجلات العمليات بنجاح.');
      await refreshData();
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  // Filter lists based on view state
  const pendingRequests = paymentRequests.filter((r: any) => r.status === 'pending');
  const rejectedRequests = paymentRequests.filter((r: any) => r.status === 'rejected');
  const approvedRequests = paymentRequests.filter((r: any) => r.status === 'approved');

  return (
    <div className="space-y-6 text-right" dir="rtl">
      {/* Top Banner and Quick State control */}
      <div className="bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 p-6 rounded-3xl flex flex-col md:flex-row items-center justify-between gap-6 shadow-sm">
        <div className="space-y-1">
          <h2 className="text-lg font-black text-slate-800 dark:text-white flex items-center gap-2">
            <Coins className="w-5 h-5 text-amber-500 animate-bounce" />
            <span>نظام الفوترة وتوثيق رموز الدخول المخصصة</span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            تأكيد التحويلات النقدية المقدمة من البطاقات البنكية للطلاب وتوليد الرموز الحصرية باسم المالك لمنع تخمين الدخول.
          </p>
        </div>

        {/* Global Access Code Switch */}
        <button
          onClick={handleToggleCode}
          disabled={loading}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl border cursor-pointer font-bold text-xs transition duration-300 ${
            requireAccessCode
              ? 'bg-amber-500 text-white border-amber-400 shadow'
              : 'bg-white dark:bg-slate-950 text-slate-600 dark:text-slate-400 border-slate-150 dark:border-slate-800 hover:bg-slate-100'
          }`}
        >
          {requireAccessCode ? <ToggleRight className="w-5 h-5" /> : <ToggleLeft className="w-5 h-5" />}
          <span>ميزة كود الدخول: {requireAccessCode ? 'مفعلة (إجبارية)' : 'مغلقة (دخول بلا أكواد)'}</span>
        </button>
      </div>

      {feedback && (
        <div className="p-4 bg-blue-50 dark:bg-blue-950/20 text-blue-600 dark:text-blue-400 text-xs font-bold rounded-2xl border border-blue-100 dark:border-blue-900 flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{feedback}</span>
        </div>
      )}

      {/* Grid Settings */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* IBAN Change card */}
        <div className="lg:col-span-1 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 p-5 rounded-3xl space-y-4">
          <h3 className="text-xs font-black text-slate-600 dark:text-slate-400 flex items-center gap-1.5 opacity-80">
            <CreditCard className="w-4 h-4 text-slate-500" />
            <span>بيانات حساب استقبال التحويل المالي</span>
          </h3>
          <p className="text-[10px] text-slate-400 leading-relaxed font-normal">
            تظهر هذه التعليمات للطلاب في شاشة الشراء لتوجيههم لتحويل رسوم الترخيص إليها من حساباتهم.
          </p>

          <form onSubmit={handleUpdateCardInfo} className="space-y-3">
            <textarea
              value={cardInfoInput}
              onChange={(e) => setCardInfoInput(e.target.value)}
              placeholder="مثلا: مصرف الراجحي ايبان SA038000..."
              className="w-full h-32 px-4 py-3 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white text-xs border border-slate-150 dark:border-slate-800 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl transition shadow cursor-pointer disabled:opacity-50"
            >
              حفظ وتعميم معلومات الدفع
            </button>
          </form>

          <div className="pt-3 border-t border-slate-50 dark:border-slate-805">
            <button
              onClick={handleClearAll}
              disabled={loading}
              className="w-full py-2 bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/20 text-rose-600 dark:text-rose-400 text-xs font-bold rounded-xl border border-rose-100/30 transition cursor-pointer"
            >
              مسح وتطهير كافة السجلات والأكواد للبدء من جديد
            </button>
          </div>
        </div>

        {/* Dynamic Requests list */}
        <div className="lg:col-span-2 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 p-5 rounded-3xl space-y-4">
          {/* Sub Navigation */}
          <div className="flex border-b border-slate-100 dark:border-slate-805 pb-3 gap-2">
            <button
              onClick={() => setActiveSubTab('pending')}
              className={`px-4 py-2 rounded-xl text-xs font-black cursor-pointer transition flex items-center gap-1.5 ${
                activeSubTab === 'pending'
                  ? 'bg-amber-500 text-white shadow'
                  : 'bg-slate-50 dark:bg-slate-950 text-slate-500 hover:bg-slate-100'
              }`}
            >
              <span>الطلبات المعلقة</span>
              <span className="bg-white/20 text-[10px] px-2 py-0.5 rounded-full">{pendingRequests.length}</span>
            </button>

            <button
              onClick={() => setActiveSubTab('approved')}
              className={`px-4 py-2 rounded-xl text-xs font-black cursor-pointer transition flex items-center gap-1.5 ${
                activeSubTab === 'approved'
                  ? 'bg-emerald-500 text-white shadow'
                  : 'bg-slate-50 dark:bg-slate-950 text-slate-500 hover:bg-slate-100'
              }`}
            >
              <span>المقبولة والأكواد الصادرة</span>
              <span className="bg-white/20 text-[10px] px-2 py-0.5 rounded-full">{approvedRequests.length}</span>
            </button>

            <button
              onClick={() => setActiveSubTab('rejected')}
              className={`px-4 py-2 rounded-xl text-xs font-black cursor-pointer transition flex items-center gap-1.5 ${
                activeSubTab === 'rejected'
                  ? 'bg-rose-500 text-white shadow'
                  : 'bg-slate-50 dark:bg-slate-950 text-slate-500 hover:bg-slate-100'
              }`}
            >
              <span>الطلبات المرفوضة</span>
              <span className="bg-white/20 text-[10px] px-2 py-0.5 rounded-full">{rejectedRequests.length}</span>
            </button>
          </div>

          <div className="space-y-3 min-h-60 overflow-y-auto max-h-[480px]">
            {activeSubTab === 'pending' && (
              <>
                {pendingRequests.length === 0 ? (
                  <div className="text-center py-12 text-slate-400 space-y-2">
                    <Check className="w-8 h-8 mx-auto text-emerald-500 opacity-60" />
                    <p className="text-xs font-bold">لا يوجد أي طلبات ترخيص معلقة حالياً! نظام الفوترة نظيف.</p>
                  </div>
                ) : (
                  pendingRequests.map((req: any) => (
                    <motion.div
                      layout
                      key={req.id}
                      className="p-4 bg-slate-50 dark:bg-slate-955 rounded-2xl border border-slate-100 dark:border-slate-805 flex flex-col md:flex-row items-center justify-between gap-4"
                    >
                      <div className="space-y-1 text-center md:text-right">
                        <h4 className="text-sm font-black text-slate-800 dark:text-white">{req.student_name}</h4>
                        <div className="flex flex-wrap items-center justify-center md:justify-start gap-3 text-[10px] text-slate-400">
                          <span>💳 البطاقة: **** {req.card_digits}</span>
                          <span>👤 الحساب: {req.card_holder}</span>
                          <span>💰 المبلغ: {req.amount} ريال</span>
                          <span>🕒 {new Date(req.created_at).toLocaleTimeString('ar-SA')}</span>
                        </div>
                      </div>

                      <div className="flex gap-2">
                        <button
                          disabled={loading}
                          onClick={() => handleAction('approve_payment', req.id)}
                          className="px-3.5 py-1.5 bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-bold rounded-xl shadow-sm flex items-center gap-1 cursor-pointer transition"
                        >
                          <Check className="w-3.5 h-3.5" />
                          <span>اعتماد الترخيص وتوليد الرمز</span>
                        </button>
                        <button
                          disabled={loading}
                          onClick={() => handleAction('reject_payment', req.id)}
                          className="px-3.5 py-1.5 bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/20 text-rose-600 rounded-xl text-xs font-bold flex items-center gap-1 cursor-pointer transition border border-rose-100/20"
                        >
                          <X className="w-3.5 h-3.5" />
                          <span>رفض</span>
                        </button>
                      </div>
                    </motion.div>
                  ))
                )}
              </>
            )}

            {activeSubTab === 'approved' && (
              <>
                {approvedRequests.length === 0 ? (
                  <div className="text-center py-12 text-slate-400">
                    <p className="text-xs font-bold">لم يتم قبول أو تفعيل أي كود دخول حتى الآن.</p>
                  </div>
                ) : (
                  approvedRequests.map((req: any) => (
                    <div
                      key={req.id}
                      className="p-4 bg-emerald-500/5 dark:bg-emerald-900/10 rounded-2xl border border-emerald-100 dark:border-emerald-900/30 flex items-center justify-between gap-4"
                    >
                      <div className="space-y-1">
                        <h4 className="text-sm font-black text-slate-850 dark:text-slate-100">{req.student_name}</h4>
                        <p className="text-[10px] text-slate-420">
                          بواسطة البطاقة **** {req.card_digits} | قيمة: {req.amount} ر.س | {new Date(req.created_at).toLocaleDateString('ar-SA')}
                        </p>
                      </div>

                      <div className="text-left space-y-1">
                        <span className="text-[9px] text-emerald-600 dark:text-emerald-400 block font-bold">الرمز النشط:</span>
                        <code className="text-sm font-black font-mono bg-white dark:bg-slate-950 px-2.5 py-1 border border-emerald-200 dark:border-emerald-900 rounded-lg text-blue-600 dark:text-blue-400 select-all tracking-widest block">
                          {req.generated_code}
                        </code>
                      </div>
                    </div>
                  ))
                )}
              </>
            )}

            {activeSubTab === 'rejected' && (
              <>
                {rejectedRequests.length === 0 ? (
                  <div className="text-center py-12 text-slate-400">
                    <p className="text-xs font-bold">سجل الطلبات المرفوضة فارغ.</p>
                  </div>
                ) : (
                  rejectedRequests.map((req: any) => (
                    <div
                      key={req.id}
                      className="p-4 bg-rose-500/5 dark:bg-rose-900/10 rounded-2xl border border-rose-100 dark:border-rose-900/30 flex items-center justify-between"
                    >
                      <div className="space-y-1">
                        <h4 className="text-sm font-black text-slate-800 dark:text-white">{req.student_name}</h4>
                        <p className="text-[10px] text-slate-400">
                          بواسطة: {req.card_holder} | البطاقة: **** {req.card_digits} | قيمة {req.amount} ر.س
                        </p>
                      </div>

                      <span className="text-xs text-rose-500 font-bold bg-rose-50 dark:bg-rose-950/20 px-3 py-1 rounded-lg border border-rose-100/20">
                        مرفوض من الإدارة ❌
                      </span>
                    </div>
                  ))
                )}
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
