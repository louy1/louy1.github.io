import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { getDevToken } from '../../lib/devToken';
import { Ad } from '../../types';
import { Megaphone, Trash2, CheckCircle, AlertTriangle, Plus } from 'lucide-react';

export default function AdsManager() {
  const { ads, refreshData } = useApp();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // Form states
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [link, setLink] = useState('');
  const [placement, setPlacement] = useState('home_top');
  const [active, setActive] = useState(true);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !body.trim()) {
      setError('الرجاء كتابة العنوان والوصف للإعلان.');
      return;
    }

    setLoading(true);
    setError('');

    const token = getDevToken();
    const payload: Ad = {
      id: `ad_${Math.random().toString(36).substr(2, 9)}`,
      title: title.trim(),
      body: body.trim(),
      image_url: imageUrl.trim() || 'https://images.unsplash.com/photo-1434030216411-0b793f4b4173?w=600',
      link: link.trim(),
      placement,
      active
    };

    try {
      const response = await fetch('/api/dev-action', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          token,
          action: 'upsert_ad',
          payload
        })
      });

      if (response.ok) {
        setTitle('');
        setBody('');
        setImageUrl('');
        setLink('');
        await refreshData();
      } else {
        const data = await response.json();
        setError(data.error || 'فشلت عملية حفظ الإعلان بالخادم.');
      }
    } catch (err) {
      setError('فشل الاتصال بالشبكة لحفظ الإعلان.');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (adId: string) => {
    setLoading(true);
    const token = getDevToken();

    try {
      const response = await fetch('/api/dev-action', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          token,
          action: 'delete_ad',
          payload: { id: adId }
        })
      });

      if (response.ok) {
        await refreshData();
      } else {
        console.error('فشل تصفير الإعلان بالخادم.');
      }
    } catch (e) {
      console.error('حدث خطأ بالشبكة.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 text-right" dir="rtl">
      
      {/* Right list column */}
      <div className="lg:col-span-2 space-y-4">
        <div>
          <h4 className="text-base font-bold text-slate-800 dark:text-white flex items-center gap-1.5">
            <Megaphone className="w-5 h-5 text-blue-500" />
            <span>لوحة البانرات والإعلانات المدرجة ({ads.length})</span>
          </h4>
          <p className="text-xs text-slate-400 mt-0.5">لافتات إعلانية وتحديات ممتازة تظهر على كروت الطلاب السفلية:</p>
        </div>

        <div className="space-y-4">
          {ads.map(ad => (
            <div
              key={ad.id}
              className="p-5 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl flex items-center justify-between shadow-sm gap-4"
            >
              <div className="flex items-center gap-4">
                {ad.image_url && (
                  <img
                    src={ad.image_url}
                    alt={ad.title}
                    referrerPolicy="no-referrer"
                    className="w-16 h-12 rounded-lg object-cover shrink-0"
                  />
                )}
                <div>
                  <h5 className="font-bold text-sm text-slate-800 dark:text-white">{ad.title}</h5>
                  <p className="text-xs text-slate-400 mt-1 line-clamp-1">{ad.body}</p>
                </div>
              </div>

              <button
                onClick={() => handleDelete(ad.id)}
                className="p-1.5 bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/20 text-rose-500 rounded-lg cursor-pointer transition"
                title="إزالة الإعلان"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Adding Editor Card form */}
      <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 p-6 rounded-3xl h-fit space-y-6 shadow-sm">
        <div>
          <h4 className="text-base font-bold text-slate-800 dark:text-white">نشر عرض أو تحدٍ إعلاني</h4>
          <p className="text-xs text-slate-400 mt-1">تعبئة المعايير لنشر اللافتة للجميع:</p>
        </div>

        <form onSubmit={handleCreate} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-500 mb-1.5">عنوان الإعلان:</label>
            <input
              id="ad-title-input"
              type="text"
              placeholder="مثال: خصم 50% كورس الصيف"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-3.5 py-2 text-sm bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-800 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-500 mb-1.5">تفاصيل العرض ووصف السير الإعلاني:</label>
            <textarea
              id="ad-body-input"
              rows={3}
              placeholder="سجل الكود الدراسي واحجز كرسيك التفاعلي فوراً..."
              value={body}
              onChange={(e) => setBody(e.target.value)}
              className="w-full px-3.5 py-2 text-sm bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-800 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-right leading-relaxed"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-500 mb-1.5">رابط صورة الترويسة (Image URL):</label>
            <input
              id="ad-image-url"
              type="text"
              placeholder="مثال: https://images.unsplash.com/..."
              value={imageUrl}
              onChange={(e) => setImageUrl(e.target.value)}
              className="w-full px-3.5 py-2 text-xs font-mono bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-800 rounded-lg focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-500 mb-1.5">رابط التحويل الخارجي (URL Link):</label>
            <input
              id="ad-link"
              type="text"
              placeholder="مثال: https://example.com/courses"
              value={link}
              onChange={(e) => setLink(e.target.value)}
              className="w-full px-3.5 py-2 text-xs font-mono bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-800 rounded-lg focus:outline-none"
            />
          </div>

          <div className="flex items-center gap-2 pt-1">
            <input
              id="ad-active-toggle"
              type="checkbox"
              checked={active}
              onChange={(e) => setActive(e.target.checked)}
              className="w-4.5 h-4.5 rounded text-blue-500"
            />
            <label htmlFor="ad-active-toggle" className="text-xs font-bold text-slate-600 dark:text-slate-300">
              تنشيط ونشر الإعلانات فورياً
            </label>
          </div>

          {error && <span className="text-xs text-rose-500 font-bold block">{error}</span>}

          <button
            id="ad-add-btn"
            type="submit"
            disabled={loading}
            className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>نشر الإعلان الآن</span>
          </button>
        </form>
      </div>

    </div>
  );
}
