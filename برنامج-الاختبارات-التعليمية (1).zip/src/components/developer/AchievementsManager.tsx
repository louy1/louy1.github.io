import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { getDevToken } from '../../lib/devToken';
import { Achievement, AchievementCondition } from '../../types';
import { Plus, Award, Trash2, Check, X, ShieldCheck } from 'lucide-react';

export default function AchievementsManager() {
  const { achievements, sections, refreshData } = useApp();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // Form states
  const [title, setTitle] = useState('');
  const [xpReward, setXpReward] = useState(100);
  const [icon, setIcon] = useState('Award');
  const [conditionType, setConditionType] = useState<any>('total_xp');
  const [conditionValue, setConditionValue] = useState(10);
  const [isDaily, setIsDaily] = useState(false);

  const ICON_LIST = ['Award', 'Trophy', 'Flame', 'Cpu', 'Zap', 'Compass', 'Heart', 'Atom', 'Brain'];

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || conditionValue <= 0) {
      setError('الرجاء كتابة اسم الجائزة وقيمة الشرط.');
      return;
    }

    setLoading(true);
    setError('');

    const token = getDevToken();
    const condObj: AchievementCondition = {
      type: conditionType,
      value: conditionValue
    };

    const payload: Achievement = {
      id: `ach_${Math.random().toString(36).substr(2, 9)}`,
      title: title.trim(),
      condition_json: condObj,
      xp_reward: xpReward,
      icon,
      is_daily: isDaily
    };

    try {
      const response = await fetch('/api/dev-action', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          token,
          action: 'upsert_achievement',
          payload
        })
      });

      if (response.ok) {
        setTitle('');
        setXpReward(100);
        setConditionValue(10);
        setIsDaily(false);
        await refreshData();
      } else {
        const data = await response.json();
        setError(data.error || 'فشلت معالجة الإرسال بالخادم.');
      }
    } catch (err) {
      setError('فشل الاتصال بالشبكة لحفظ الجائزة.');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (achId: string) => {
    setLoading(true);
    const token = getDevToken();

    try {
      const response = await fetch('/api/dev-action', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          token,
          action: 'delete_achievement',
          payload: { id: achId }
        })
      });

      if (response.ok) {
        await refreshData();
      } else {
        console.error('فشل في إزالة الإنجاز بالخادم.');
      }
    } catch (e) {
      console.error('حدث عطل بالشبكة.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 text-right" dir="rtl">
      
      {/* Right side list of rewards */}
      <div className="lg:col-span-2 space-y-4">
        <div>
          <h4 className="text-base font-bold text-slate-800 dark:text-white flex items-center gap-1.5">
            <Award className="w-5 h-5 text-amber-500" />
            <span>لوحة الأوسمة المعيّنة نشطاً ({achievements.length})</span>
          </h4>
          <p className="text-xs text-slate-400 mt-0.5">أوسمة تظهر تلقائياً بتقدم الطالب بمجرد استيفاء المعايير:</p>
        </div>

        <div className="space-y-4">
          {achievements.map(ach => (
            <div
              key={ach.id}
              className="p-5 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl flex items-center justify-between shadow-sm"
            >
              <div>
                <h5 className="font-bold text-sm text-slate-800 dark:text-white flex items-center gap-1.5">
                  <span className="text-amber-500">[{ach.icon}]</span>
                  <span>{ach.title}</span>
                </h5>
                <p className="text-xs text-slate-400 mt-1.5">
                  نوع الشرط: <span className="font-semibold text-slate-600 dark:text-slate-300">{ach.condition_json.type}</span> |
                  عتبة الفتح: <span className="font-bold text-slate-600 dark:text-slate-300 font-mono">{ach.condition_json.value}</span> |
                  بونص: <span className="text-amber-500 font-bold font-mono">+{ach.xp_reward} XP</span>
                </p>
              </div>

              <button
                onClick={() => handleDelete(ach.id)}
                className="p-1.5 bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/20 text-rose-500 rounded-lg cursor-pointer transition"
                title="مسح الجائزة"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Editor addition form */}
      <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 p-6 rounded-3xl h-fit space-y-6 shadow-sm">
        <div>
          <h4 className="text-base font-bold text-slate-800 dark:text-white">إضافة وسام تكريمي جديد</h4>
          <p className="text-xs text-slate-400 mt-1">تفريخ أهداف جديدة لإثارة ذكاء الطلاب:</p>
        </div>

        <form onSubmit={handleCreate} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-500 mb-1.5">اسم الجائزة:</label>
            <input
              id="ach-title-input"
              type="text"
              placeholder="مثال: قناص كويز الرياضيات"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-3.5 py-2 text-sm bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-800 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-500 mb-1.5">الشرط القياسي:</label>
              <select
                value={conditionType}
                onChange={(e) => setConditionType(e.target.value)}
                className="w-full px-3.5 py-2.5 text-xs bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-800 rounded-lg focus:outline-none"
              >
                <option value="total_xp">نقاط XP إجمالية</option>
                <option value="answered_count">أسئلة مجابة كلياً</option>
                <option value="correct_count">إجابات صحيحة كلية</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-500 mb-1.5">العتبة الرقمية:</label>
              <input
                id="ach-cond-value-input"
                type="number"
                value={conditionValue}
                onChange={(e) => setConditionValue(parseInt(e.target.value, 10) || 10)}
                className="w-full px-3.5 py-2 text-sm bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-800 rounded-lg focus:outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-500 mb-1.5">بونص جائزه الجولة:</label>
              <input
                id="ach-reward-xp-input"
                type="number"
                value={xpReward}
                onChange={(e) => setXpReward(parseInt(e.target.value, 10) || 50)}
                className="w-full px-3.5 py-2 text-sm bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-800 rounded-lg focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-500 mb-1.5">أيقونة الشعار:</label>
              <select
                value={icon}
                onChange={(e) => setIcon(e.target.value)}
                className="w-full px-3.5 py-2.5 text-xs bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-800 rounded-lg focus:outline-none"
              >
                {ICON_LIST.map(ic => <option key={ic} value={ic}>{ic}</option>)}
              </select>
            </div>
          </div>

          <div className="flex items-center gap-2 pt-1">
            <input
              id="ach-is-daily-toggle"
              type="checkbox"
              checked={isDaily}
              onChange={(e) => setIsDaily(e.target.checked)}
              className="w-4.5 h-4.5 rounded text-amber-500"
            />
            <label htmlFor="ach-is-daily-toggle" className="text-xs font-bold text-slate-600 dark:text-slate-300">
              اعتبار التحدي "يومي تفاعلي متكرر"
            </label>
          </div>

          {error && <span className="text-xs text-rose-500 font-bold block">{error}</span>}

          <button
            id="ach-add-btn"
            type="submit"
            disabled={loading}
            className="w-full py-3 bg-amber-500 hover:bg-amber-600 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 cursor-pointer mt-2"
          >
            <ShieldCheck className="w-4 h-4" />
            <span>تأكيد ونشر الإنجاز</span>
          </button>
        </form>
      </div>

    </div>
  );
}
