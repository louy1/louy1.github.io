import { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { getDevToken } from '../../lib/devToken';
import { BookOpen, Search, Trash2, Calendar, User, FileText } from 'lucide-react';
import { motion } from 'motion/react';

export default function StudentNotesManager() {
  const { studentNotes, students, refreshData } = useApp();
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(false);

  // Match student details for each note
  const notesWithStudent = studentNotes.map(note => {
    const writer = students.find(s => s.id === note.student_id);
    return {
      ...note,
      studentName: writer ? writer.display_name : 'طالب مجهول'
    };
  });

  // Filter notes
  const filteredNotes = notesWithStudent.filter(note => {
    return (
      note.note_text.toLowerCase().includes(searchTerm.toLowerCase()) ||
      note.section_title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      note.studentName.toLowerCase().includes(searchTerm.toLowerCase())
    );
  });

  const handleDeleteNote = async (noteId: string) => {
    setLoading(true);
    const token = getDevToken();

    try {
      const response = await fetch('/api/dev-action', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          token,
          action: 'delete_student_note',
          payload: { noteId }
        })
      });

      if (response.ok) {
        await refreshData();
      } else {
        alert('فشل خادم الحفظ في إزالة الملاحظة.');
      }
    } catch (e) {
      alert('حدث خطأ بالاتصال بالخادم لإتمام الطلب.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-3xl p-6 space-y-6 text-right" dir="rtl">
      
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h3 className="text-base font-black text-slate-800 dark:text-white flex items-center gap-2">
            <FileText className="w-5 h-5 text-indigo-500" />
            <span>رقابة وإدارة مفكرات وملاحظات الطلاب</span>
          </h3>
          <p className="text-xs text-slate-400 mt-1">هنا يمكنك مراجعة وتعديل وتصفية الملاحظات والملخصات الدراسية التي يقوم الطلاب بكتابتها أثناء استذكارهم للمناهج:</p>
        </div>

        <div className="relative w-full sm:w-64 shrink-0">
          <input
            type="text"
            placeholder="ابحث بالنص، الطالب أو المادة..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-3 pr-10 py-2 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-800 rounded-xl text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-none"
          />
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
        </div>
      </div>

      {filteredNotes.length === 0 ? (
        <div className="p-12 text-center text-slate-400 dark:text-slate-500 font-bold bg-slate-50 dark:bg-slate-950 rounded-2xl border border-dashed text-xs">
          لا توجد ملاحظات مطابقة لبحثك في البوابة التعليمية.
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredNotes.map((note) => (
            <motion.div
              layout
              key={note.id}
              className="p-5 bg-white dark:bg-slate-950 border border-slate-100 dark:border-slate-850 rounded-2xl shadow-sm hover:shadow-md transition-all relative flex flex-col justify-between group"
            >
              <div className="space-y-3.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-xs font-black text-slate-800 dark:text-white">
                    <User className="w-3.5 h-3.5 text-indigo-500" />
                    <span>{note.studentName}</span>
                  </div>

                  <span className="px-2 py-0.5 bg-indigo-50 dark:bg-indigo-950/20 text-indigo-600 dark:text-indigo-400 text-[10px] rounded-md font-bold">
                    {note.section_title}
                  </span>
                </div>

                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed font-medium bg-slate-50/50 dark:bg-slate-900/40 p-3 rounded-xl border border-slate-100 dark:border-slate-850/50">
                  {note.note_text}
                </p>
              </div>

              <div className="flex items-center justify-between mt-4 pt-3 border-t border-slate-50 dark:border-slate-900 text-[10px] text-slate-400">
                <div className="flex items-center gap-1">
                  <Calendar className="w-3 h-3 text-slate-400" />
                  <span>{new Date(note.created_at).toLocaleDateString('ar-SA', { day: 'numeric', month: 'long', year: 'numeric' })}</span>
                </div>

                <button
                  onClick={() => handleDeleteNote(note.id)}
                  disabled={loading}
                  className="p-1.5 bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/20 text-rose-500 rounded-lg transition opacity-60 group-hover:opacity-100 cursor-pointer"
                  title="حذف الملاحظة"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      )}

    </div>
  );
}
