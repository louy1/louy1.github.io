import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { getDevToken } from '../../lib/devToken';
import { Sparkles, Trophy, Star, Lightbulb, Image as ImageIcon } from 'lucide-react';
import { motion } from 'motion/react';

export default function CupGenerator() {
  const { sections, student } = useApp();
  
  // Inputs
  const [studentName, setStudentName] = useState(student?.display_name || 'طالب متميز');
  const [selectedSubject, setSelectedSubject] = useState(sections[0]?.title || 'الرياضيات');
  const [specialNotice, setSpecialNotice] = useState('البطولة ومعدل دقة 100%');

  // Outputs
  const [loading, setLoading] = useState(false);
  const [generatedCup, setGeneratedCup] = useState<any | null>(null);
  const [error, setError] = useState('');

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setGeneratedCup(null);

    try {
      const response = await fetch('/api/cup-generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          studentName,
          subjectName: selectedSubject,
          specialNotice
        })
      });

      if (response.ok) {
        const data = await response.json();
        setGeneratedCup(data.cup);
      } else {
        const errData = await response.json();
        setError(errData.error || 'حدث خلل في ميكانيزم استخلاص ذكاء الكأس.');
      }
    } catch (err) {
      setError('فشل الاتصال بخادم الذكاء الاصطناعي لتوليد الجائزة الكأسية.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 text-right" dir="rtl">
      
      {/* Right Column: Generation Inputs form */}
      <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 p-6 sm:p-8 rounded-3xl shadow-sm space-y-6">
        <div>
          <h4 className="text-base font-bold text-slate-800 dark:text-white flex items-center gap-1.5">
            <Sparkles className="w-5 h-5 text-amber-500 animate-pulse" />
            <span>مولّد الدروع والكؤوس التعليمية بالذكاء الاصطناعي</span>
          </h4>
          <p className="text-xs text-slate-400 mt-1">
            يقوم الخادم بتمرير المعايير لمندوب ذكاء Gemini الاصطناعي لإنشاء لقب نادٍ ووصف درع خيالي مخصص فائق الجمال:
          </p>
        </div>

        <form onSubmit={handleGenerate} className="space-y-4">
          
          <div>
            <label className="block text-xs font-semibold text-slate-500 mb-1.5 mr-1">اسم الطالب الفائز:</label>
            <input
              id="cup-student-name"
              type="text"
              value={studentName}
              onChange={(e) => setStudentName(e.target.value)}
              className="w-full px-4 py-2.5 text-sm bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-500 mb-1.5 mr-1">المادة المرتبطة بالإنجاز:</label>
            <select
              value={selectedSubject}
              onChange={(e) => setSelectedSubject(e.target.value)}
              className="w-full px-3.5 py-2.5 text-sm bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500"
            >
              {sections.map(s => (
                <option key={s.id} value={s.title}>{s.title}</option>
              ))}
              <option value="المنصة الكلية">جميع المواد والإنجاز العام</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-500 mb-1.5 mr-1">ملاحظة التميز المضافة للذكاء:</label>
            <input
              id="cup-special-notice"
              type="text"
              value={specialNotice}
              onChange={(e) => setSpecialNotice(e.target.value)}
              placeholder="مثال: دقة متناهية وإتمام مئة سؤال"
              className="w-full px-4 py-2.5 text-sm bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500"
            />
          </div>

          {error && <span className="text-xs text-rose-500 font-bold block">{error}</span>}

          <button
            id="btn-trigger-ai-cup"
            type="submit"
            disabled={loading}
            className="w-full py-3.5 bg-gradient-to-r from-amber-500 via-orange-500 to-yellow-500 text-white font-extrabold rounded-xl text-xs flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-orange-500/10 hover:shadow-orange-500/20 transition"
          >
            {loading ? (
              <>
                <span className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                <span>جاري استثارة عقول Gemini وتصميم الكأس...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4.5 h-4.5 text-white animate-pulse" />
                <span>توليد وتصميم الكأس بالذكاء</span>
              </>
            )}
          </button>
        </form>
      </div>

      {/* Left Column: Visual generated Trophy representation */}
      <div className="flex flex-col items-center justify-center min-h-[300px]">
        {loading && (
          <div className="text-center space-y-4">
            <Trophy className="w-16 h-16 text-amber-500/30 animate-pulse mx-auto" />
            <p className="text-xs font-bold text-slate-400 dark:text-slate-500 animate-pulse">يقوم المعالج بإرسال المطالب وصبر الهياكل اللغوية...</p>
          </div>
        )}

        {!loading && !generatedCup && (
          <div className="text-center p-8 bg-slate-50 dark:bg-slate-900/10 border border-slate-100 dark:border-slate-850 rounded-3xl max-w-sm">
            <Trophy className="w-12 h-12 text-slate-350 mx-auto mb-3" />
            <span className="text-xs font-bold text-slate-400">انقر على زر التوليد باليمين لتخيل وطبخ الكؤوس الحصرية بنظام الذكاء التوليدي المزدوج.</span>
          </div>
        )}

        {!loading && generatedCup && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="w-full max-w-md bg-gradient-to-br from-amber-950 via-slate-900 to-slate-950 border-2 border-amber-500/40 p-8 rounded-3xl text-center space-y-6 relative overflow-hidden shadow-2xl"
          >
            {/* Ambient golden glows */}
            <div className="absolute -top-12 -left-12 w-32 h-32 bg-amber-500/10 rounded-full blur-3xl" />
            <div className="absolute -bottom-12 -right-12 w-32 h-32 bg-yellow-500/10 rounded-full blur-3xl" />

            <div className="relative inline-block">
              <div className="w-20 h-20 bg-gradient-to-br from-amber-400 via-yellow-500 to-orange-500 rounded-3xl flex items-center justify-center text-white shadow-xl shadow-amber-500/20 mx-auto">
                <Trophy className="w-10 h-10 animate-bounce" />
              </div>
              <div className="absolute -top-1 -right-1">
                <Star className="w-5 h-5 text-yellow-300 fill-yellow-300 animate-spin" />
              </div>
            </div>

            <div className="space-y-2">
              <span className="text-[10px] uppercase font-bold tracking-widest text-amber-400 block px-2.5 py-1 bg-amber-950/40 border border-amber-900/60 rounded-full w-fit mx-auto">
                لقب ومخطط درع شرفي الذكاء
              </span>
              <h2 className="text-xl font-black text-amber-400 leading-snug">
                {generatedCup.cupTitle}
              </h2>
              <div className="text-xs text-slate-400 font-bold">للطالب المتفوق: {studentName}</div>
            </div>

            {/* AI visualization details */}
            <div className="p-4 bg-slate-950/80 border border-amber-900/30 rounded-2xl text-right text-xs leading-relaxed text-slate-300 font-medium space-y-2.5 relative">
              <span className="text-[10px] text-amber-500/80 font-black block border-b border-amber-900/20 pb-2">تفاصيل الصهر الفني للتخيل:</span>
              <p>{generatedCup.visualDescription}</p>
            </div>

            <div className="flex justify-between items-center bg-amber-500/5 border border-amber-500/15 p-3 rounded-xl text-xs text-amber-400 font-bold">
              <span>القيمة التقديرية الحصرية لك:</span>
              <span className="font-mono text-sm underline font-black">+{generatedCup.pointsReward} XP</span>
            </div>

            <span className="block text-[9px] text-slate-500">تم صهره بموجب مستندات نموذج @google/genai الرائد</span>

          </motion.div>
        )}
      </div>

    </div>
  );
}
