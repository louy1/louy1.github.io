import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { getDevToken } from '../../lib/devToken';
import { Sliders, CheckCircle, Lock, Key } from 'lucide-react';

export default function UICustomizer() {
  const { uiSettings, updateUISettings, refreshData } = useApp();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  // Local Form states
  const [appTitle, setAppTitle] = useState(uiSettings.appTitle || 'برنامج الاختبارات التعليمية');
  const [bannerText, setBannerText] = useState(uiSettings.bannerText || 'نظام النقاط XP مفعّل!');
  const [primaryColor, setPrimaryColor] = useState(uiSettings.primaryColor || '#222 80% 50%');
  const [devDisplayName, setDevDisplayName] = useState(uiSettings.dev_display_name || uiSettings.devDisplayName || 'المطور الرئيسي');
  const [disableAccountCreation, setDisableAccountCreation] = useState(uiSettings.disable_account_creation === 'on');
  const [quizAutoAdvanceDelay, setQuizAutoAdvanceDelay] = useState(Number(uiSettings.quiz_auto_advance_delay || '3'));

  // PIN settings local state
  const [supervisorPin, setSupervisorPin] = useState(uiSettings.supervisor_pin || 'awdrgyjilp');
  const [masterPin, setMasterPin] = useState(uiSettings.master_control_pin || 'awdrgyjilplouyking');
  const [schoolPinCode, setSchoolPinCode] = useState(uiSettings.school_pin_code !== undefined ? uiSettings.school_pin_code : 'awdrgyjilp');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setSuccess(false);

    if (!supervisorPin.trim() || !masterPin.trim()) {
      setError('الرجاء كتابة شفرات تشغيل صالحة لقسمي المشرف والتحكم.');
      setLoading(false);
      return;
    }

    try {
      const token = getDevToken();
      const updatedUi = { 
        appTitle, 
        bannerText, 
        primaryColor, 
        devDisplayName, 
        disable_account_creation: disableAccountCreation ? 'on' : 'off',
        quiz_auto_advance_delay: quizAutoAdvanceDelay.toString()
      };
      
      // Save primary ui settings
      const responseUi = await fetch('/api/dev-action', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          token,
          action: 'upsert_ui_settings',
          payload: { id: 'singleton', ...updatedUi }
        })
      });

      // Save secret PINs
      const responsePins = await fetch('/api/dev-action', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          token,
          action: 'update_pincodes',
          payload: { 
            supervisorPin: supervisorPin.trim(), 
            masterPin: masterPin.trim(),
            schoolPinCode: schoolPinCode.trim()
          }
        })
      });

      if (responseUi.ok && responsePins.ok) {
        setSuccess(true);
        updateUISettings(updatedUi);
        await refreshData();
        setTimeout(() => setSuccess(false), 3500);
      } else {
        setError('فشلت معالجة بعض عمليات الحفظ بالخادم. يرجى مراجعة الصلاحية.');
      }
    } catch (err) {
      setError('خطأ في الاتصال بالخادم لحفظ إعدادات المنصة.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto text-right" dir="rtl">
      
      <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 p-6 sm:p-8 rounded-3xl shadow-sm space-y-6">
        <div>
          <h4 className="text-base font-bold text-slate-800 dark:text-white flex items-center gap-1.5">
            <Sliders className="w-5 h-5 text-blue-500" />
            <span>لوحة مخصص الواجهة والتأمين (PINs)</span>
          </h4>
          <p className="text-xs text-slate-400 mt-0.5">تعديل الألوان والشريط العلوي، بالإضافة لتغيير شفرات تأمين المشرف والتحكم:</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-505 mb-1.5 mr-1">تسمية عنوان تطبيق الأكاديمية (App Navigation Title):</label>
              <input
                type="text"
                value={appTitle}
                onChange={(e) => setAppTitle(e.target.value)}
                className="w-full px-4 py-2.5 text-xs bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-505 mb-1.5 mr-1">رقم الرموز اللونية للثيم الأساسي (Hex or HSL):</label>
              <input
                type="text"
                value={primaryColor}
                onChange={(e) => setPrimaryColor(e.target.value)}
                placeholder="مثال: #3b82f6"
                className="w-full px-4 py-2.5 text-xs font-mono bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-505 mb-1.5 mr-1">شريط بونص النقاط العلوي بالتحديات (Banner Promotion text):</label>
            <input
              type="text"
              value={bannerText}
              onChange={(e) => setBannerText(e.target.value)}
              className="w-full px-4 py-2.5 text-xs bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-505 mb-1.5 mr-1">اسم المطور الذي يظهر للطلاب في مجموعات الدردشة (Developer Display Name):</label>
            <input
              type="text"
              value={devDisplayName}
              onChange={(e) => setDevDisplayName(e.target.value)}
              placeholder="مثال: المطور الرئيسي"
              className="w-full px-4 py-2.5 text-xs bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          {/* Secret Passwords Section */}
          <div className="pt-4 border-t border-slate-100 dark:border-slate-800 space-y-4">
            <h5 className="text-xs font-bold text-slate-800 dark:text-white flex items-center gap-1">
              <Lock className="w-4 h-4 text-amber-500" />
              <span>إدارة وتعديل برمجة رموز المرور (Passwords)</span>
            </h5>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-[11px] font-semibold text-slate-500 mb-1.5 mr-1 flex items-center gap-1">
                  <Key className="w-3 h-3 text-blue-500" />
                  <span>رمز الدخول الأول (المشرف / تعديل الأسئلة):</span>
                </label>
                <input
                  type="text"
                  value={supervisorPin}
                  onChange={(e) => setSupervisorPin(e.target.value)}
                  placeholder="الافتراضي: awdrgyjilp"
                  className="w-full px-4 py-2.5 text-xs font-mono bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 text-center"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-505 mb-1.5 mr-1 flex items-center gap-1">
                  <Lock className="w-3 h-3 text-red-500" />
                  <span>رمز التحكم الثاني (المالك المطور الشامل):</span>
                </label>
                <input
                  type="text"
                  value={masterPin}
                  onChange={(e) => setMasterPin(e.target.value)}
                  placeholder="الافتراضي: awdrgyjilplouyking"
                  className="w-full px-4 py-2.5 text-xs font-mono bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 text-center text-red-500 font-bold"
                />
              </div>
            </div>

            <div className="bg-slate-50 dark:bg-slate-950 p-4 rounded-2xl border border-slate-100 dark:border-slate-850 space-y-2">
              <label className="block text-[11px] font-bold text-slate-705 dark:text-slate-300 flex items-center gap-1.5">
                <Sliders className="w-4 h-4 text-emerald-500" />
                <span>الرمز السري العام لتسجيل الطلاب الجدد (School PIN):</span>
              </label>
              <input
                type="text"
                value={schoolPinCode}
                onChange={(e) => setSchoolPinCode(e.target.value)}
                placeholder="اتركه فارغاً لكي ينضم الطلاب الجدد بدون طلب رمز"
                className="w-full px-4 py-2.5 text-xs font-mono bg-white dark:bg-slate-900 text-slate-905 dark:text-white border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 text-center font-bold"
              />
              <p className="text-[10px] text-slate-400 dark:text-slate-500">
                💡 ميزة التسجيل الذكي: إذا أدخلت كوداً هنا، سيُطالب أي طالب جديد يُسجل اسمه لأول مرة بإدخاله. أما إذا تركت هذا الحقل فارغاً، فيمكن لأي مستخدم جديد الانضمام والدخول إلى المنصة مباشرة وبسهولة تامة بدون طلب رمز!
              </p>
            </div>

            {/* Direct Login / Disable Account Creation Toggle */}
            <div className="bg-slate-50 dark:bg-slate-950 p-4 rounded-2xl border border-slate-100 dark:border-slate-850 space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-[11px] font-bold text-slate-705 dark:text-slate-300 flex items-center gap-1.5">
                  <Sliders className="w-4 h-4 text-rose-500" />
                  <span>إيقاف إنشاء حساب وتفعيل الدخول المباشر بالاسم والباسوورد:</span>
                </label>
                <input
                  type="checkbox"
                  checked={disableAccountCreation}
                  onChange={(e) => setDisableAccountCreation(e.target.checked)}
                  className="w-4 h-4 accent-rose-500 cursor-pointer shrink-0"
                />
              </div>
              <p className="text-[10px] text-slate-400 dark:text-slate-500 leading-relaxed">
                💡 عند تفعيل هذا الخيار، سيتم إلغاء الحاجة لأكواد تفعيل أو تفعيل المشرف للطلاب الجدد. سيقوم الطلاب بالدخول بكتابة اسمهم الكامل مع أي باسوورد من اختيارهم، وسيقوم النظام فوراً بحفظ بياناتهم مدى الحياة حتى تحذفهم يدوياً!
              </p>
            </div>

            {/* Quiz Auto-Advance Duration Settings */}
            <div className="bg-slate-50 dark:bg-slate-950 p-4 rounded-2xl border border-slate-100 dark:border-slate-850 space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-[11px] font-bold text-slate-705 dark:text-slate-300 flex items-center gap-1.5 animate-none">
                  <Sliders className="w-4 h-4 text-indigo-500" />
                  <span>تأخير الانتقال التلقائي للسؤال التالي (بالثواني):</span>
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    min="1"
                    max="60"
                    value={quizAutoAdvanceDelay}
                    onChange={(e) => setQuizAutoAdvanceDelay(Math.max(1, Number(e.target.value)))}
                    className="w-16 px-2 py-1.5 text-xs text-center bg-white dark:bg-slate-900 border border-slate-205 dark:border-slate-800 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 font-bold"
                  />
                  <span className="text-xs text-slate-400">ثانية</span>
                </div>
              </div>
              <p className="text-[10px] text-slate-400 dark:text-slate-500 leading-relaxed">
                ⏰ لتوفير ميزة الانتقال العبقرية والسريعة، بمجرد أن يختار الطالب أحد الخيارات، سيتحقق الاختبار في الحال من الإجابة، يلوّن خيار الإجابة باللون الموفق، ثم ينتقل تلقائياً للسؤال التالي بعد عدد الثواني المحدد هنا دون الحاجة للنقر على أي أزرار!
              </p>
            </div>

            <p className="text-[10px] text-slate-400">تنبيه: تحديث هذه الرموز يحفظها مباشرة بالخادم، بحيث يحتاج أي مستخدم للرمز الجديد في كافة المتصفحات فوراً.</p>
          </div>

          {error && <span className="text-xs text-rose-500 font-bold block">{error}</span>}
          {success && (
            <span className="text-xs text-green-500 font-bold flex items-center gap-1.5 justify-end">
              <CheckCircle className="w-4.5 h-4.5 text-green-500" />
              <span>تم حفظ هويتك المرئية ورموز المرور وتحديثها على الخادم!</span>
            </span>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-xs transition cursor-pointer flex items-center justify-center gap-1.5 shadow-md"
          >
            {loading ? (
              <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <span>حفظ وتعميم التعديلات التأمينية والهوية</span>
            )}
          </button>

        </form>
      </div>

    </div>
  );
}
