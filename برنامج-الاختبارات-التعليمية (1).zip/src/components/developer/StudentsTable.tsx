import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../../context/AppContext';
import { getDevToken } from '../../lib/devToken';
import { 
  Users, Trophy, Calendar, RefreshCw, Trash2, Ban, 
  Send, Megaphone, ShieldAlert, CheckCircle2, AlertOctagon, HelpCircle,
  MessageSquare, User, X
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function StudentsTable() {
  const { students, progress, privateMessages, refreshData, kickedStudents } = useApp();

  // Custom Ban Modal states
  const [customBanStudentId, setCustomBanStudentId] = useState<string | null>(null);
  const [banUnit, setBanUnit] = useState<'minutes' | 'hours' | 'days'>('minutes');
  const [banDurationValue, setBanDurationValue] = useState<number>(30);
  const [customBannedReason, setCustomBannedReason] = useState('بسبب مخالفة لوائح الفصول ومراجعة المشرف');

  // Active chat state for developer
  const [activeChatStudent, setActiveChatStudent] = useState<any | null>(null);
  const [chatMessages, setChatMessages] = useState<any[]>([]);
  const [chatText, setChatText] = useState('');
  const [chatLoading, setChatLoading] = useState(false);
  const chatEndRef = useRef<HTMLDivElement | null>(null);

  // Poll chats
  useEffect(() => {
    if (!activeChatStudent) return;
    let active = true;

    const fetchChatMessages = async (silent = false) => {
      try {
        const res = await fetch(`/api/private-messages?studentId=${encodeURIComponent(activeChatStudent.id)}`);
        if (res.ok && active) {
          const data = await res.json();
          setChatMessages(data);
        }
      } catch (err) {
        console.error(err);
      }
    };

    fetchChatMessages();
    const interval = setInterval(() => {
      fetchChatMessages(true);
    }, 1500);

    return () => {
      active = false;
      clearInterval(interval);
    };
  }, [activeChatStudent]);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages]);

  const handleSendResponse = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatText.trim() || !activeChatStudent) return;

    setChatLoading(true);
    const textToSend = chatText.trim();
    setChatText('');

    try {
      const res = await fetch('/api/private-messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          studentId: activeChatStudent.id,
          sender: 'developer',
          text: textToSend,
          token: getDevToken() || 'awdrgyjilp-supervisor-token'
        })
      });
      if (res.ok) {
        const newMsg = await res.json();
        setChatMessages(prev => [...prev, newMsg]);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setChatLoading(false);
    }
  };

  // Control inputs
  const [loadingAction, setLoadingAction] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  // Local state for direct messages
  const [targetStudentId, setTargetStudentId] = useState<string>('');
  const [directText, setDirectText] = useState('');
  const [directType, setDirectType] = useState<'info' | 'warning' | 'congratulations' | 'alert'>('info');

  // Local state for broadcast
  const [broadcastText, setBroadcastText] = useState('');
  const [broadcastType, setBroadcastType] = useState<'info' | 'warning' | 'congratulations' | 'alert'>('info');

  // Custom Ban values
  const [bannedReason, setBannedReason] = useState('');

  // Handle generic API dev-action dispatcher
  const dispatchDevAction = async (action: string, payload: any) => {
    setSuccessMsg('');
    setErrorMsg('');
    const actionKey = `${action}_${Date.now()}`;
    setLoadingAction(actionKey);

    const token = getDevToken();

    try {
      const response = await fetch('/api/dev-action', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token, action, payload })
      });

      const data = await response.json();

      if (response.ok) {
        setSuccessMsg('تم تنفيذ الإجراء التعليمي بالخادم بنجاح وبثه حياً لجميع الطلاب!');
        setTimeout(() => setSuccessMsg(''), 4000);
        refreshData();
      } else {
        setErrorMsg(data.error || 'فشل تنفيذ الإجراء بالخادم.');
        setTimeout(() => setErrorMsg(''), 4500);
      }
    } catch (err) {
      setErrorMsg('خطأ بالشبكة أثناء إرسال تعليمات التحكم.');
    } finally {
      setLoadingAction(null);
    }
  };

  const handleKick = (studentId: string, name: string) => {
    dispatchDevAction('kick_student', { studentId });
  };

  const handleBan = (studentId: string, minutes: number, reasonText: string) => {
    const reason = reasonText.trim() || 'بسبب سوء السلوك ومخالفة لوائح المناهج';
    dispatchDevAction('ban_student', { studentId, durationMinutes: minutes, reason });
  };

  const handleApplyCustomBan = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customBanStudentId) return;
    
    let finalMinutes = Number(banDurationValue) || 1;
    if (banUnit === 'hours') {
      finalMinutes = finalMinutes * 60;
    } else if (banUnit === 'days') {
      finalMinutes = finalMinutes * 1440;
    }

    handleBan(customBanStudentId, finalMinutes, customBannedReason);
    setCustomBanStudentId(null);
  };

  const handleMessageSend = (studentId: string) => {
    if (!directText.trim()) return;
    dispatchDevAction('message_student', {
      studentId,
      text: directText.trim(),
      type: directType
    });
    setDirectText('');
    setTargetStudentId('');
  };

  const handleBroadcast = () => {
    if (!broadcastText.trim()) return;
    dispatchDevAction('broadcast_global_message', {
      text: broadcastText.trim(),
      type: broadcastType
    });
    setBroadcastText('');
  };

  return (
    <div className="space-y-6 text-right" dir="rtl">
      
      {/* Toast/Alert Boxes */}
      {successMsg && (
        <div className="p-4 bg-green-500/10 text-green-600 border border-green-500/20 rounded-2xl flex items-center gap-2 text-xs font-bold transition-all">
          <CheckCircle2 className="w-4 h-4 text-green-500 shrink-0" />
          <span>{successMsg}</span>
        </div>
      )}
      {errorMsg && (
        <div className="p-4 bg-rose-500/10 text-rose-500 border border-rose-500/25 rounded-2xl flex items-center gap-2 text-xs font-bold transition-all">
          <AlertOctagon className="w-4 h-4 text-rose-500 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {/* Top action grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pb-2">
        
        {/* Card 1: Broadcast direct notification overlay screen */}
        <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-3xl p-5 shadow-sm space-y-4">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-amber-500/10 text-amber-500 rounded-xl">
              <Megaphone className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-slate-800 dark:text-white">جديد: بث تنبيه عاجل يظهر فوراً لجميع النشطين</h4>
              <p className="text-[10px] text-slate-400">بث شاشة توقف منبثقة مع تجميد فوري لجميع الطلاب بدون أي تحديث للصفحة!</p>
            </div>
          </div>

          <div className="space-y-3">
            <textarea
              value={broadcastText}
              onChange={(e) => setBroadcastText(e.target.value)}
              placeholder="اكتب رسالة البث العام هنا... (مثال: يرجى التركيز في الكويز الحالي، نقاط مضاعفة!)"
              className="w-full h-20 p-3 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white border border-slate-150 dark:border-slate-850 rounded-xl resize-none focus:outline-none focus:ring-1 focus:ring-amber-500 text-xs leading-relaxed"
            />

            <div className="flex flex-wrap items-center justify-between gap-2.5">
              <div className="flex items-center gap-1.5">
                <span className="text-[10px] text-slate-400">نمط التنبيه:</span>
                <select
                  value={broadcastType}
                  onChange={(e) => setBroadcastType(e.target.value as any)}
                  className="bg-slate-50 dark:bg-slate-950 text-slate-700 dark:text-slate-300 border border-slate-100 dark:border-slate-800 rounded-lg p-1.5 text-[10px] font-bold outline-none"
                >
                  <option value="info">إرشادي مسالم (أزرق)</option>
                  <option value="warning">تحذيري صارم (برتقالي)</option>
                  <option value="congratulations">احتفالي ومكافأة (ذهبي/أخضر)</option>
                  <option value="alert">إنذار أمني قاطع (أحمر)</option>
                </select>
              </div>

              <button
                onClick={handleBroadcast}
                disabled={!broadcastText.trim() || !!loadingAction}
                className="px-4 py-2 bg-amber-500 hover:bg-amber-600 disabled:bg-slate-200 text-white font-bold rounded-xl text-xs transition flex items-center gap-1 cursor-pointer"
              >
                <span>شغل بث التنبيه كمدير</span>
                <Send className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>

        {/* Card 2: Send Direct letter to specifically selected user */}
        <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-3xl p-5 shadow-sm space-y-4">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-blue-500/10 text-blue-500 rounded-xl">
              <Send className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-slate-800 dark:text-white">إرسال رسالة توجيهية خاصة لطالب محدد</h4>
              <p className="text-[10px] text-slate-400">وجه تنبيهاً أو تشجيعاً لطالب بمفرده يظهر كشعار بمنتصف شاشته فوراً:</p>
            </div>
          </div>

          <div className="space-y-2.5">
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-[10px] text-slate-400 mb-1">اختر اسم الطالب المتلقي:</label>
                <select
                  value={targetStudentId}
                  onChange={(e) => setTargetStudentId(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-950 text-slate-700 dark:text-slate-200 border border-slate-150 dark:border-slate-850 rounded-xl p-2 text-xs font-medium outline-none"
                >
                  <option value="">-- اختر طالب من الفصل --</option>
                  {students.map(s => (
                    <option key={s.id} value={s.id}>{s.display_name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[10px] text-slate-400 mb-1">نوع التنبيه الشخصي:</label>
                <select
                  value={directType}
                  onChange={(e) => setDirectType(e.target.value as any)}
                  className="w-full bg-slate-50 dark:bg-slate-950 text-slate-700 dark:text-slate-200 border border-slate-150 dark:border-slate-850 rounded-xl p-2 text-xs font-medium outline-none"
                >
                  <option value="info">إرشادي عام (أزرق)</option>
                  <option value="warning">تنبيّه هام (برتقالي)</option>
                  <option value="congratulations">تهنئة كبرى (ذهبي)</option>
                  <option value="alert">بطاقة حمراء / إنذار رسمي</option>
                </select>
              </div>
            </div>

            <div className="relative">
              <input
                type="text"
                value={directText}
                onChange={(e) => setDirectText(e.target.value)}
                placeholder="اكتب الرسالة الخاصة للطالب هنا..."
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white border border-slate-150 dark:border-slate-850 rounded-xl outline-none focus:ring-1 focus:ring-blue-500"
              />
            </div>

            <div className="flex justify-end">
              <button
                onClick={() => handleMessageSend(targetStudentId)}
                disabled={!targetStudentId || !directText.trim() || !!loadingAction}
                className="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-200 text-white font-bold rounded-xl text-xs transition flex items-center gap-1 cursor-pointer"
              >
                <span>إرسال الإشعار الفردي</span>
                <Send className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>

      </div>

      {/* Header and counter UI */}
      <div className="flex items-center justify-between">
        <div>
          <h4 className="text-sm font-bold text-slate-800 dark:text-white flex items-center gap-1.5">
            <Users className="w-5 h-5 text-blue-500" />
            <span>لوحة التحكم وإحصاء الفصل الدراسي ({students.length} طالب)</span>
          </h4>
          <p className="text-[11px] text-slate-400">إدارة مباشرة: يمكنك الطرد، الحظر والتشغيل، أو فك الحظر بلحظة:</p>
        </div>
        
        <button onClick={refreshData} className="p-1 px-2.5 bg-slate-100 hover:bg-slate-250 dark:bg-slate-900 rounded-lg text-[10px] font-bold text-slate-500 flex gap-1 cursor-pointer items-center border border-slate-200/50">
          <RefreshCw className="w-3.5 h-3.5" />
          <span>تحديث الحالات</span>
        </button>
      </div>

      {/* Main Students list database table */}
      <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-3xl overflow-hidden shadow-sm">
        {students.length === 0 ? (
          <div className="p-12 text-center text-xs text-slate-400">لا يوجد طلاب مسجلون حتى الآن بالقائمة.</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-right border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50 dark:bg-slate-950 text-slate-400 font-bold border-b border-slate-100 dark:border-slate-805">
                  <th className="p-4 mr-2">اسم الطالب المعتمد المسجل</th>
                  <th className="p-4">حالة الحساب / المخالفات</th>
                  <th className="p-4">إجمالي نقاط XP الكويز</th>
                  <th className="p-4">الأجوبة الصح</th>
                  <th className="p-4">سجل الانضمام</th>
                  <th className="p-4 text-center">إجراءات المالك والتحكم والمخالفات</th>
                </tr>
              </thead>
              <tbody>
                {students.map(stud => {
                  const studProgress = progress.filter(p => p.student_id === stud.id);
                  const totalXp = studProgress.reduce((sum, p) => sum + p.xp, 0);
                  const totalAnswered = studProgress.reduce((sum, p) => sum + p.answered, 0);
                  const totalCorrect = studProgress.reduce((sum, p) => sum + p.correct, 0);

                  // Check if currently banned
                  const isCurrentlyBanned = stud.banned_until && new Date(stud.banned_until) > new Date();
                  const remainingMinutes = isCurrentlyBanned 
                    ? Math.max(1, Math.round((new Date(stud.banned_until!).getTime() - Date.now()) / 60000))
                    : 0;

                  return (
                    <tr key={stud.id} className="border-b border-slate-50 dark:border-slate-900 hover:bg-slate-50/50 dark:hover:bg-slate-950/20 text-slate-700 dark:text-slate-200">
                      <td className="p-4 font-bold text-slate-950 dark:text-white flex items-center gap-2">
                        <div className="w-7 h-7 bg-blue-100 dark:bg-blue-900/40 text-blue-600 dark:text-blue-300 rounded-lg flex items-center justify-center font-black">
                          {stud.display_name.charAt(0)}
                        </div>
                        <div className="flex flex-col">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span className="font-bold">{stud.display_name}</span>
                            
                            {/* Presence Status */}
                            {stud.last_active_at && (Date.now() - new Date(stud.last_active_at).getTime() < 15000) ? (
                              <span className="inline-flex items-center gap-1 text-[9px] text-emerald-600 dark:text-emerald-400 font-extrabold bg-emerald-500/10 px-1.5 py-0.5 rounded-full animate-pulse border border-emerald-500/20">
                                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 shrink-0" />
                                <span>متصل الآن</span>
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 text-[8px] text-slate-400 dark:text-slate-500 bg-slate-100 dark:bg-slate-950 px-1 rounded">
                                آخر نشاط: {stud.last_active_at ? new Date(stud.last_active_at).toLocaleTimeString('ar-EG', {hour: '2-digit', minute: '2-digit'}) : 'منذ فترة'}
                              </span>
                            )}

                            {(() => {
                              const studentMsgs = (privateMessages || []).filter(m => m.student_id === stud.id);
                              if (studentMsgs.length > 0) {
                                const last = studentMsgs[studentMsgs.length - 1];
                                if (last.sender === 'student') {
                                  return (
                                    <span className="inline-flex h-2 w-2 rounded-full bg-emerald-500 animate-pulse" title="رسالة جديدة غير مقروءة من الطالب!" />
                                  );
                                }
                              }
                              return null;
                            })()}
                          </div>
                          <span className="text-[9px] text-slate-400 select-all font-mono">ID: {stud.id}</span>
                          
                          {/* Devices registered under this student */}
                          {stud.registered_devices && stud.registered_devices.length > 0 && (
                            <div className="mt-1 flex flex-col gap-0.5 text-[8px] text-slate-400 bg-slate-50 dark:bg-slate-950 p-1 rounded border border-slate-100 dark:border-slate-850/50 max-w-[200px]" dir="rtl">
                              <span className="font-bold text-slate-500">💻 الأجهزة المسجلة ({stud.registered_devices.length}):</span>
                              {stud.registered_devices.map((dev: string, idx: number) => {
                                const shortDev = dev.length > 25 ? dev.slice(0, 25) + '...' : dev;
                                return (
                                  <span key={idx} className="font-mono text-slate-500 truncate" title={dev}>
                                    • {shortDev}
                                  </span>
                                );
                              })}
                            </div>
                          )}

                          {(() => {
                            const studentMsgs = (privateMessages || []).filter(m => m.student_id === stud.id);
                            if (studentMsgs.length > 0) {
                              const last = studentMsgs[studentMsgs.length - 1];
                              return (
                                <span className={`text-[10px] mt-0.5 truncate max-w-[150px] font-medium leading-none ${
                                  last.sender === 'student' ? 'text-emerald-600 dark:text-emerald-400 font-bold' : 'text-slate-400 dark:text-slate-500'
                                }`}>
                                  {last.sender === 'student' ? '👤 ' : '💻 '}
                                  {last.text}
                                </span>
                              );
                            }
                            return null;
                          })()}
                        </div>
                      </td>
                      
                      <td className="p-4">
                        <div className="flex flex-col gap-0.5">
                          {isCurrentlyBanned ? (
                            <span className="inline-flex items-center gap-1 text-[10px] text-rose-500 font-bold bg-rose-50 dark:bg-rose-950/20 px-2 py-0.5 rounded-md border border-rose-200/30">
                              <Ban className="w-3 h-3" />
                              <span>محظور (متبقي {remainingMinutes} دقيقة)</span>
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 text-[10px] text-green-500 font-bold bg-green-50 dark:bg-green-950/20 px-2 py-0.5 rounded-md border border-green-250/30">
                              <CheckCircle2 className="w-3 h-3" />
                              <span>حساب نشط بالكامل</span>
                            </span>
                          )}

                          {stud.warning_attempts && stud.warning_attempts > 0 ? (
                            <span className="inline-flex items-center text-[9px] text-amber-500 font-bold">
                              <ShieldAlert className="w-3 h-3 ml-0.5" />
                              <span>محاولات اختراق: {stud.warning_attempts}</span>
                            </span>
                          ) : null}
                        </div>
                      </td>

                      <td className="p-4 font-bold font-mono text-amber-500 flex items-center gap-1 mt-1">
                        <Trophy className="w-3.5 h-3.5 text-amber-500" />
                        <span>{totalXp} XP</span>
                      </td>

                      <td className="p-4 font-medium">
                        <span className="text-slate-500 dark:text-slate-300 font-mono font-bold">
                          {totalCorrect} صح من {totalAnswered}
                        </span>
                      </td>

                      <td className="p-4 text-slate-400">
                        <div className="flex items-center gap-1 text-[10px]">
                          <Calendar className="w-3.5 h-3.5" />
                          <span>{new Date(stud.created_at).toLocaleDateString('ar-EG')}</span>
                        </div>
                      </td>

                      <td className="p-4">
                        <div className="flex items-center justify-center gap-2">
                          
                          {/* Live Chat with Student trigger */}
                          <button
                            onClick={async () => {
                              setActiveChatStudent(stud);
                              
                              // Automatically send "أنا هو المطور" if not already sent
                              const msgs = (privateMessages || []).filter(m => m.student_id === stud.id);
                              const alreadySentIntro = msgs.some(m => m.sender === 'developer' && m.text === 'أنا هو المطور');
                              
                              if (!alreadySentIntro) {
                                try {
                                  await fetch('/api/private-messages', {
                                    method: 'POST',
                                    headers: { 'Content-Type': 'application/json' },
                                    body: JSON.stringify({
                                      studentId: stud.id,
                                      sender: 'developer',
                                      text: 'أنا هو المطور',
                                      token: 'awdrgyjilp-devms-token'
                                    })
                                  });
                                  refreshData();
                                } catch (e) {
                                  console.error("Failed to send intro message", e);
                                }
                              }
                            }}
                            title="فتح خط الدردشة المغلق والخاص مع الطالب"
                            className="p-1.5 bg-sky-50 hover:bg-sky-100 dark:bg-sky-950/30 text-sky-600 dark:text-sky-400 rounded-lg cursor-pointer border border-sky-200/20 transition flex items-center justify-center relative"
                          >
                            <MessageSquare className="w-3.5 h-3.5" />
                            {(() => {
                              const studentMsgs = (privateMessages || []).filter(m => m.student_id === stud.id);
                              if (studentMsgs.length > 0) {
                                const last = studentMsgs[studentMsgs.length - 1];
                                if (last.sender === 'student') {
                                  return (
                                    <span className="absolute -top-1 -left-1 flex h-2.5 w-2.5">
                                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                                      <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
                                    </span>
                                  );
                                }
                              }
                              return null;
                            })()}
                          </button>

                          {/* Quick Message trigger */}
                          <button
                            onClick={() => {
                              setTargetStudentId(stud.id);
                              setDirectText('أحسنت يا بطل استمر على هذا الأداء العالي!');
                            }}
                            title="إرسال تنبيه شخصي سريع"
                            className="p-1.5 bg-slate-50 hover:bg-slate-100 dark:bg-slate-950 dark:hover:bg-slate-900 rounded-lg text-slate-500 hover:text-blue-500 cursor-pointer border border-slate-100 dark:border-slate-800 transition"
                          >
                            <Send className="w-3.5 h-3.5" />
                          </button>

                          {isCurrentlyBanned ? (
                            <button
                              onClick={() => handleBan(stud.id, 0, '')}
                              title="فك الحظر الفوري"
                              className="px-3 py-1.5 bg-green-500 hover:bg-green-600 dark:bg-green-600 dark:hover:bg-green-700 text-white font-bold rounded-xl text-[10px] cursor-pointer transition flex items-center gap-1 shadow-sm"
                            >
                              <CheckCircle2 className="w-3.5 h-3.5 text-white" />
                              <span>فك كتم الحظر</span>
                            </button>
                          ) : (
                            <button
                              onClick={() => {
                                setCustomBanStudentId(stud.id);
                                if (bannedReason) setCustomBannedReason(bannedReason);
                              }}
                              title="تحديد حظر مخصص بالأيام أو الساعات أو الدقائق"
                              className="px-3 py-1.5 bg-amber-500 hover:bg-amber-600 text-white font-bold rounded-xl text-[10px] cursor-pointer transition flex items-center gap-1 shadow-sm"
                            >
                              <Ban className="w-3.5 h-3.5" />
                              <span>فرض حظر...</span>
                            </button>
                          )}

                          {/* Kick completely */}
                          <button
                            onClick={() => handleKick(stud.id, stud.display_name)}
                            title="حذف وطرد الطالب بالكامل من المنصة"
                            className="p-1.5 bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/20 hover:bg-rose-500 hover:text-white rounded-lg text-rose-500 cursor-pointer border border-rose-100 dark:border-rose-900/30 transition flex items-center justify-center"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>

                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Kicked Students Registry section */}
      <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-4">
        <h4 className="text-xs font-black text-slate-800 dark:text-rose-400 flex items-center gap-1.5 border-b border-slate-50 dark:border-slate-850 pb-3">
          <ShieldAlert className="w-4 h-4 text-rose-550 animate-pulse" />
          <span>سجل وقائمة الطلاب المطرودين من الفصل الدراسي الحقيقي ({kickedStudents?.length || 0} طالب مطرود)</span>
        </h4>
        <p className="text-[10px] text-slate-400">أي طالب مطرود لن يستطيع الولوج إلى الدروس أو الامتحانات حتى يقوم المشرف أو المطور بإلغاء طرده يدويًا مدمجاً:</p>

        {(!kickedStudents || kickedStudents.length === 0) ? (
          <div className="p-8 text-center bg-slate-50 dark:bg-slate-950 border border-slate-100 dark:border-slate-850 rounded-2xl">
            <span className="text-xl">✅</span>
            <p className="text-[10.5px] font-bold text-slate-500 mt-1">لا يوجد طلاب مطرودين حالياً بالبوابة. تجربة الدراسة هادئة وخالية من المخالفات.</p>
          </div>
        ) : (
          <div className="overflow-x-auto border border-slate-100 dark:border-slate-850 rounded-2xl">
            <table className="w-full text-right border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50 dark:bg-slate-950 text-slate-500 font-black border-b border-slate-100 dark:border-slate-850">
                  <th className="p-3">اسم الطالب المطرود</th>
                  <th className="p-3">المعرف وبصمة الجهاز</th>
                  <th className="p-3">رمز تفعيل الدخول</th>
                  <th className="p-3 text-center">الإجراءات والتحكم</th>
                </tr>
              </thead>
              <tbody>
                {kickedStudents.map((stud) => (
                  <tr key={stud.id} className="border-b border-slate-100 dark:border-slate-850 hover:bg-slate-50/50">
                    <td className="p-3 font-bold text-slate-800 dark:text-slate-200">{stud.display_name}</td>
                    <td className="p-3 font-mono text-[10px] text-slate-500 select-all">{stud.device_id || 'غير معروف'}</td>
                    <td className="p-3 font-mono text-[10.5px] text-amber-500">{stud.entry_code || 'تسجيل مباشر'}</td>
                    <td className="p-3 text-center">
                      <button
                        onClick={() => dispatchDevAction('restore_kicked_student', { studentId: stud.id })}
                        disabled={!!loadingAction}
                        className="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-600 font-bold text-white text-[10px] rounded-xl transition cursor-pointer select-none"
                      >
                        إلغاء الطرد واسترجاع الحساب
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <div className="p-4 bg-slate-50 dark:bg-slate-905 border border-slate-100 dark:border-slate-800 rounded-2xl flex items-start gap-2 text-[10px] text-slate-400 leading-relaxed">
        <HelpCircle className="w-4 h-4 text-blue-500 mt-0.5 shrink-0" />
        <div>
          <span className="font-bold block text-slate-600 dark:text-slate-350">نظام التشديد والمراقبة المباشر:</span>
          <span>
            أي طالب يتم حظره سيتم كتم ومقاطعة اتصاله ووقف الأجوبة لديه لحظيًا دون تحميل، وسيظهر له شاشة معتمة تفيد بحظره من قبل الأستاذ وتاريخ فك الحظر، مما يضمن تجربة اختبارية غاية في الانضباط والموثوقية التامة بالفصول الدراسية مجملاً.
          </span>
          <div className="mt-2 flex items-center gap-1.5">
            <span>تخصيص سبب الحظر المسبق:</span>
            <input
              type="text"
              placeholder="مثال: محاولة الغش أو الدخول بلقاءات غير نظامية"
              value={bannedReason}
              onChange={(e) => setBannedReason(e.target.value)}
              className="bg-white dark:bg-slate-950 text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-800 rounded px-2 py-0.5 text-[9px] font-medium outline-none"
            />
          </div>
        </div>
      </div>

      {/* Developer Private Support Chat Sidebar/Overlay */}
      <AnimatePresence>
        {activeChatStudent && (
          <div className="fixed inset-0 bg-slate-950/40 backdrop-blur-xs z-50 flex justify-end transition-opacity">
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 220 }}
              className="w-full max-w-md h-full bg-white dark:bg-slate-900 border-r border-slate-205 dark:border-slate-800 shadow-2xl flex flex-col overflow-hidden"
            >
              {/* Drawer Header */}
              <div className="p-4 bg-slate-950 text-white flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-9 h-9 rounded-full bg-blue-600 flex items-center justify-center text-white text-xs font-black">
                    <User className="w-4.5 h-4.5" />
                  </div>
                  <div>
                    <h3 className="text-xs font-black">{activeChatStudent.display_name}</h3>
                    <span className="text-[10px] text-slate-400 block font-normal">تواصل خاص 1-على-1 للمطور مع الطالب</span>
                  </div>
                </div>

                <button
                  onClick={() => setActiveChatStudent(null)}
                  className="p-2 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-white transition duration-150 cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Security Hint */}
              <div className="p-2.5 bg-blue-50 dark:bg-slate-950 text-center text-[10px] text-blue-800 dark:text-blue-400 font-bold border-b select-none leading-relaxed">
                🛠️ <strong>بيئة الدعم المغلقة للمشرف:</strong> يمكنك إرشاد الطالب لحل مشكلته الحالية، وتظهر الرسائل لديه منبثقةً في الوقت الحقيقي وبطريقة تفاعلية سلسة.
              </div>

              {/* Shared Chat Feed */}
              <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-slate-50 dark:bg-slate-950 divide-y divide-transparent">
                {chatMessages.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-center p-6 text-slate-400 gap-2">
                    <MessageSquare className="w-12 h-12 text-slate-300 dark:text-slate-850" />
                    <p className="text-xs font-bold text-slate-500">لا توجد رسائل دعم سابقة!</p>
                    <p className="text-[10px] text-slate-450">اكتب رسالة ترحيب أو مساعدة للطالب بالأسفل لتبدأ گفتگو معه.</p>
                  </div>
                ) : (
                  chatMessages.map(m => {
                    const isDev = m.sender === 'developer';
                    return (
                      <div
                        key={m.id}
                        className={`flex flex-col pt-2 ${isDev ? 'items-end' : 'items-start'}`}
                      >
                        <div className={`px-3.5 py-2 rounded-2xl max-w-[85%] text-xs shadow-xs font-semibold leading-relaxed ${
                          isDev
                            ? 'bg-gradient-to-l from-blue-600 to-indigo-650 text-white rounded-br-none text-right'
                            : 'bg-slate-200 dark:bg-slate-800 text-slate-800 dark:text-slate-250 rounded-bl-none text-right'
                        }`}>
                          {m.text}
                        </div>
                        <span className="text-[9px] text-slate-400 mt-0.5 px-1 font-normal font-mono">
                          {new Date(m.created_at).toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                    );
                  })
                )}
                <div ref={chatEndRef} />
              </div>

              {/* Reply Form Foot */}
              <form onSubmit={handleSendResponse} className="p-3 bg-white dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800 flex gap-2">
                <input
                  type="text"
                  value={chatText}
                  onChange={(e) => setChatText(e.target.value)}
                  placeholder={`اكتب ردّك هنا إلى ${activeChatStudent.display_name}...`}
                  disabled={chatLoading}
                  className="flex-1 px-4 py-2.5 bg-slate-50 dark:bg-slate-950 text-xs text-slate-800 dark:text-slate-100 border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-none"
                />
                <button
                  type="submit"
                  disabled={chatLoading || !chatText.trim()}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1 cursor-pointer disabled:opacity-40"
                >
                  <span>إرسال</span>
                  <Send className="w-3.5 h-3.5 transform rotate-180" />
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Custom Ban Duration Modal */}
      {customBanStudentId && (() => {
        const targetStudent = [...students, ...(kickedStudents || [])].find(s => s.id === customBanStudentId);
        return (
          <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-xs z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="w-full max-w-md bg-white dark:bg-slate-900 border border-slate-150 dark:border-slate-800 p-6 rounded-3xl space-y-4 text-right"
              dir="rtl"
            >
              <div className="w-12 h-12 bg-amber-500/10 text-amber-500 rounded-3xl mx-auto flex items-center justify-center border border-amber-500/20 mb-2">
                <Ban className="w-6 h-6" />
              </div>

              <div className="text-center space-y-1">
                <h4 className="text-slate-900 dark:text-white font-black text-base">إصدار قرار حظر وحجب مخصص</h4>
                <p className="text-xs text-slate-400 leading-normal">
                  أنت بصدد معاقبة وحظر الطالب <strong className="text-slate-700 dark:text-slate-300">"{targetStudent?.display_name || 'غير معروف'}"</strong>. الرجاء تحديد الصلاحية الزمنية للخصم أدناه:
                </p>
              </div>

              <form onSubmit={handleApplyCustomBan} className="space-y-4">
                
                {/* Duration Value and Unit Selectors */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-slate-500 mr-1">الفترة الزمنية للحظر المطلوبة:</label>
                  <div className="flex gap-2">
                    <input
                      type="number"
                      min="1"
                      required
                      value={banDurationValue}
                      onChange={(e) => setBanDurationValue(Math.max(1, parseInt(e.target.value) || 1))}
                      className="w-2/5 px-3 py-2.5 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white border border-slate-250 dark:border-slate-800 rounded-xl focus:outline-none focus:ring-1 focus:ring-amber-500 text-center text-xs font-bold"
                    />
                    <select
                      value={banUnit}
                      onChange={(e) => setBanUnit(e.target.value as any)}
                      className="w-3/5 px-3 py-2.5 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white border border-slate-250 dark:border-slate-800 rounded-xl focus:outline-none focus:ring-1 focus:ring-amber-500 text-center text-xs font-bold cursor-pointer"
                    >
                      <option value="minutes">⏱️ دقائق (Minutes)</option>
                      <option value="hours">⏰ ساعات (Hours)</option>
                      <option value="days">📅 أيام (Days)</option>
                    </select>
                  </div>
                </div>

                {/* Reason Value */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-slate-500 mr-1">سبب الحظر والعقوبة المقيدة:</label>
                  <input
                    type="text"
                    required
                    value={customBannedReason}
                    onChange={(e) => setCustomBannedReason(e.target.value)}
                    placeholder="مثال: مخالفة لوائح الفصول والتشويش"
                    className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white border border-slate-250 dark:border-slate-800 rounded-xl focus:outline-none focus:ring-1 focus:ring-amber-500 text-xs"
                  />
                </div>

                {/* Action buttons */}
                <div className="flex gap-2 pt-2">
                  <button
                    type="submit"
                    className="flex-1 py-3 bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold rounded-xl shadow-md transition cursor-pointer flex items-center justify-center gap-1"
                  >
                    <Ban className="w-4 h-4" />
                    <span>تطبيق قرار الحظر</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setCustomBanStudentId(null)}
                    className="px-4 py-3 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-750 text-slate-500 dark:text-slate-300 text-xs font-bold rounded-xl transition cursor-pointer"
                  >
                    إلغاء
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        );
      })()}

    </div>
  );
}
