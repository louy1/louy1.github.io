import { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { getDevToken } from '../../lib/devToken';
import { parseQuestionsText } from '../../lib/parser';
import { Question } from '../../types';
import { FileText, Play, CheckCircle, AlertTriangle, Trash2, HelpCircle, Eye, RefreshCw, Layers, Copy, Check, X, ShieldAlert, Lightbulb, Upload, Link, PlusCircle, Film, Image as ImageIcon } from 'lucide-react';
import { motion } from 'motion/react';

export default function ContentEditor() {
  const { sections, questions, refreshData, setQuestions } = useApp();
  
  // States
  const [selectedSectionId, setSelectedSectionId] = useState(sections[0]?.id || '');
  const [rawText, setRawText] = useState(
    `1. ما هو ناتج ضرب 6 في 8؟\nأ. 42\nب. 48\nج. 54\nب# *+5 *-1`
  );
  const [editingQuestionId, setEditingQuestionId] = useState<string | null>(null);
  
  // Parser outputs
  const [parsedQuestions, setParsedQuestions] = useState<any[]>([]);
  const [parseErrors, setParseErrors] = useState<any[]>([]);
  const [hasParsed, setHasParsed] = useState(false);
  const [loading, setLoading] = useState(false);
  const [successMsg, setSuccessMsg] = useState('');

  // Simulator/Preview states
  const [previewIndex, setPreviewIndex] = useState(0);
  const [simulatorChoice, setSimulatorChoice] = useState<string | null>(null);
  const [simulatorIsSubmitted, setSimulatorIsSubmitted] = useState(false);
  const [simVideoOpen, setSimVideoOpen] = useState(false);

  // Live media helper states
  const [editingTagIndex, setEditingTagIndex] = useState<number | null>(null);
  const [manualUrlInput, setManualUrlInput] = useState('');
  const [isPreviewModalOpen, setIsPreviewModalOpen] = useState(false);
  const [activePreviewUrl, setActivePreviewUrl] = useState('');

  // Extract media tags from raw text
  const extractMediaTags = (text: string) => {
    const lines = text.split(/\r?\n/);
    const tags: any[] = [];
    
    for (let i = 0; i < lines.length; i++) {
      const rawLine = lines[i];
      const line = rawLine.trim();
      if (!line) continue;
      
      // Check specific Image with number -> e.g. "1.()" or "1.(http://imageUrl)"
      const specificImgMatch = line.match(/^(\d+)\.\s*\(\s*(.*?)\s*\)$/);
      if (specificImgMatch) {
        const qNum = parseInt(specificImgMatch[1], 10);
        tags.push({
          qNum,
          type: 'image',
          value: specificImgMatch[2].trim(),
          lineIndex: i,
          rawLine
        });
        continue;
      }

      // Check specific Video with number -> e.g. "1.!()" or "1.!(http://videoUrl)"
      const specificVidMatch = line.match(/^(\d+)\.\s*!\(\s*(.*?)\s*\)$/);
      if (specificVidMatch) {
        const qNum = parseInt(specificVidMatch[1], 10);
        tags.push({
          qNum,
          type: 'video',
          value: specificVidMatch[2].trim(),
          lineIndex: i,
          rawLine
        });
        continue;
      }
    }
    return tags;
  };

  const detectedTags = extractMediaTags(rawText);

  // Helper to replace tag value
  const updateMediaValue = (tag: any, newValue: string) => {
    const lines = rawText.split(/\r?\n/);
    const oldLine = tag.rawLine;
    let newLine = '';
    if (tag.type === 'image') {
      newLine = `${tag.qNum}.(${newValue})`;
    } else {
      newLine = `${tag.qNum}.!(${newValue})`;
    }
    
    if (lines[tag.lineIndex] && lines[tag.lineIndex].trim() === oldLine.trim()) {
      lines[tag.lineIndex] = newLine;
    } else {
      const foundIdx = lines.findIndex(l => l.trim() === oldLine.trim());
      if (foundIdx !== -1) {
        lines[foundIdx] = newLine;
      }
    }
    
    setRawText(lines.join('\n'));
    setEditingTagIndex(null);
    setManualUrlInput('');
    if (hasParsed) setHasParsed(false);
  };

  // Auto resize and compress local image uploads with HTML5 Canvas (keeps database size extremely light!)
  const handleImageUpload = (tag: any, file: File) => {
    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const MAX_WIDTH = 800; // Optimal resolution
        let width = img.width;
        let height = img.height;
        
        if (width > MAX_WIDTH) {
          height = Math.round((height * MAX_WIDTH) / width);
          width = MAX_WIDTH;
        }
        
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          const compressedBase64 = canvas.toDataURL('image/jpeg', 0.7);
          updateMediaValue(tag, compressedBase64);
        }
      };
      if (event.target?.result) {
        img.src = event.target.result as string;
      }
    };
    reader.readAsDataURL(file);
  };

  // Helper to quickly insert media codes
  const insertQuickMedia = (type: 'image' | 'video') => {
    const lines = rawText.split(/\r?\n/);
    let maxQNum = 0;
    lines.forEach(l => {
      const m = l.match(/^(\d+)\./);
      if (m) {
        const num = parseInt(m[1], 10);
        if (num > maxQNum) maxQNum = num;
      }
    });
    
    const nextNum = maxQNum > 0 ? maxQNum : 1; // Default to current max or 1
    const tagToInsert = type === 'image' ? `\n${nextNum}.()` : `\n${nextNum}.!()`;
    setRawText(prev => prev.trim() + tagToInsert);
  };

  const currentQuestions = questions.filter(q => q.section_id === selectedSectionId);

  const handleParse = () => {
    if (!rawText.trim()) return;
    const result = parseQuestionsText(rawText);
    setParsedQuestions(result.questions);
    setParseErrors(result.errors);
    setHasParsed(true);
    setSuccessMsg('');
    
    // Reset Simulator state
    setPreviewIndex(0);
    setSimulatorChoice(null);
    setSimulatorIsSubmitted(false);
    setSimVideoOpen(false);
  };

  const handleImport = async () => {
    if (parsedQuestions.length === 0 || parseErrors.length > 0) return;
    
    setLoading(true);
    const token = getDevToken();
    let importCount = 0;

    try {
      for (const pq of parsedQuestions) {
        const questionId = (editingQuestionId && parsedQuestions.length === 1)
          ? editingQuestionId
          : `question_${selectedSectionId}_${Math.random().toString(36).substr(2, 9)}`;

        const questionPayload: Question = {
          id: questionId,
          section_id: selectedSectionId,
          raw_text: `${pq.parsed_json.questionText}\n${pq.parsed_json.correctAnswer}#`, // metadata
          parsed_json: pq.parsed_json,
          points_correct: pq.points_correct,
          points_wrong: pq.points_wrong,
          sort: currentQuestions.length + importCount + 1
        };

        const res = await fetch('/api/dev-action', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            token,
            action: 'upsert_question',
            payload: questionPayload
          })
        });

        if (res.ok) {
          importCount++;
        }
      }

      setSuccessMsg(`تم استيراد وحفظ عدد ${importCount} أسئلة تفاعلية بنجاح وبسرعة!`);
      setParsedQuestions([]);
      setHasParsed(false);
      setRawText('');
      setEditingQuestionId(null);
      await refreshData();
    } catch (err) {
      alert('حدث خطأ أثناء إجراء عملية الحفظ التدريجي.');
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteQuestion = async (qId: string) => {
    // Delete instantly and optimistically without any confirmation or waiting!
    setQuestions(prev => prev.filter(q => q.id !== qId));

    const token = getDevToken();
    try {
      await fetch('/api/dev-action', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          token,
          action: 'delete_question',
          payload: { id: qId }
        })
      });
    } catch (e) {
      console.error('Server deletion error', e);
      refreshData();
    }
  };

  const handleEditQuestion = (q: any) => {
    setEditingQuestionId(q.id);
    
    // Create raw text representation of this question
    let text = `1. ${q.parsed_json.questionText}\n`;
    if (q.parsed_json.options && Array.isArray(q.parsed_json.options)) {
      q.parsed_json.options.forEach((opt: any) => {
        text += `${opt.key}. ${opt.text}\n`;
      });
    }
    
    let suffix = `${q.parsed_json.correctAnswer}# *+${q.points_correct} *-${q.points_wrong}`;
    text += suffix;
    
    // Prepend image/video tags if present
    if (q.parsed_json.image_url) {
      text = `1.(${q.parsed_json.image_url})\n` + text;
    }
    if (q.parsed_json.video_url) {
      text = `1.!(${q.parsed_json.video_url})\n` + text;
    }
    
    setRawText(text);
    // Parse instantly to show preview
    const result = parseQuestionsText(text);
    setParsedQuestions(result.questions);
    setParseErrors(result.errors);
    setHasParsed(true);
    setSuccessMsg('جاري تعديل السؤال المختار. قم بإجراء التغييرات المطلوبة بالصندوق ثم اضغط حفظ التعديل!');
  };

  const handleCancelQuestionEdit = () => {
    setEditingQuestionId(null);
    setRawText('');
    setParsedQuestions([]);
    setParseErrors([]);
    setHasParsed(false);
    setSuccessMsg('');
  };

  const loadTemplate = (type: 'math' | 'physics' | 'english') => {
    if (type === 'math') {
      setRawText(
        `1. أوجد قيمة المتغير x في المعادلة التالية: 3x + 12 = 27\nأ. x = 5\nب. x = 6\nج. x = 7\nد. x = 4\nأ# *+6 *-2\n\n2. ما هو الجذر التربيعي للعدد 144؟\nأ. 10\nب. 12\nج. 14\nب# *+5 *-1`
      );
    } else if (type === 'physics') {
      setRawText(
        `1. أيُّ العوامل التالية تتغير طاقة حركة الجسم بتغيره مباشرة؟\nأ. الكتلة والسرعة\nب. الكتلة والارتفاع\nج. الوزن والتسارع\nأ# *+5 *-1`
      );
    } else {
      setRawText(
        `1. Choose the correct past continuous form: "They ____ soundly when the alarm rang."\nأ. was sleeping\nب. sleeping\nج. were sleeping\nد. slept\nج# *+4 *-1`
      );
    }
    setHasParsed(false);
    setSuccessMsg('');
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 text-right" dir="rtl">
      
      {/* Right column: Editor input box */}
      <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 p-6 rounded-3xl shadow-sm space-y-6">
        <div className="space-y-4">
          <div>
            <h4 className="text-base font-bold text-slate-800 dark:text-white flex items-center gap-1.5">
              <FileText className="w-5 h-5 text-blue-500" />
              <span>مترجم ومصنف أسئلة المناهج المطور</span>
            </h4>
            <p className="text-xs text-slate-400 mt-0.5">اكتب الأسئلة تفصيلياً بالتنسيق المطلوب، ثم انقر لتحليل ومعاينتها حياً وتفاعلياً:</p>
          </div>

          {/* New Arabic Guided Instructions Card */}
          <div className="bg-gradient-to-br from-indigo-50 to-blue-50 dark:from-slate-950 dark:to-slate-900 p-5 rounded-2xl border border-indigo-100 dark:border-slate-800 space-y-3">
            <div className="flex items-center gap-1.5 text-indigo-700 dark:text-indigo-400 font-bold text-xs">
              <span className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse" />
              <span>📝 تعليمات إنشاء إختبار بشكل صورة أو بدون صورة:</span>
            </div>
            
            <div className="grid grid-cols-1 gap-2 text-xs text-slate-705 dark:text-slate-300 leading-relaxed font-semibold">
              <div className="p-2.5 bg-white dark:bg-slate-900/50 rounded-xl border border-indigo-50/60 dark:border-slate-800/40 flex items-start gap-2">
                <span className="text-indigo-600 dark:text-indigo-400 font-black">١.</span>
                <p>إن كتبت <code className="px-1.5 py-0.5 bg-slate-100 dark:bg-slate-800 rounded font-mono text-indigo-600 dark:text-indigo-400 font-bold">1.()</code> فمعناته أنك تريد إضافة صورة للسؤال (حيث يمكنك بعدها رفع صورة مخصصة في لوحة المرفقات أدناه).</p>
              </div>

              <div className="p-2.5 bg-white dark:bg-slate-900/50 rounded-xl border border-indigo-50/60 dark:border-slate-800/40 flex items-start gap-2">
                <span className="text-indigo-600 dark:text-indigo-400 font-black">٢.</span>
                <p>لإنشاء سؤال بدون صورة اكتبه هكذا: <code className="px-1.5 py-0.5 bg-slate-100 dark:bg-slate-800 rounded font-mono text-indigo-600 dark:text-indigo-400 font-bold">1. ثم السؤال ثم ؟</code> فقط دون الأقواس.</p>
              </div>

              <div className="p-2.5 bg-white dark:bg-slate-900/50 rounded-xl border border-indigo-50/60 dark:border-slate-800/40 flex items-start gap-2">
                <span className="text-indigo-600 dark:text-indigo-400 font-black">٣.</span>
                <p>لكتابة الاختيارات اكتب: <strong className="text-slate-900 dark:text-white">"حرف ثم نقطة ثم اسم الخيار"</strong>، مثل: <code className="px-1.5 py-0.5 bg-slate-100 dark:bg-slate-800 rounded font-mono text-indigo-600 dark:text-indigo-400 font-bold">أ. خالد</code>.</p>
              </div>

              <div className="p-2.5 bg-white dark:bg-slate-900/50 rounded-xl border border-indigo-50/60 dark:border-slate-800/40 flex items-start gap-2">
                <span className="text-indigo-600 dark:text-indigo-400 font-black">٤.</span>
                <p>لتحديد الإجابة الصحيحة اكتب: <strong className="text-slate-900 dark:text-white">"حرف الخيار الصحيح ثم #"</strong>، مثل: <code className="px-1.5 py-0.5 bg-slate-100 dark:bg-slate-800 rounded font-mono text-indigo-600 dark:text-indigo-400 font-bold">أ#</code> فقط.</p>
              </div>

              <div className="p-2.5 bg-white dark:bg-slate-900/50 rounded-xl border border-indigo-50/60 dark:border-slate-800/40 flex items-start gap-2">
                <span className="text-indigo-600 dark:text-indigo-400 font-black">٥.</span>
                <p>نقاط الإجابة الصحيحة <code className="px-1.5 py-0.5 bg-green-100 dark:bg-green-950/40 text-green-700 dark:text-green-400 rounded font-mono font-bold">*+ رقم</code> ونقاط الإجابة الخاطئة <code className="px-1.5 py-0.5 bg-rose-100 dark:bg-rose-950/40 text-rose-700 dark:text-rose-400 rounded font-mono font-bold">*- رقم</code>، مثل: <code className="px-1 py-0.5 bg-slate-100 dark:bg-slate-800 rounded font-mono text-slate-700 dark:text-slate-300 font-bold">*+5</code> أو <code className="px-1 py-0.5 bg-slate-100 dark:bg-slate-800 rounded font-mono text-slate-700 dark:text-slate-300 font-bold">*-5</code>.</p>
              </div>
            </div>
          </div>
        </div>

        {/* Templates quick action row */}
        <div className="bg-slate-50 dark:bg-slate-950 p-3 rounded-2xl border border-slate-100 dark:border-slate-850 space-y-2">
          <span className="text-[10px] font-bold text-slate-400 dark:text-slate-500 block">قوالب جاهزة سريعة التعبئة:</span>
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => loadTemplate('math')}
              className="px-2.5 py-1.5 bg-blue-50 hover:bg-blue-100 dark:bg-blue-950/40 text-blue-600 dark:text-blue-400 border border-blue-100 dark:border-blue-900/50 rounded-lg text-[10px] font-bold cursor-pointer transition"
            >
              📐 مقرر الرياضيات
            </button>
            <button
              onClick={() => loadTemplate('physics')}
              className="px-2.5 py-1.5 bg-amber-50 hover:bg-amber-100 dark:bg-amber-950/40 text-amber-600 dark:text-amber-400 border border-amber-100 dark:border-amber-900/50 rounded-lg text-[10px] font-bold cursor-pointer transition"
            >
              🪐 مقرر العلوم والفيزياء
            </button>
            <button
              onClick={() => loadTemplate('english')}
              className="px-2.5 py-1.5 bg-purple-50 hover:bg-purple-100 dark:bg-purple-950/40 text-purple-600 dark:text-purple-400 border border-purple-100 dark:border-purple-900/50 rounded-lg text-[10px] font-bold cursor-pointer transition"
            >
              🇬🇧 مقرر اللغة الإنجليزية
            </button>
          </div>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-500 mb-1.5 mr-1">المادة المستهدفة حالياً:</label>
            <select
              value={selectedSectionId}
              onChange={(e) => {
                setSelectedSectionId(e.target.value);
                setSuccessMsg('');
                setHasParsed(false);
              }}
              className="w-full px-3.5 py-2.5 text-sm bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 font-bold"
            >
              {sections.map(s => (
                <option key={s.id} value={s.id}>{s.title}</option>
              ))}
            </select>
          </div>

          <div className="space-y-2">
            <div className="flex justify-between items-center mr-1">
              <label className="block text-xs font-semibold text-slate-500">صندوق تحرير الأسئلة الكلي:</label>
              <div className="flex gap-1.5">
                <button
                  type="button"
                  onClick={() => insertQuickMedia('image')}
                  className="px-2 py-1 bg-blue-50 hover:bg-blue-100 dark:bg-blue-950/40 text-blue-600 dark:text-blue-400 border border-blue-105 dark:border-blue-900/40 rounded-lg text-[9px] font-bold cursor-pointer transition flex items-center gap-1"
                  title="إدراج كود لصورة السؤال الحالي"
                >
                  <PlusCircle className="w-3 h-3" />
                  <span>+ كود صورة ()</span>
                </button>
                <button
                  type="button"
                  onClick={() => insertQuickMedia('video')}
                  className="px-2 py-1 bg-amber-50 hover:bg-amber-100 dark:bg-amber-950/40 text-amber-600 dark:text-amber-400 border border-amber-105 dark:border-amber-900/40 rounded-lg text-[9px] font-bold cursor-pointer transition flex items-center gap-1"
                  title="إدراج كود لفيديو المادة الحالي"
                >
                  <PlusCircle className="w-3 h-3" />
                  <span>+ كود فيديو !()</span>
                </button>
              </div>
            </div>
            <textarea
              id="raw-text-compiler"
              rows={10}
              value={rawText}
              onChange={(e) => {
                setRawText(e.target.value);
                if (hasParsed) setHasParsed(false);
              }}
              placeholder={`شكل الإدخال:\n1. من هو مكتشف الجاذبية؟\nأ. إسحاق نيوتن\nب. ألبرت أينشتاين\nأ# *+5 *-0`}
              className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-800 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 text-right text-sm font-mono leading-relaxed"
            />
          </div>

          {/* Dynamic Active Media Dashboard */}
          {detectedTags.length > 0 && (
            <div className="border border-indigo-100 dark:border-indigo-950/40 bg-indigo-50/10 dark:bg-indigo-950/5 p-4 rounded-2xl space-y-3">
              <div className="flex justify-between items-center text-xs font-black text-indigo-700 dark:text-indigo-400 border-b pb-2 border-indigo-100/50 dark:border-indigo-950/40">
                <span className="flex items-center gap-1.5">
                  <Lightbulb className="w-4 h-4 text-amber-500 animate-pulse" />
                  <span>لوحة الوسائط وإدراج صور الأسئلة الذكية ({detectedTags.length})</span>
                </span>
                <span className="text-[9px] text-slate-400">انقر لرفع ملف مباشر!</span>
              </div>

              <div className="space-y-2 max-h-[220px] overflow-y-auto pr-0.5">
                {detectedTags.map((tag, idx) => {
                  const isEmpty = !tag.value;
                  const isEditing = editingTagIndex === idx;

                  return (
                    <div 
                      key={idx} 
                      className={`p-3 rounded-xl border transition-all text-xs space-y-2 ${
                        isEmpty 
                          ? 'border-amber-200/50 bg-amber-500/5 dark:border-amber-900/20' 
                          : 'border-green-200/50 bg-green-500/5 dark:border-green-950/10'
                      }`}
                    >
                      <div className="flex justify-between items-center">
                        <div className="flex items-center gap-1.5 font-bold">
                          <span className="w-5 h-5 bg-indigo-100 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 rounded-lg text-[10px] flex items-center justify-center font-mono">
                            {tag.qNum}
                          </span>
                          <span className={isEmpty ? 'text-amber-700 dark:text-amber-400' : 'text-green-700 dark:text-green-400'}>
                            {tag.type === 'image' ? '🖼️ صورة السؤال التوضيحية' : '🎥 فيديو السؤال والشرح'}
                          </span>
                        </div>

                        <div className="flex gap-1.5 items-center">
                          {!isEmpty ? (
                            <>
                              <button
                                type="button"
                                onClick={() => {
                                  setActivePreviewUrl(tag.value);
                                  setIsPreviewModalOpen(true);
                                }}
                                className="px-2 py-0.5 bg-white dark:bg-slate-900 border hover:border-indigo-500 text-[10px] font-bold rounded cursor-pointer transition text-indigo-600 dark:text-indigo-400"
                              >
                                معاينة 👀
                              </button>
                              <button
                                type="button"
                                onClick={() => updateMediaValue(tag, '')}
                                className="px-2 py-0.5 bg-rose-50 hover:bg-rose-100 text-rose-600 border border-rose-200 rounded text-[10px] cursor-pointer"
                              >
                                مسح 🗑️
                              </button>
                            </>
                          ) : (
                            <span className="text-[9px] bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-400 px-1.5 py-0.5 rounded font-bold">بانتظار الإدراج</span>
                          )}
                        </div>
                      </div>

                      {/* Actions for Empty Tags */}
                      {isEmpty && !isEditing ? (
                        <div className="flex flex-wrap gap-2 pt-1">
                          {tag.type === 'image' && (
                            <label className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg text-[10px] cursor-pointer inline-flex items-center gap-1 shadow-sm transition">
                              <Upload className="w-3.5 h-3.5" />
                              <span>اختر ملف صورة من جهازك</span>
                              <input
                                type="file"
                                accept="image/*"
                                className="hidden"
                                onChange={(e) => {
                                  if (e.target.files?.[0]) {
                                    handleImageUpload(tag, e.target.files[0]);
                                  }
                                }}
                              />
                            </label>
                          )}

                          <button
                            type="button"
                            onClick={() => {
                              setEditingTagIndex(idx);
                              setManualUrlInput('');
                            }}
                            className="px-3 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 font-bold rounded-lg text-[10px] cursor-pointer inline-flex items-center gap-1 transition"
                          >
                            <Link className="w-3.5 h-3.5" />
                            <span>لصق رابط مباشر</span>
                          </button>
                        </div>
                      ) : null}

                      {/* Manual URL input state */}
                      {isEditing && (
                        <div className="space-y-2 bg-white dark:bg-slate-900 border p-2.5 rounded-lg">
                          <label className="block text-[10px] text-slate-400 font-bold">أدخل رابط الوسائط للويب:</label>
                          <div className="flex gap-1.5">
                            <input
                              type="text"
                              value={manualUrlInput}
                              onChange={(e) => setManualUrlInput(e.target.value)}
                              placeholder={tag.type === 'image' ? 'https://example.com/logo.png' : 'https://youtube.com/watch?v=...'}
                              className="flex-grow px-2 py-1 text-sm bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-800 rounded font-mono text-left focus:outline-none"
                            />
                          </div>
                          <div className="flex gap-1.5 justify-end">
                            <button
                              type="button"
                              onClick={() => setEditingTagIndex(null)}
                              className="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded text-[10px] cursor-pointer font-bold"
                            >
                              إلغاء
                            </button>
                            <button
                              type="button"
                              onClick={() => updateMediaValue(tag, manualUrlInput)}
                              disabled={!manualUrlInput.trim()}
                              className="px-3 py-1 bg-green-600 hover:bg-green-700 text-white rounded text-[10px] font-bold cursor-pointer"
                            >
                              حفظ وتحديث
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          <div className="flex gap-2">
            <button
              id="btn-parse-questions"
              onClick={handleParse}
              className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-xs cursor-pointer transition flex items-center justify-center gap-1.5 flex-grow font-mono"
            >
              <Play className="w-4 h-4 fill-white" />
              <span>{editingQuestionId ? 'ترجمة وتحليل وتدقيق التعديلات' : 'ترجمة وتحليل الأسئلة ومعاينتها'}</span>
            </button>
            {editingQuestionId && (
              <button
                type="button"
                onClick={handleCancelQuestionEdit}
                className="px-4 py-3 bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/20 text-rose-600 rounded-xl text-xs font-bold transition cursor-pointer"
              >
                إلغاء التعديل ❌
              </button>
            )}
          </div>

          {/* Validation report panels */}
          {hasParsed && (
            <div className="space-y-4 p-4 rounded-2xl border" style={{ borderColor: parseErrors.length > 0 ? '#fda4af' : '#6ee7b7', backgroundColor: parseErrors.length > 0 ? '#fff1f2' : '#f0fdf4' }}>
              <div className="flex items-center gap-2 text-sm font-bold">
                {parseErrors.length > 0 ? (
                  <>
                    <AlertTriangle className="w-5 h-5 text-rose-500" />
                    <span className="text-rose-700">تنبيه: وجدنا عيوب بالتنسيق ({parseErrors.length})</span>
                  </>
                ) : (
                  <>
                    <CheckCircle className="w-5 h-5 text-green-500" />
                    <span className="text-green-700 font-bold">ممتاز! تم الترجمة بنجاح ({parsedQuestions.length} سؤال)</span>
                  </>
                )}
              </div>

              {parseErrors.length > 0 ? (
                <div className="space-y-2 max-h-32 overflow-y-auto pr-1">
                  {parseErrors.map((err, i) => (
                    <div key={i} className="text-xs text-rose-600 font-medium">
                      السطر <span className="font-bold underline">{err.lineNum}</span>: {err.message} <code className="bg-white/75 dark:bg-slate-900 px-1 py-0.5 rounded font-mono border text-rose-700 text-[10px]">{err.lineText}</code>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="space-y-4">
                  <p className="text-xs text-green-600 font-medium">جميع المستندات والمقاييس متطابقة وخالية من الأخطاء. يمكنك تأكيد حفظها وتوسيع المقرر فوراً:</p>
                  
                  <button
                    id="btn-confirm-import"
                    onClick={handleImport}
                    disabled={loading}
                    className="w-full py-3 bg-green-600 hover:bg-green-700 text-white font-bold rounded-xl text-xs transition cursor-pointer"
                  >
                    {loading ? 'جاري تصدير التعديلات...' : (editingQuestionId ? 'تأكيد وتحديث السؤال الحالي 💾' : 'تأكيد واستيراد لقاعدة البيانات')}
                  </button>
                </div>
              )}
            </div>
          )}

          {successMsg && (
            <div className="p-4 bg-emerald-50 dark:bg-emerald-950/20 border border-emerald-200 text-emerald-800 dark:text-emerald-400 rounded-xl text-xs font-bold leading-relaxed">
              {successMsg}
            </div>
          )}

        </div>
      </div>

      {/* Left column: Simulator and list */}
      <div className="space-y-6">
        
        {/* INTERACTIVE QUESTION LIVE PREVIEW/SIMULATOR DEVICE */}
        {hasParsed && parsedQuestions.length > 0 && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-indigo-900/5 dark:bg-indigo-950/10 border-2 border-dashed border-indigo-500/20 p-6 rounded-3xl space-y-4"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5 text-indigo-700 dark:text-indigo-400">
                <Eye className="w-5 h-5" />
                <h4 className="text-sm font-black">جهاز محاكاة ومعاينة التفاعل للسؤال</h4>
              </div>
              
              {parsedQuestions.length > 1 && (
                <div className="flex gap-1.5 items-center">
                  <button
                    onClick={() => {
                      setPreviewIndex(Math.max(0, previewIndex - 1));
                      setSimulatorChoice(null);
                      setSimulatorIsSubmitted(false);
                      setSimVideoOpen(false);
                    }}
                    disabled={previewIndex === 0}
                    className="px-2 py-1 bg-white dark:bg-slate-900 border text-xs rounded-lg disabled:opacity-30"
                  >
                    السابق
                  </button>
                  <span className="text-xs text-indigo-700 dark:text-indigo-400 font-mono font-bold">
                    {previewIndex + 1} / {parsedQuestions.length}
                  </span>
                  <button
                    onClick={() => {
                      setPreviewIndex(Math.min(parsedQuestions.length - 1, previewIndex + 1));
                      setSimulatorChoice(null);
                      setSimulatorIsSubmitted(false);
                      setSimVideoOpen(false);
                    }}
                    disabled={previewIndex === parsedQuestions.length - 1}
                    className="px-2 py-1 bg-white dark:bg-slate-900 border text-xs rounded-lg disabled:opacity-30"
                  >
                    التالي
                  </button>
                </div>
              )}
            </div>

            {/* Simulated Question Layout */}
            <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-805 p-5 rounded-2xl space-y-5">
              <div className="flex justify-between items-center text-[10px] text-slate-400 font-bold border-b pb-3 border-slate-50 dark:border-slate-800">
                <span>نموذج محاكاة المعاينة الفعالة للمشرف</span>
                <div className="flex gap-2">
                  <span className="px-1.5 py-0.5 bg-green-50 text-green-600 rounded">+{parsedQuestions[previewIndex].points_correct} XP</span>
                  <span className="px-1.5 py-0.5 bg-rose-50 text-rose-500 rounded">-{parsedQuestions[previewIndex].points_wrong} XP</span>
                </div>
              </div>

              {/* Emulator Image */}
              {parsedQuestions[previewIndex].parsed_json.image_url && (
                <div className="overflow-hidden rounded-xl border border-slate-100 dark:border-slate-800 shadow-sm max-h-[180px] flex items-center justify-center bg-slate-50 dark:bg-slate-950">
                  <img 
                    src={parsedQuestions[previewIndex].parsed_json.image_url} 
                    alt="صورة المعاينة" 
                    className="w-full h-auto max-h-[180px] object-contain transition duration-200"
                    referrerPolicy="no-referrer"
                  />
                </div>
              )}

              <div className="flex items-start justify-between gap-3 font-bold text-sm text-slate-800 dark:text-white leading-relaxed">
                <div className="flex-grow">
                  {parsedQuestions[previewIndex].parsed_json.questionText}
                </div>
                {parsedQuestions[previewIndex].parsed_json.video_url && (
                  <button
                    type="button"
                    onClick={() => setSimVideoOpen(!simVideoOpen)}
                    className={`shrink-0 p-1.5 rounded-lg border cursor-pointer relative flex items-center justify-center ${
                      simVideoOpen
                        ? 'bg-amber-500/10 border-amber-500 text-amber-600 dark:text-amber-400'
                        : 'bg-amber-500/5 border-amber-500/20 text-amber-500'
                    }`}
                    title="معاينة فيديو الشرح"
                  >
                    <span className="absolute top-0 right-0 h-1.5 w-1.5 bg-amber-400 rounded-full"></span>
                    <Lightbulb className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              {/* Simulated Video Player Section */}
              {parsedQuestions[previewIndex].parsed_json.video_url && simVideoOpen && (
                <div className="border border-amber-500/15 bg-amber-500/5 p-3 rounded-xl space-y-2">
                  <div className="flex items-center justify-between text-[10px] text-amber-600 font-bold">
                    <span>💡 فيديو المعاينة للشرح:</span>
                    <button
                      type="button"
                      onClick={() => setSimVideoOpen(false)}
                      className="text-slate-400 hover:text-slate-600"
                    >
                      إغلاق ×
                    </button>
                  </div>
                  <div className="relative aspect-video rounded-lg overflow-hidden bg-black text-[10px] text-white flex items-center justify-center">
                    <span className="p-2 text-center text-slate-300">
                      معاينة الرابط النشط: <code className="block bg-slate-850 p-1 rounded font-mono text-xs text-amber-400 break-all select-all mt-1">{parsedQuestions[previewIndex].parsed_json.video_url}</code>
                    </span>
                  </div>
                </div>
              )}

              {/* Options lists */}
              <div className="space-y-2.5">
                {parsedQuestions[previewIndex].parsed_json.options.map((opt: any) => {
                  const isSelected = simulatorChoice === opt.key;
                  const isCorrect = opt.key === parsedQuestions[previewIndex].parsed_json.correctAnswer;
                  
                  let optStyle = "border-slate-200 hover:border-indigo-500 bg-slate-50/50";
                  
                  if (simulatorIsSubmitted) {
                    if (isCorrect) {
                      optStyle = "border-green-500 bg-green-50 text-green-700 font-bold";
                    } else if (isSelected) {
                      optStyle = "border-rose-500 bg-rose-50 text-rose-700 font-bold";
                    } else {
                      optStyle = "opacity-40 border-slate-100";
                    }
                  } else if (isSelected) {
                    optStyle = "border-indigo-600 bg-indigo-50 text-indigo-700 font-bold ring-2 ring-indigo-500/10";
                  }

                  return (
                    <button
                      key={opt.key}
                      onClick={() => !simulatorIsSubmitted && setSimulatorChoice(opt.key)}
                      className={`w-full p-3 rounded-xl border flex items-center gap-3 text-right text-xs transition-all ${optStyle}`}
                    >
                      <span className={`w-6 h-6 rounded-lg flex items-center justify-center font-bold text-[10px] ${
                        isSelected || (simulatorIsSubmitted && isCorrect) ? 'bg-indigo-600 text-white' : 'bg-slate-200 text-slate-600'
                      }`}>
                        {opt.key}
                      </span>
                      <span>{opt.text}</span>
                    </button>
                  );
                })}
              </div>

              {/* Action buttons inside simulator */}
              <div className="flex items-center justify-between pt-2 border-t border-slate-50 dark:border-slate-800">
                {!simulatorIsSubmitted ? (
                  <button
                    onClick={() => setSimulatorIsSubmitted(true)}
                    disabled={!simulatorChoice}
                    className="px-5 py-2 bg-indigo-600 disabled:opacity-50 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl cursor-pointer"
                  >
                    تأكيد إجابة المعاينة
                  </button>
                ) : (
                  <div className="flex items-center gap-2 justify-between w-full">
                    <span className={`text-xs font-bold ${simulatorChoice === parsedQuestions[previewIndex].parsed_json.correctAnswer ? 'text-green-600' : 'text-rose-500'}`}>
                      {simulatorChoice === parsedQuestions[previewIndex].parsed_json.correctAnswer ? 'إجابة صحيحة (السؤال يعمل!)' : 'إجابة خاطئة!'}
                    </span>
                    <button
                      onClick={() => {
                        setSimulatorChoice(null);
                        setSimulatorIsSubmitted(false);
                      }}
                      className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 dark:text-slate-300 rounded-lg text-[10px] font-bold"
                    >
                      إعادة الاختبار
                    </button>
                  </div>
                )}
              </div>
            </div>
          </motion.div>
        )}

        <div>
          <h4 className="text-base font-bold text-slate-800 dark:text-white flex items-center gap-1.5">
            <HelpCircle className="w-5 h-5 text-blue-500" />
            <span>جرد أسئلة المقرر الدراسي ({currentQuestions.length})</span>
          </h4>
          <p className="text-xs text-slate-400 mt-0.5">قائمة الأسئلة المدرجة نشطاً في هذا المقرر الدراسي:</p>
        </div>

        <div className="space-y-4 max-h-[400px] overflow-y-auto pr-1">
          {currentQuestions.length === 0 ? (
            <div className="p-8 bg-slate-50 dark:bg-slate-900/40 text-center text-xs text-slate-400 rounded-2xl border border-dashed border-slate-100 dark:border-slate-850">
              لا توجد أسئلة مدرجة في هذا القسم بعد.
            </div>
          ) : (
            currentQuestions.map((q, index) => (
              <div
                key={q.id}
                className="p-4 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl flex items-start justify-between shadow-sm gap-4 hover:border-slate-200 transition-all"
              >
                <div className="space-y-2 flex-grow">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 bg-blue-55 dark:bg-blue-950 text-blue-600 dark:text-blue-400 rounded text-xs font-bold font-mono flex items-center justify-center shrink-0">
                      {index + 1}
                    </span>
                    <h5 className="font-bold text-xs text-slate-800 dark:text-white leading-relaxed">{q.parsed_json.questionText}</h5>
                  </div>
                  
                  <div className="flex flex-wrap gap-1.5 text-[10px] text-slate-400">
                    <span className="px-1.5 py-0.5 bg-slate-100 dark:bg-slate-950 rounded font-bold text-slate-500">الإجابة: ({q.parsed_json.correctAnswer})</span>
                    <span className="px-1.5 py-0.5 bg-green-50 dark:bg-green-950/20 text-green-600 font-bold rounded">+{q.points_correct} XP</span>
                    {q.points_wrong > 0 && <span className="px-1.5 py-0.5 bg-rose-50 dark:bg-rose-950/20 text-rose-600 font-bold rounded">-{q.points_wrong} XP</span>}
                  </div>
                </div>

                <div className="flex items-center gap-1.5 self-center shrink-0">
                  <button
                    onClick={() => handleEditQuestion(q)}
                    disabled={loading}
                    className="p-1.5 bg-blue-50 hover:bg-blue-100 dark:bg-slate-800 rounded-lg text-blue-600 dark:text-blue-400 transition cursor-pointer flex items-center gap-1"
                    title="تعديل هذا السؤال"
                  >
                    <span className="text-[10px] font-black">تعديل ⚙️</span>
                  </button>
                  <button
                    onClick={() => handleDeleteQuestion(q.id)}
                    disabled={loading}
                    className="p-1.5 bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/20 rounded-lg text-rose-500 transition cursor-pointer"
                    title="حذف السؤال"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Media Active Preview Dialog */}
      {isPreviewModalOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 p-5 rounded-3xl max-w-lg w-full space-y-4 shadow-2xl relative text-right" dir="rtl">
            <button
              onClick={() => setIsPreviewModalOpen(false)}
              className="absolute top-4 left-4 p-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-900 dark:hover:bg-slate-850 rounded-full text-slate-400 hover:text-slate-700 transition"
            >
              <X className="w-4 h-4" />
            </button>

            <h4 className="text-sm font-black text-slate-800 dark:text-white flex items-center gap-2">
              <Eye className="w-5 h-5 text-indigo-500" />
              <span>معاينة وسيط المادة النشط المرفق:</span>
            </h4>

            <div className="rounded-2xl border bg-slate-50 dark:bg-slate-900 aspect-video overflow-hidden flex items-center justify-center">
              {activePreviewUrl.startsWith('data:image/') || activePreviewUrl.match(/\.(jpeg|jpg|gif|png|webp)/i) ? (
                <img 
                  src={activePreviewUrl} 
                  alt="محتوى معاينة المترجم" 
                  className="w-full h-full object-contain"
                  referrerPolicy="no-referrer"
                />
              ) : (
                <div className="w-full p-4 text-center space-y-2 font-mono">
                  <Film className="w-8 h-8 text-indigo-500 mx-auto" />
                  <p className="text-[11px] text-slate-500">رابط الفيديو المرفق للمقرر:</p>
                  <code className="text-[10px] block bg-slate-105 dark:bg-slate-950 p-2 rounded break-all select-all text-indigo-600 dark:text-indigo-400">{activePreviewUrl}</code>
                </div>
              )}
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={() => setIsPreviewModalOpen(false)}
                className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white dark:bg-white dark:hover:bg-slate-100 dark:text-black font-bold text-xs rounded-xl cursor-pointer"
              >
                إغلاق المعاينة
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
