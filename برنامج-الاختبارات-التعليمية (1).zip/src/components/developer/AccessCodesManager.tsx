import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  Key, UserPlus, Trash2, ShieldCheck, Sparkles, Users, RefreshCw, Sliders, Clipboard
} from 'lucide-react';
import { getDevToken } from '../../lib/devToken';

interface PreRegisteredCode {
  id: string;
  student_name: string;
  code: string;
  duration_days: number;
  duration_months: number;
  duration_years: number;
  max_devices: number;
  is_used: boolean;
  registered_student_id?: string;
  registered_name?: string;
  created_at: string;
}

export default function AccessCodesManager() {
  const { db, refreshData } = useApp();
  
  // Custom manual code states
  const [studentName, setStudentName] = useState('');
  const [codeValue, setCodeValue] = useState('');
  const [days, setDays] = useState(1);
  const [months, setMonths] = useState(0);
  const [years, setYears] = useState(0);
  const [maxDevices, setMaxDevices] = useState(1);
  
  const [formError, setFormError] = useState('');
  const [formSuccess, setFormSuccess] = useState('');
  const [loading, setLoading] = useState(false);

  // Manage custom ban states
  const [banDuration, setBanDuration] = useState<number>(60);
  const [banReason, setBanReason] = useState('مخالفة قيود حجز الأجهزة التعليمية النشطة ومشاركة العضوية دون إذن.');

  const preRegistered: PreRegisteredCode[] = db.pre_registered_codes || [];
  const students = db.students || [];

  // Group students by their used entry_code
  const studentsWithCodes = students.filter(s => s.entry_code && s.entry_code.trim() !== '');
  const groupedStudents: { [code: string]: typeof students } = {};
  studentsWithCodes.forEach(student => {
    const code = student.entry_code!.trim();
    if (!groupedStudents[code]) {
      groupedStudents[code] = [];
    }
    groupedStudents[code].push(student);
  });

  // Balanced symbol code generator
  const generateRandomKeyWithSymbols = () => {
    const symbols = ['@', '-', '!', '#', '$', '.'];
    const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let result = '';
    
    // Mix letters and symbols
    for (let i = 0; i < 4; i++) {
      result += letters.charAt(Math.floor(Math.random() * letters.length));
      if (i < 3) {
        result += symbols[Math.floor(Math.random() * symbols.length)];
      }
    }
    setCodeValue(result + '-' + String(Math.floor(100 + Math.random() * 900)));
  };

  const handleAddCode = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!codeValue.trim()) {
      setFormError('الرجاء كتابة أو توليد رمز الاشتراك.');
      return;
    }

    setLoading(true);
    setFormError('');
    setFormSuccess('');

    try {
      const pinToken = getDevToken() || '';
      const finalStudentName = studentName.trim() || `كود_تفعيل_${codeValue.trim()}`;
      
      const response = await fetch('/api/dev-action', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          token: pinToken,
          action: 'add_pre_registered_code',
          payload: {
            studentName: finalStudentName,
            code: codeValue.trim(),
            days: Number(days) || 0,
            months: Number(months) || 0,
            years: Number(years) || 0,
            maxDevices: Number(maxDevices) || 1
          }
        })
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'فشل حفظ الكود التعريفي للطالب.');
      }

      setFormSuccess(`تم بنجاح حجز الاسم وتخصيص الكود: ${codeValue.trim()}`);
      setStudentName('');
      setCodeValue('');
      setDays(1);
      setMonths(0);
      setYears(0);
      setMaxDevices(1);
      refreshData();
    } catch (err: any) {
      setFormError(err.message || 'حدث خطأ أثناء الاتصال بالخادم.');
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteCode = async (codeId: string) => {
    try {
      const pinToken = getDevToken() || '';
      const response = await fetch('/api/dev-action', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          token: pinToken,
          action: 'delete_pre_registered_code',
          payload: { codeId }
        })
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || 'فشل حذف الكود.');
      }

      refreshData();
    } catch (err: any) {
      console.error(err.message || 'فشل الحذف.');
    }
  };

  const handleWarnStudent = async (studentId: string, name: string) => {
    const text = prompt(
      `أدخل نص رسالة التنبيه التي ستظهر للطالب (${name}) فوراً:`,
      `⚠️ تنبيه أمني عاجل من المطور: لقد رصدت بوابتنا قيامك باستخدام حسابك على أجهزة متعددة بشكل غير مسموح به!`
    );
    if (!text) return;

    try {
      const pinToken = getDevToken() || '';
      await fetch('/api/dev-action', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          token: pinToken,
          action: 'message_student',
          payload: { studentId, text, type: 'warning' }
        })
      });
      refreshData();
    } catch (err) {
      console.error('فشل إرسال التنبيه.');
    }
  };

  const handleKickStudent = async (studentId: string, name: string) => {
    try {
      const pinToken = getDevToken() || '';
      await fetch('/api/dev-action', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          token: pinToken,
          action: 'kick_student',
          payload: { studentId }
        })
      });
      refreshData();
    } catch (e) {
      console.error('فشل طرد الطالب.');
    }
  };

  const handleBanStudent = async (studentId: string, name: string) => {
    try {
      const pinToken = getDevToken() || '';
      await fetch('/api/dev-action', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          token: pinToken,
          action: 'ban_student',
          payload: { studentId, durationMinutes: banDuration, reason: banReason }
        })
      });
      refreshData();
    } catch (e) {
      console.error('فشل فرض الحظر.');
    }
  };

  return (
    <div className="space-y-8 text-right mx-auto max-w-7xl" dir="rtl">
      
      {/* Primary Clean Header Block */}
      <div className="p-6 bg-gradient-to-r from-slate-900 to-slate-800 border border-slate-800 rounded-3xl text-white shadow-xl relative overflow-hidden">
        <div className="absolute top-0 left-0 w-32 h-32 bg-indigo-500/10 rounded-full blur-3xl animate-pulse" />
        <div className="relative z-10 space-y-2">
          <div className="flex items-center gap-2 text-indigo-400 font-black text-sm">
            <Key className="w-5 h-5 animate-pulse" />
            <span>إنشاء اكواد لمره واحده او رموز لمده واحدات</span>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed max-w-3xl font-bold">
            مرحباً بك في لوحة تحكّم المطور! هنا يمكنك إنشاء الرموز المخصصة لمرة واحدة وتعيين مدة الصلاحية الدقيقة لها (باليوم، الشهر، أو السنة). بعد تفعيل الطالب للكود، سيستمر حسابه طوال هذه المدة ثم يُحذف تلقائياً فور انتهائه.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* RIGHT COLUMN: MANUAL UNIQUE CODE BUILDER */}
        <div className="lg:col-span-5 space-y-6 animate-fade-in">
          <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-4">
            <div className="flex items-center gap-1.5 border-b border-slate-100 dark:border-slate-800 pb-3">
              <UserPlus className="w-4 h-4 text-emerald-500 animate-pulse" />
              <h4 className="font-bold text-sm text-slate-800 dark:text-slate-100">تخصيص رموز التفعيل الآمنة</h4>
            </div>

            <form onSubmit={handleAddCode} className="space-y-4">
              <div className="space-y-1.5">
                <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400">اسم الطالب الكامل (أو اترك فارغاً لاسم عشوائي):</label>
                <input
                  type="text"
                  placeholder="مثال: أحمد يحيى العبيدي"
                  value={studentName}
                  onChange={(e) => setStudentName(e.target.value)}
                  className="w-full px-4 py-2.5 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl outline-none text-right font-medium focus:ring-1 focus:ring-indigo-500"
                />
              </div>

              <div className="space-y-1.5">
                <div className="flex justify-between items-center">
                  <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400">رمز الاشتراك (Password/Code):</label>
                  <button
                    type="button"
                    onClick={generateRandomKeyWithSymbols}
                    className="text-[10px] font-bold text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1 cursor-pointer"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>توليد كود يضم رموز عشوائية (@, -, !, #, $, .)</span>
                  </button>
                </div>
                <input
                  type="text"
                  required
                  placeholder="مثال: AH-@$-918 أو اكتبه يدوياً"
                  value={codeValue}
                  onChange={(e) => setCodeValue(e.target.value)}
                  className="w-full px-4 py-2.5 text-xs font-mono text-center bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl outline-none font-bold focus:ring-1 focus:ring-indigo-500"
                />
              </div>

              {/* DURATION ASSIGNERS: DAYS, MONTHS, YEARS */}
              <div className="space-y-2 border-t border-b border-slate-50 dark:border-slate-850 py-3">
                <span className="block text-xs font-black text-slate-700 dark:text-slate-300">تحديد مدة صلاحية الحساب بعد التفعيل:</span>
                
                <div className="grid grid-cols-3 gap-2">
                  <div className="space-y-1">
                    <label className="text-[10px] text-slate-400 block font-bold">أيام:</label>
                    <input
                      type="number"
                      min="0"
                      max="365"
                      value={days}
                      onChange={(e) => setDays(Math.max(0, parseInt(e.target.value) || 0))}
                      className="w-full p-2 bg-slate-50 dark:bg-slate-950 text-xs font-bold text-center border rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] text-slate-400 block font-bold">شهور:</label>
                    <input
                      type="number"
                      min="0"
                      max="12"
                      value={months}
                      onChange={(e) => setMonths(Math.max(0, parseInt(e.target.value) || 0))}
                      className="w-full p-2 bg-slate-50 dark:bg-slate-950 text-xs font-bold text-center border rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] text-slate-400 block font-bold">سنوات:</label>
                    <input
                      type="number"
                      min="0"
                      max="5"
                      value={years}
                      onChange={(e) => setYears(Math.max(0, parseInt(e.target.value) || 0))}
                      className="w-full p-2 bg-slate-50 dark:bg-slate-950 text-xs font-bold text-center border rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500"
                    />
                  </div>
                </div>

                <div className="pt-1.5">
                  <label className="block text-[10px] font-bold text-slate-500 mb-1">الحد الأقصى للأجهزة المصرحة:</label>
                  <select
                    value={maxDevices}
                    onChange={(e) => setMaxDevices(parseInt(e.target.value))}
                    className="w-full p-2 bg-slate-50 dark:bg-slate-950 text-xs font-bold border rounded-lg"
                  >
                    <option value={1}>جهاز واحد فقط (مستحسن للأمان)</option>
                    <option value={2}>جهازين إثنين (2)</option>
                    <option value={3}>3 أجهزة</option>
                    <option value={5}>5 أجهزة</option>
                  </select>
                </div>

                <p className="text-[10px] font-bold text-indigo-500 dark:text-indigo-400 leading-relaxed bg-indigo-500/10 p-2 rounded-xl mt-2">
                  💡 معلومات: سيتم تشغيل عداد الصلاحية فور إعطاء الكود للطالب وتفعيله بالحساب.
                </p>
              </div>

              {formError && (
                <div className="bg-rose-50 text-rose-500 p-2.5 rounded-lg text-[10px] font-bold border">
                  {formError}
                </div>
              )}
              
              {formSuccess && (
                <div className="bg-emerald-50 text-emerald-600 p-2.5 rounded-lg text-[10px] font-bold border">
                  {formSuccess}
                </div>
              )}

              <button
                type="submit"
                disabled={loading || !codeValue.trim()}
                className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-bold text-xs rounded-xl transition cursor-pointer"
              >
                {loading ? 'تخصيص الكود...' : 'حفظ كود الاشتراك وتجهيزه'}
              </button>
            </form>
          </div>

          <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-3">
            <h4 className="font-bold text-sm text-slate-800 dark:text-slate-100">الأكواد اليدوية المنشأة ({preRegistered.length})</h4>
            <div className="max-h-[300px] overflow-y-auto space-y-2 pr-1 custom-scroll">
              {preRegistered.length === 0 ? (
                <p className="text-[11px] text-slate-400 text-center py-6">لا توجد أكواد تفعيل نشطة للأعضاء حالياً.</p>
              ) : (
                preRegistered.map((item) => (
                  <div key={item.id} className="p-3 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-100 dark:border-slate-900 space-y-2">
                    <div className="flex justify-between items-start">
                      <div>
                        <h5 className="text-[11px] font-black text-slate-800 dark:text-slate-200">{item.student_name}</h5>
                        <div className="flex items-center gap-1.5 mt-1">
                          <span className="text-[9px] bg-indigo-50 text-indigo-600 dark:bg-indigo-950/40 dark:text-indigo-400 px-1.5 py-0.5 rounded font-mono font-black select-all">
                            {item.code}
                          </span>
                          <button
                            onClick={() => {
                              navigator.clipboard.writeText(item.code);
                              alert('📋 تم نسخ الكود بنجاح!');
                            }}
                            className="p-1 opacity-60 hover:opacity-100"
                            title="نسخ الكود"
                          >
                            <Clipboard className="w-3.5 h-3.5 text-slate-400" />
                          </button>
                        </div>
                      </div>
                      <button
                        onClick={() => handleDeleteCode(item.id)}
                        className="p-1.5 hover:bg-rose-50 text-rose-500 rounded-lg transition"
                        title="حذف الكود"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <div className="flex flex-wrap gap-1.5 text-[9px] font-bold text-slate-400">
                      <span>⏳ المدة: {item.duration_years > 0 ? `${item.duration_years} سن ` : ''}{item.duration_months > 0 ? `${item.duration_months} شهر ` : ''}{item.duration_days > 0 ? `${item.duration_days} يوم` : ''}</span>
                      <span>• max: {item.max_devices} أجهزة</span>
                      {item.is_used ? (
                        <span className="text-emerald-500 bg-emerald-50 dark:bg-emerald-950/20 px-1 rounded">🟢 مفعل ({item.registered_name})</span>
                      ) : (
                        <span className="text-amber-500 bg-amber-50 dark:bg-amber-950/20 px-1 rounded animate-pulse">⏳ بانتظار التفعيل</span>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>

        {/* LEFT COLUMN: SHARED MULTI-DEVICE DEVICE VIOLATIONS LIST */}
        <div className="lg:col-span-7 space-y-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-4">
            
            <div className="border-b border-slate-100 dark:border-slate-800 pb-3">
              <h4 className="font-bold text-sm text-slate-800 dark:text-slate-100 flex items-center gap-1.5">
                <Users className="w-4 h-4 text-rose-500 animate-pulse" />
                <span>رصد الأجهزة والطلاب ذوي الرموز المتشابهة والمشتركة</span>
              </h4>
              <p className="text-[10px] text-slate-400 mt-1">
                البرنامج يفحص الطلاب ويفرزهم بشكل تجميعي آمن للوقوف على التناقل وحظر الأجهزة المسربة.
              </p>
            </div>

            {/* Config Box of durations */}
            <div className="bg-slate-50 dark:bg-slate-950 p-4 rounded-2xl border border-slate-100 dark:border-slate-850 space-y-3">
              <div className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                <Sliders className="w-4 h-4 text-amber-500" />
                <span>إعدادات عقوبات حظر المتهمين بالاختراق:</span>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-[10px] text-slate-400 font-bold block">مدة الحظر المؤقت:</label>
                  <select 
                    value={banDuration}
                    onChange={(e) => setBanDuration(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-white dark:bg-slate-900 text-xs text-slate-800 dark:text-white border border-slate-200 dark:border-slate-800 rounded-lg outline-none"
                  >
                    <option value={10}>10 دقائق (تحذير تجريبي)</option>
                    <option value={60}>ساعة واحدة فقط</option>
                    <option value={1440}>يوم كامل (24 ساعة)</option>
                    <option value={10080}>أسبوع كامل (7 أيام)</option>
                    <option value={43200}>30 يوماً متواصلة</option>
                    <option value={0}>🚫 حظر نهائي ودائم للأبد من المطور</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] text-slate-400 font-bold block">سبب الحظر الموجه رسمياً:</label>
                  <input
                    type="text"
                    value={banReason}
                    onChange={(e) => setBanReason(e.target.value)}
                    className="w-full px-3 py-2 bg-white dark:bg-slate-900 text-xs text-slate-800 dark:text-white border border-slate-200 dark:border-slate-800 rounded-lg outline-none"
                  />
                </div>
              </div>
            </div>

            {/* Live groupings rendering */}
            <div className="space-y-3 max-h-[500px] overflow-y-auto pr-1">
              {Object.keys(groupedStudents).length === 0 ? (
                <div className="p-6 text-center text-xs font-bold text-slate-400">لا توجد أجهزة متصلة بالبوابة برمز تفعيل نشط حالياً.</div>
              ) : (
                Object.keys(groupedStudents).map((codeKey) => {
                  const studentsInCode = groupedStudents[codeKey];
                  const isViolating = studentsInCode.length > 1;

                  return (
                    <div 
                      key={codeKey}
                      className={`border rounded-2xl overflow-hidden transition ${
                        isViolating 
                          ? 'border-rose-200 dark:border-rose-950/40 bg-rose-50/5' 
                          : 'border-slate-100 dark:border-slate-800'
                      }`}
                    >
                      <div className="p-3.5 bg-slate-50 dark:bg-slate-950 flex justify-between items-center border-b border-light">
                        <div>
                          <span className="text-[10px] font-black font-mono bg-indigo-500 text-white px-2 py-0.5 rounded">كود: {codeKey}</span>
                          {isViolating && <span className="text-[8px] bg-rose-500 text-white px-1.5 py-0.5 rounded-full mr-2 animate-bounce">⚠️ دخول مزدوج</span>}
                        </div>
                        <span className="text-[10px] text-slate-400 font-bold">{studentsInCode.length} أجهزة متصلة</span>
                      </div>

                      <div className="divide-y divide-slate-100 dark:divide-slate-800 bg-white dark:bg-slate-900">
                        {studentsInCode.map((item) => {
                          const isBanned = item.banned_until && new Date(item.banned_until) > new Date();
                          
                          return (
                            <div key={item.id} className="p-3 flex justify-between items-center text-xs">
                              <div>
                                <h5 className="font-black">{item.display_name} {isBanned && <span className="text-rose-500 font-black text-[9px]">(محظور)</span>}</h5>
                                <span className="text-[9px] text-slate-400 font-mono">ID: {item.id}</span>
                              </div>

                              <div className="flex gap-1">
                                <button
                                  onClick={() => handleWarnStudent(item.id, item.display_name)}
                                  className="px-2 py-1 bg-yellow-500 hover:bg-yellow-600 text-white text-[8px] font-black rounded cursor-pointer"
                                >
                                  تنبيه
                                </button>
                                <button
                                  onClick={() => handleKickStudent(item.id, item.display_name)}
                                  className="px-2 py-1 bg-slate-200 hover:bg-slate-300 text-slate-800 text-[8px] font-black rounded cursor-pointer"
                                >
                                  طرد
                                </button>
                                <button
                                  onClick={() => handleBanStudent(item.id, item.display_name)}
                                  className="px-2 py-1 bg-rose-600 hover:bg-rose-700 text-white text-[8px] font-black rounded cursor-pointer"
                                >
                                  حظر
                                </button>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  );
                })
              )}
            </div>

          </div>
        </div>

      </div>

    </div>
  );
}
