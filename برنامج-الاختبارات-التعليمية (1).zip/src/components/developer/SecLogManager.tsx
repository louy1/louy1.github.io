import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { getDevToken } from '../../lib/devToken';
import { 
  ShieldAlert, Trash2, Unlock, Coins, Ban, ShieldX, Search, Calendar, 
  RefreshCw, Smartphone, CreditCard, HelpCircle, FileText, CheckCircle, AlertTriangle 
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function SecLogManager() {
  const { db, refreshData, students } = useApp();
  const [subTab, setSubTab] = useState<'intrusions' | 'blocked_devices' | 'conflicts' | 'receipts'>('intrusions');
  
  // Search & Filter state
  const [searchTerm, setSearchTerm] = useState('');
  const [loadingAction, setLoadingAction] = useState<string | null>(null);
  const [showClearConfirm, setShowClearConfirm] = useState<string | null>(null);

  const logs = db.intrusion_logs || [];
  const deviceBlocks = db.device_blocks || [];
  const conflicts = db.code_share_conflicts || [];
  const receipts = db.payment_receipts || [];

  // Count metrics
  const totalIncidents = logs.length;
  const activeDeviceBans = deviceBlocks.length;
  const activeConflicts = conflicts.length;
  const totalIncome = receipts.reduce((sum, r) => sum + (r.amount || 0), 0);

  const handleAction = async (action: string, payload: any) => {
    const actionKey = `${action}_${payload.studentId || payload.deviceId || payload.codeId || 'all'}`;
    setLoadingAction(actionKey);
    try {
      const response = await fetch('/api/dev-action', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          token: getDevToken() || 'awdrgyjilp-supervisor-token',
          action,
          payload
        })
      });
      if (response.ok) {
        await refreshData();
      } else {
        const data = await response.json();
        alert(data.error || 'عذراً، فشل تطبيق الإجراء بالخادم.');
      }
    } catch (err) {
      console.error(err);
      alert('حدث خطأ في الاتصال بنظام الإدارة الذكي للتحجيم.');
    } finally {
      setLoadingAction(null);
    }
  };

  const handleClearCollections = async (category: string) => {
    if (category === 'intrusion') {
      await handleAction('clear_intrusion_logs', {});
    } else if (category === 'conflicts') {
      await handleAction('clear_code_share_conflicts', {});
    } else if (category === 'receipts') {
      await handleAction('clear_payment_receipts', {});
    }
    setShowClearConfirm(null);
  };

  // Filter logs
  const filteredLogs = logs.filter(log => {
    return (
      log.student_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (log.attempted_password || '').toLowerCase().includes(searchTerm.toLowerCase())
    );
  }).sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());

  // Filter receipts
  const filteredReceipts = receipts.filter(r => {
    return (
      r.student_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (r.generated_code || '').includes(searchTerm)
    );
  }).sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());

  return (
    <div className="space-y-6" id="sec-logs-module">
      {/* Header Info */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-800 dark:text-white flex items-center gap-2">
            <ShieldAlert className="w-6 h-6 text-rose-500 animate-pulse" />
            منظومة المراقبة الأمنية والتحكّم بالدواعي التأديبية
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            إدارة الحظر التلقائي للأجهزة، مكافحة التشغيل المزدوج للأكواد، ومعاينة فواتير الخدمة الذاتية للطلاب.
          </p>
        </div>
        
        <div className="flex items-center gap-2 self-start md:self-auto">
          <button
            onClick={() => refreshData()}
            className="p-2 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition duration-150"
            title="تحديث فوري لكل الجداول والبيانات المسجلة"
          >
            <RefreshCw className="w-5 h-5 text-emerald-500" />
          </button>
        </div>
      </div>

      {/* Stats Bento Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 p-4 rounded-xl flex items-center gap-3.5 shadow-sm">
          <div className="p-2.5 rounded-lg bg-rose-50 dark:bg-rose-950/20 text-rose-500 shrink-0">
            <ShieldX className="w-5 h-5" />
          </div>
          <div>
            <div className="text-lg font-bold text-slate-800 dark:text-white font-mono leading-tight">{totalIncidents}</div>
            <div className="text-[10px] text-slate-500 dark:text-slate-450">تخمينات الإشراف الخاطئة</div>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 p-4 rounded-xl flex items-center gap-3.5 shadow-sm">
          <div className="p-2.5 rounded-lg bg-amber-50 dark:bg-amber-950/20 text-amber-500 shrink-0">
            <Ban className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <div className="text-lg font-bold text-slate-800 dark:text-white font-mono leading-tight">{activeDeviceBans}</div>
            <div className="text-[10px] text-slate-500 dark:text-slate-450 font-bold">أجهزة محظورة مؤقتاً لـ 30 دقيقة</div>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 p-4 rounded-xl flex items-center gap-3.5 shadow-sm">
          <div className="p-2.5 rounded-lg bg-orange-50 dark:bg-orange-950/20 text-orange-500 shrink-0">
            <AlertTriangle className="w-5 h-5 text-orange-500 animate-bounce" />
          </div>
          <div>
            <div className="text-lg font-bold text-slate-800 dark:text-white font-mono leading-tight">{activeConflicts}</div>
            <div className="text-[10px] text-slate-500 dark:text-slate-450 font-bold">حالات قرصنة وتزييف رمز الدخول</div>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 p-4 rounded-xl flex items-center gap-3.5 shadow-sm">
          <div className="p-2.5 rounded-lg bg-emerald-50 dark:bg-emerald-950/20 text-emerald-500 shrink-0">
            <CreditCard className="w-5 h-5" />
          </div>
          <div>
            <div className="text-lg font-bold text-slate-800 dark:text-white font-mono leading-tight">{totalIncome} <span className="text-[10px] text-emerald-600 font-bold">ر.س</span></div>
            <div className="text-[10px] text-slate-500 dark:text-slate-450">مبيعات الدخول المالي الذاتي</div>
          </div>
        </div>
      </div>

      {/* Master Sub-Tabs Trigger */}
      <div className="flex bg-slate-100 dark:bg-slate-950 p-1 rounded-xl mb-4 font-bold" dir="rtl">
        <button
          onClick={() => { setSubTab('intrusions'); setSearchTerm(''); }}
          className={`flex-1 py-2 text-xs rounded-lg transition-all ${
            subTab === 'intrusions'
              ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
              : 'text-slate-500 dark:text-slate-400 hover:text-slate-700'
          }`}
        >
          <span>تخمين رموز لوحة التحكم ({totalIncidents})</span>
        </button>
        <button
          onClick={() => { setSubTab('blocked_devices'); setSearchTerm(''); }}
          className={`flex-1 py-2 text-xs rounded-lg transition-all ${
            subTab === 'blocked_devices'
              ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
              : 'text-slate-500 dark:text-slate-400 hover:text-slate-700'
          }`}
        >
          <span>الأجهزة المحظورة 🚫 ({activeDeviceBans})</span>
        </button>
        <button
          onClick={() => { setSubTab('conflicts'); setSearchTerm(''); }}
          className={`flex-1 py-2 text-xs rounded-lg transition-all ${
            subTab === 'conflicts'
              ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
              : 'text-slate-500 dark:text-slate-400 hover:text-slate-700'
          }`}
        >
          <span>سرقة ومشاركة الأكواد ({activeConflicts})</span>
        </button>
        <button
          onClick={() => { setSubTab('receipts'); setSearchTerm(''); }}
          className={`flex-1 py-2 text-xs rounded-lg transition-all ${
            subTab === 'receipts'
              ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
              : 'text-slate-500 dark:text-slate-400 hover:text-slate-700'
          }`}
        >
          <span>المدفوعات والبطاقات 💳 ({receipts.length})</span>
        </button>
      </div>

      {/* Clearing Dialogue Confirms */}
      <AnimatePresence>
        {showClearConfirm && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="bg-amber-50 dark:bg-amber-950/20 border border-amber-250 dark:border-amber-900/40 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 overflow-hidden text-right"
            dir="rtl"
          >
            <div className="flex items-start gap-2">
              <ShieldAlert className="w-5 h-5 text-amber-500 mt-0.5 shrink-0" />
              <div>
                <h4 className="text-xs font-black text-amber-900 dark:text-amber-200">تأكيد تصفير وتنظيف قاعدة البيانات الأمنيّة</h4>
                <p className="text-[11px] text-amber-700 dark:text-amber-400 mt-0.5">هل تريد فعلياً مسح هذه القائمة بشكل متكامل ونهائي من السجلات؟</p>
              </div>
            </div>
            <div className="flex items-center gap-2 self-end sm:self-auto">
              <button
                onClick={() => handleClearCollections(showClearConfirm)}
                className="px-3.5 py-1.5 text-xs bg-red-600 hover:bg-red-700 text-white font-bold rounded-lg transition duration-150 cursor-pointer"
              >
                نعم، احذف نهائياً
              </button>
              <button
                onClick={() => setShowClearConfirm(null)}
                className="px-3 py-1.5 text-xs bg-slate-150 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-200 rounded-lg cursor-pointer"
              >
                تراجع
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* TAB SUB-CONTENTS MODULE */}
      <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-xl shadow-sm overflow-hidden text-right" dir="rtl">
        
        {/* Search tool for list categories (Intrusions & Receipts) */}
        {(subTab === 'intrusions' || subTab === 'receipts') && (
          <div className="p-4 bg-slate-50/50 dark:bg-slate-900/40 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between gap-4">
            <div className="relative flex-1">
              <Search className="w-4 h-4 absolute right-3 top-2.5 text-slate-400" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder={subTab === 'intrusions' ? "ابحث باسم الطالب المعتدي أو الباسورد المخمن..." : "ابحث باسم المشتري أو الكود المستخرج لحسابه..."}
                className="w-full pr-9 pl-4 py-1.5 text-xs bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-850 rounded-lg text-slate-700 dark:text-slate-200 focus:outline-none"
              />
            </div>

            {subTab === 'intrusions' && (
              <button
                onClick={() => setShowClearConfirm('intrusion')}
                disabled={logs.length === 0}
                className="px-3 py-1.5 text-xs bg-rose-50 hover:bg-rose-100 text-rose-600 dark:bg-rose-950/20 dark:hover:bg-rose-950/40 dark:text-rose-450 border border-rose-100 dark:border-rose-900 rounded-lg disabled:opacity-50 flex items-center gap-1 cursor-pointer font-bold"
              >
                <Trash2 className="w-3.5 h-3.5" />
                مسح السجلات
              </button>
            )}

            {subTab === 'receipts' && (
              <button
                onClick={() => setShowClearConfirm('receipts')}
                disabled={receipts.length === 0}
                className="px-3 py-1.5 text-xs bg-rose-50 hover:bg-rose-100 text-rose-600 dark:bg-rose-950/20 dark:hover:bg-rose-950/40 dark:text-rose-450 border border-rose-100 dark:border-rose-900 rounded-lg disabled:opacity-50 flex items-center gap-1 cursor-pointer font-bold"
              >
                <Trash2 className="w-3.5 h-3.5" />
                تصفير الفواتير المالّية
              </button>
            )}
          </div>
        )}

        {/* SECTION A: INTRUSION ATTEMPTS LIST */}
        {subTab === 'intrusions' && (
          <div className="overflow-x-auto">
            {filteredLogs.length === 0 ? (
              <div className="p-12 text-center text-slate-400 dark:text-slate-500 py-16 flex flex-col items-center justify-center gap-2">
                <ShieldAlert className="w-12 h-12 text-slate-200 dark:text-slate-800 mb-2" />
                <p className="text-sm font-bold">سجلات التخمين فارغة</p>
                <p className="text-xs text-slate-400">لا توجد محاولات تسلل مرصودة في النظام.</p>
              </div>
            ) : (
              <table className="w-full text-right border-collapse text-xs">
                <thead className="bg-slate-50 dark:bg-slate-950 text-slate-500 dark:text-slate-400 font-bold border-b border-slate-105">
                  <tr>
                    <th className="p-4">اسم الطالب</th>
                    <th className="p-4">البوابة المستهدفة</th>
                    <th className="p-4">الباسورد المدخل</th>
                    <th className="p-4">عقوبة النظام الملقاة</th>
                    <th className="p-4">التوقيت الأمني</th>
                    <th className="p-4 text-left">أدوات التأديب</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {filteredLogs.map((log) => {
                    const studentRecord = students.find(s => s.id === log.student_id);
                    return (
                      <tr key={log.id} className="hover:bg-slate-50/40 dark:hover:bg-slate-850/10">
                        <td className="p-4">
                          <div className="font-bold text-slate-800 dark:text-slate-200">{log.student_name}</div>
                          {log.student_id && (
                            <div className="text-[10px] text-slate-400 dark:text-slate-500 mt-0.5">
                              معرّف الطالب: {log.student_id.slice(0, 8)}...
                              {studentRecord && studentRecord.warning_attempts ? (
                                <span className="mr-1 text-red-500 font-bold">({studentRecord.warning_attempts} محاولة تخمين)</span>
                              ) : null}
                            </div>
                          )}
                        </td>
                        <td className="p-4">
                          <span className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-black ${
                            log.attempted_gate === 'master_gate'
                              ? 'bg-purple-100 text-purple-700 dark:bg-purple-950/40 dark:text-purple-400'
                              : 'bg-amber-100 text-amber-700 dark:bg-amber-950/40 dark:text-amber-400'
                          }`}>
                            {log.attempted_gate === 'master_gate' ? 'لوحة التحكم للمطور' : 'واجهة تحرير المشرف'}
                          </span>
                        </td>
                        <td className="p-4">
                          <code className="text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/20 px-2 py-0.5 rounded border border-rose-100 dark:border-rose-950 text-[10px] font-bold">
                            {log.attempted_password || '(خالي)'}
                          </code>
                        </td>
                        <td className="p-4">
                          {log.action_taken === 'banned_automatically' ? (
                            <span className="text-red-500 font-black flex items-center gap-1">
                              <Ban className="w-3 h-3" />
                              تم الحظر لـ 60 دقيقة
                            </span>
                          ) : (
                            <span className="text-amber-600 font-bold flex items-center gap-1">
                              <ShieldAlert className="w-3 h-3" />
                              إنذار وتنبيه أمني
                            </span>
                          )}
                        </td>
                        <td className="p-4 text-[10px] text-slate-400 font-mono">
                          {new Date(log.created_at).toLocaleString('ar-EG')}
                        </td>
                        <td className="p-4 text-left">
                          {log.student_id ? (
                            <div className="flex items-center justify-end gap-1.5">
                              <button
                                onClick={() => handleAction('pardon_student_intrusion', { studentId: log.student_id })}
                                className="px-2 py-1 text-[10px] bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-950/20 dark:hover:bg-emerald-950/40 text-emerald-600 dark:text-emerald-450 rounded-lg cursor-pointer font-bold"
                              >
                                عفو وتصفير
                              </button>
                              <button
                                onClick={() => handleAction('deduct_student_xp', { studentId: log.student_id, amount: 50 })}
                                className="px-2 py-1 text-[10px] bg-orange-50 hover:bg-orange-100 dark:bg-orange-950/20 dark:hover:bg-orange-950/40 text-orange-650 dark:text-orange-400 rounded-lg cursor-pointer"
                              >
                                خصم ٥٠ XP
                              </button>
                              <button
                                onClick={() => handleAction('deduct_student_xp', { studentId: log.student_id, amount: 150 })}
                                className="px-2 py-1 text-[10px] bg-red-50 hover:bg-red-100 dark:bg-red-950/20 dark:hover:bg-red-950/40 text-red-650 dark:text-red-400 rounded-lg cursor-pointer font-black"
                              >
                                خصم ١٥٠ XP 🔨
                              </button>
                            </div>
                          ) : (
                            <span className="text-[10px] text-slate-400">بدون حساب</span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            )}
          </div>
        )}

        {/* SECTION B: BLOCKED DEVICES TAB */}
        {subTab === 'blocked_devices' && (
          <div className="p-4 space-y-4">
            <div className="bg-amber-500/10 p-3 rounded-xl border border-amber-500/20 text-xs text-amber-700 dark:text-amber-400 font-bold leading-relaxed">
              💡 <strong>عقوبة حظر الـ 30 دقيقة للأجهزة:</strong> عندما يُدخل الطالب الرمز السري العام للمدرسة أو كلمة مرور الحساب بشكل خاطئ <strong>5 مرات متتالية</strong> من نفس متصفحه وجهازه، يسد خادمنا المنفذ لـ 30 دقيقة لحمايتنا من التخمين المستمر. يمكنك كمسؤول تصفير حظر أجهزتهم لتمكينهم من إعادة المحاولة.
            </div>

            {deviceBlocks.length === 0 ? (
              <div className="p-8 text-center text-slate-400 dark:text-slate-500 py-12 flex flex-col items-center justify-center gap-2">
                <Smartphone className="w-12 h-12 text-slate-200 dark:text-slate-800 mb-1" />
                <p className="text-xs font-black text-slate-700 dark:text-slate-300">لا توجد أجهزة محظورة حالياً</p>
                <p className="text-[10px] text-slate-400">كل الأجهزة والمتصفحات تتمتع باتصال طبيعي وآمن بالمنصة.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {deviceBlocks.map((block) => {
                  const minutesLeft = Math.ceil((new Date(block.blocked_until).getTime() - Date.now()) / 60000);
                  return (
                    <div key={block.id} className="p-4 bg-slate-50 dark:bg-slate-950 border border-slate-100 dark:border-slate-850 rounded-xl relative overflow-hidden flex flex-col justify-between">
                      <div className="absolute top-0 left-0 bg-red-500 text-white font-mono px-3 py-1 font-bold text-[10px] rounded-br-xl">
                        {minutesLeft > 0 ? `متبقي ${minutesLeft} د` : 'منتهي'}
                      </div>

                      <div className="space-y-2 mt-2">
                        <div className="flex items-center gap-1 text-slate-800 dark:text-slate-200 font-bold text-xs">
                          <Smartphone className="w-4 h-4 text-slate-500" />
                          <span>جهاز: <span className="font-mono text-[10px] bg-slate-200 dark:bg-slate-800 px-1.5 py-0.5 rounded text-blue-600 dark:text-blue-400 font-bold">{block.device_id}</span></span>
                        </div>

                        <p className="text-xs text-slate-600 dark:text-slate-400 leading-normal">
                          سبب تقييد الحساب: <strong className="text-red-500">{block.reason}</strong>
                        </p>

                        <div className="text-[10px] text-slate-400 space-y-0.5 font-bold">
                          <div>توقيت الحظر المطبق: {new Date(block.created_at).toLocaleString('ar-EG')}</div>
                          <div>توقيت انتهاء المنع: {new Date(block.blocked_until).toLocaleString('ar-EG')}</div>
                        </div>
                      </div>

                      <div className="mt-4 pt-3 border-t border-slate-200 dark:border-slate-800 flex justify-end">
                        <button
                          onClick={() => handleAction('pardon_device', { deviceId: block.device_id })}
                          disabled={loadingAction !== null}
                          className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold transition flex items-center gap-1 cursor-pointer"
                        >
                          <Unlock className="w-3.5 h-3.5" />
                          <span>رفع الحظر الفوري عن هذا الجهاز</span>
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* SECTION C: CODE-SHARE CONFLICTS */}
        {subTab === 'conflicts' && (
          <div className="p-4 space-y-4">
            <div className="flex items-start gap-2.5 bg-rose-50 dark:bg-rose-950/20 p-4 rounded-xl border border-rose-100 dark:border-rose-900/40">
              <ShieldAlert className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
              <div className="text-xs leading-relaxed text-rose-800 dark:text-rose-400 font-bold">
                <strong>حرب مشاركة الأكواد والرموز:</strong> يحظر النظام بقوانين ذكية تشغيل الرمز التعريفي للطالب من جهازين مختلفين. إذا تم تفعيل الكود على جهاز، فسيتم احتكاره له. ودخول أي جهاز آخر بنفس الكود ينشئ فوراً بطاقة نزاع، ويقوم خادمنا تلقائياً بـ: <br />
                ١- حظر كود الطالب وحظره من الدخول. <br />
                ٢- حظر جهاز الطالب الأصلي (60 دقيقة) لحظر تسهيل مشاركة کوده. <br />
                ٣- حظر الجهاز الدخيل والمخترق (60 دقيقة). <br />
                ٤- تسجيل تضارب الأكواد هنا لعين الإدارة والمسؤول للفصل والاسترجاع.
              </div>
            </div>

            <div className="flex justify-between items-center py-1">
              <h3 className="text-xs font-black text-slate-800 dark:text-white">سجل التضاربات والنزاعات المسجلة:</h3>
              <button
                onClick={() => setShowClearConfirm('conflicts')}
                disabled={conflicts.length === 0}
                className="px-3 py-1 bg-rose-100 hover:bg-rose-200 dark:bg-rose-900 text-rose-700 dark:text-rose-300 rounded-lg text-[10px] pointer transition font-bold"
              >
                تصفير قائمة التضاربات
              </button>
            </div>

            {conflicts.length === 0 ? (
              <div className="p-8 text-center text-slate-400 dark:text-slate-500 py-12 flex flex-col items-center justify-center gap-2">
                <CheckCircle className="w-12 h-12 text-emerald-500/80 mb-1" />
                <p className="text-xs font-black text-emerald-700 dark:text-emerald-400">لا توجد أي محاولات تزييف أو تشغيل مزدوج!</p>
                <p className="text-[10px] text-slate-400">الطلاب ملتزمون كلياً بإجراء الدخول الأحادي والشرعي.</p>
              </div>
            ) : (
              <div className="space-y-4">
                {conflicts.map((conflict) => {
                  return (
                    <div key={conflict.id} className="p-4 bg-white dark:bg-slate-950 border border-red-200 dark:border-red-950 rounded-xl relative overflow-hidden shadow-sm space-y-3">
                      <div className="absolute top-0 left-0 bg-red-600 text-white font-bold px-3 py-1 text-[9px] rounded-br-lg">
                        تضارب حرج للدخول
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs font-bold pt-2">
                        <div className="p-3 bg-blue-50/50 dark:bg-slate-900/60 rounded-lg border space-y-1">
                          <div className="text-xs text-blue-600 dark:text-blue-400">اسم الطالب صاحب الكود:</div>
                          <div className="text-slate-800 dark:text-slate-100 text-sm font-black">{conflict.student_name}</div>
                          <div className="text-[10px] text-slate-400 font-mono mt-1">كود الطالب: <span className="text-blue-600 font-bold">{conflict.code}</span></div>
                        </div>

                        <div className="p-3 bg-amber-50/50 dark:bg-slate-900/40 rounded-lg border border-dashed text-slate-500 space-y-1">
                          <div className="text-xs text-amber-600 dark:text-amber-400">صاحب الجهاز الأول والمالك:</div>
                          <div className="text-slate-800 dark:text-slate-200 font-mono break-all text-[10px]">{conflict.original_device_id}</div>
                          <div className="text-[9px] text-red-500">❌ تم حظره لـ 60 دقيقة وتجميد حسابه</div>
                        </div>

                        <div className="p-3 bg-rose-50/30 dark:bg-slate-900/40 rounded-lg border border-red-100 dark:border-red-900/30 text-rose-500 space-y-1">
                          <div className="text-xs text-rose-600 dark:text-rose-400 font-black">الدخيل والمخترق (الجهاز الثاني):</div>
                          <div className="text-slate-800 dark:text-slate-200 font-mono break-all text-[10px]">{conflict.intruder_device_id}</div>
                          <div className="text-[9px] text-rose-600 dark:text-rose-400">❌ تم حظر جهازه تلقائياً</div>
                        </div>
                      </div>

                      <div className="flex flex-col sm:flex-row items-center sm:justify-between gap-3 pt-2 text-[10px] text-slate-400 border-t pr-1">
                        <div>توقيت رصد الاختراق ومصادرة المحاولة: {new Date(conflict.created_at).toLocaleString('ar-EG')}</div>
                        <div className="flex gap-2">
                          <button
                            onClick={async () => {
                              // We can locate the code ID by looking it up in `db.pre_registered_codes`
                              const matchingCode = (db.pre_registered_codes || []).find(c => c.code === conflict.code);
                              if (matchingCode) {
                                await handleAction('reset_device_lock', { codeId: matchingCode.id });
                                await handleAction('pardon_device', { deviceId: conflict.original_device_id });
                                await handleAction('pardon_device', { deviceId: conflict.intruder_device_id });
                                alert('تم فك قفل الكود وحذف الارتباط، كما جرى عفو سريع وحذف حظر جهازي الطالب بنجاح! يمكنه الآن معاودة الدخول مجدداً.');
                              } else {
                                alert('عذراً، الكود غير موجود بقاعدة بيانات الرموز.');
                              }
                            }}
                            className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-[10px] font-black transition cursor-pointer"
                          >
                            🔓 حل التضارب وعفو سريع عن الطالب
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* SECTION D: SELF-SERVICE PAYMENTS LEDGER */}
        {subTab === 'receipts' && (
          <div className="overflow-x-auto">
            {filteredReceipts.length === 0 ? (
              <div className="p-12 text-center text-slate-400 dark:text-slate-500 py-16 flex flex-col items-center justify-center gap-2">
                <CreditCard className="w-12 h-12 text-slate-200 dark:text-slate-800 mb-2" />
                <p className="text-sm font-bold">لا توجد عمليات حجز مالي مسجلة</p>
                <p className="text-xs text-slate-400">لم يقم أي طالب بالدفع البنكي لاستخراج كود دخول فوري.</p>
              </div>
            ) : (
              <table className="w-full text-right border-collapse text-xs">
                <thead className="bg-slate-50 dark:bg-slate-950 text-slate-500 dark:text-slate-400 font-bold border-b border-slate-105">
                  <tr>
                    <th className="p-4">اسم الطالب المشتري</th>
                    <th className="p-4">اسم صاحب البطاقة</th>
                    <th className="p-4">أرقام البطاقة (الأخيرة)</th>
                    <th className="p-4">المبلغ المقبوض</th>
                    <th className="p-4">الكود المستخرج بنجاح</th>
                    <th className="p-4">التاريخ والوقت</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {filteredReceipts.map((receipt) => {
                    return (
                      <tr key={receipt.id} className="hover:bg-slate-50/40 dark:hover:bg-slate-850/10 font-bold">
                        <td className="p-4">
                          <span className="text-slate-800 dark:text-slate-100 text-xs font-black">{receipt.student_name}</span>
                          <div className="text-[9px] text-slate-400 block font-mono mt-0.5">معرف الفاتورة: {receipt.id}</div>
                        </td>
                        <td className="p-4 text-xs font-medium text-slate-700 dark:text-slate-300">
                          {receipt.card_holder}
                        </td>
                        <td className="p-4 font-mono text-xs text-slate-600 dark:text-slate-400">
                          **** **** **** {receipt.card_digits}
                        </td>
                        <td className="p-4">
                          <span className="px-2 py-0.5 bg-emerald-50 dark:bg-emerald-950/30 text-emerald-600 dark:text-emerald-400 rounded border border-emerald-100 dark:border-emerald-900 font-mono">
                            {receipt.amount} ر.س
                          </span>
                        </td>
                        <td className="p-4">
                          <code className="px-2.5 py-1 bg-slate-100 dark:bg-slate-800 text-blue-600 dark:text-blue-400 rounded-lg font-mono text-sm font-black border tracking-wider">
                            {receipt.generated_code}
                          </code>
                        </td>
                        <td className="p-4 text-[10px] text-slate-400 font-mono font-normal">
                          {new Date(receipt.created_at).toLocaleString('ar-EG')}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
