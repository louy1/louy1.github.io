import { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { getDevToken } from '../../lib/devToken';
import { ShieldAlert, BarChart3, Users, FileText, HelpCircle, AlertOctagon, RotateCcw, Power, CheckCircle2 } from 'lucide-react';
import { motion } from 'motion/react';

export default function AdvancedSystemManager() {
  const { students, questions, studentNotes, progress, achievements, refreshData } = useApp();
  const [loading, setLoading] = useState(false);
  const [successText, setSuccessText] = useState('');
  const [showConfirmReset, setShowConfirmReset] = useState(false);

  // Filter students who have non-zero warning attempts (unauthorized master password inputs)
  const flaggedStudents = students.filter(s => (s.warning_attempts || 0) > 0);

  const handleClearWarnings = async (studentId: string) => {
    setLoading(true);
    setSuccessText('');
    const token = getDevToken();

    try {
      // In server, we can update student's warn count
      const studentObj = students.find(s => s.id === studentId);
      if (!studentObj) return;

      const updatedStudent = {
        ...studentObj,
        warning_attempts: 0,
        messages: (studentObj.messages || []).filter(m => !m.id.startsWith('unauth_'))
      };

      const res = await fetch('/api/dev-action', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          token,
          action: 'upsert_student', // use upsert_student to update warning states
          payload: updatedStudent
        })
      });

      if (res.ok) {
        setSuccessText('تم تصفير عداد إنذارات الطالب بنجاح.');
        await refreshData();
      } else {
        alert('فشل تصفير إنذار الطالب.');
      }
    } catch (err) {
      alert('خطأ في استدعاء الخدمة.');
    } finally {
      setLoading(false);
    }
  };

  const handleFullSemesterReset = async () => {
    setLoading(true);
    setSuccessText('');
    const token = getDevToken();

    try {
      const res = await fetch('/api/dev-action', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          token,
          action: 'reset_student_scores',
          payload: {}
        })
      });

      if (res.ok) {
        setSuccessText('تمت جدولة وتصفير لوحة النتائج وإنجازات العام الدراسي وإراشيف الطلاب بنجاح تام وبدء دورة فصلية جديدة!');
        setShowConfirmReset(false);
        await refreshData();
      } else {
        alert('فشلت العملية على الخادم.');
      }
    } catch (e) {
      alert('خطأ في الاتصال بقاعدة البيانات لجدولة تصفير العام.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6 text-right" dir="rtl">
      
      {/* 1. General Metrics Grid */}
      <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-3xl p-6 space-y-4">
        <div>
          <h3 className="text-base font-black text-slate-800 dark:text-white flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-indigo-500" />
            <span>إحصائيات المنصة الشاملة لحظة بلحظة</span>
          </h3>
          <p className="text-xs text-slate-400 mt-1">تراكم وتحليل فوري لجميع البيانات والأنشطة المسجلة على خوادم البوابة:</p>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-slate-50 dark:bg-slate-950 p-4 rounded-2xl border border-slate-100 dark:border-slate-850 space-y-1">
            <span className="text-[10px] text-slate-400 font-bold block">إجمالي الطلاب المسجلين</span>
            <div className="flex items-baseline gap-1">
              <span className="text-2xl font-black text-slate-800 dark:text-white font-mono">{students.length}</span>
              <span className="text-xs text-slate-400 font-medium">عضو</span>
            </div>
          </div>
          <div className="bg-slate-50 dark:bg-slate-950 p-4 rounded-2xl border border-slate-100 dark:border-slate-850 space-y-1">
            <span className="text-[10px] text-slate-400 font-bold block">مجموع بنك الأسئلة المنهجية</span>
            <div className="flex items-baseline gap-1">
              <span className="text-2xl font-black text-slate-800 dark:text-white font-mono">{questions.length}</span>
              <span className="text-xs text-slate-400 font-medium">سؤال</span>
            </div>
          </div>
          <div className="bg-slate-50 dark:bg-slate-950 p-4 rounded-2xl border border-slate-100 dark:border-slate-850 space-y-1">
            <span className="text-[10px] text-slate-400 font-bold block">ملخصات وملاحظات الطلاب</span>
            <div className="flex items-baseline gap-1">
              <span className="text-2xl font-black text-slate-800 dark:text-white font-mono">{studentNotes.length}</span>
              <span className="text-xs text-slate-400 font-medium">مذكرة</span>
            </div>
          </div>
          <div className="bg-slate-50 dark:bg-slate-950 p-4 rounded-2xl border border-slate-100 dark:border-slate-850 space-y-1">
            <span className="text-[10px] text-slate-400 font-bold block">سجلات حلول المقررات</span>
            <div className="flex items-baseline gap-1">
              <span className="text-2xl font-black text-slate-800 dark:text-white font-mono">{progress.length}</span>
              <span className="text-xs text-slate-400 font-medium">ملف</span>
            </div>
          </div>
        </div>
      </div>

      {/* 2. Intrusion & Password Hack Warning Logger */}
      <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-3xl p-6 space-y-4">
        <div>
          <h3 className="text-base font-black text-slate-800 dark:text-white flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-amber-500" />
            <span>سجل وإشعار التعدي ومحاولات اختراق الباسورد</span>
          </h3>
          <p className="text-xs text-slate-400 mt-1">يعمل النظام على تعقب الطلاب النشطين الذين يبذلون محاولات مستمرة لتخمين شفرة الإدارة وكتابة كلمات مرور خاطئة:</p>
        </div>

        {flaggedStudents.length === 0 ? (
          <div className="p-8 text-center text-green-600 dark:text-green-500 font-bold bg-green-50/50 dark:bg-green-950/10 rounded-2xl border border-green-100 text-xs flex items-center justify-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-green-500" />
            <span>النظام آمن ومحمي بالكامل، لا توجد أي تجاوزات مسجلة!</span>
          </div>
        ) : (
          <div className="space-y-3 max-h-60 overflow-y-auto pr-1">
            {flaggedStudents.map(stud => (
              <div
                key={stud.id}
                className="p-4 bg-amber-50/30 dark:bg-amber-950/10 border border-amber-100 dark:border-amber-950/40 rounded-2xl flex items-center justify-between gap-4"
              >
                <div className="space-y-1">
                  <span className="text-xs font-black text-slate-800 dark:text-white block">{stud.display_name}</span>
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-400 text-[10px] font-black rounded">
                      تجاوز بإنذارات: {stud.warning_attempts} محاولة خاطئة
                    </span>
                    <span className="text-[10px] text-slate-400">هوية الطالب: {stud.id}</span>
                  </div>
                </div>

                <button
                  onClick={() => handleClearWarnings(stud.id)}
                  disabled={loading}
                  className="px-3 py-1.5 bg-white dark:bg-slate-900 hover:bg-slate-50 text-indigo-600 dark:text-indigo-400 border rounded-xl text-[10px] font-bold cursor-pointer transition"
                >
                  تصفير الإنذار والمسامحة
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* 3. Dangerous Semester Reset Controls */}
      <div className="bg-white dark:bg-slate-900 border border-rose-100 dark:border-rose-950/40 rounded-3xl p-6 space-y-4">
        <div>
          <h3 className="text-base font-black text-rose-600 dark:text-rose-400 flex items-center gap-2">
            <AlertOctagon className="w-5 h-5" />
            <span>أدوات التهيئة وإعادة التعيين والتصفيات (إجراء خطير)</span>
          </h3>
          <p className="text-xs text-slate-400 mt-1">تتيح لك كمدير ومطور عام للموقع إعادة ضبط كافة تقدم دراسي وإنجازات الطلاب نهائياً لبدء عام دراسي جديد:</p>
        </div>

        {successText && (
          <div className="p-3.5 bg-emerald-50 dark:bg-emerald-950/20 border border-emerald-150 text-emerald-800 dark:text-emerald-400 text-xs font-bold rounded-xl leading-relaxed">
            {successText}
          </div>
        )}

        <div className="p-4 bg-rose-50/30 dark:bg-rose-950/10 rounded-2xl border border-dashed border-rose-200 dark:border-rose-900 space-y-4">
          <p className="text-[11px] text-rose-700 dark:text-rose-300 font-bold leading-relaxed">تنبيه: سيؤدي هذا الخيار إلى حذف كافة السجلات التراكمية، ومفكرات الطلاب، وإنجازاتهم، وحذف تتبع حل المقررات لتنشيط وبدء عام دراسي أو تيرم امتحاني جديد تماماً! يرجى الحذر قبل المضي قدماً.</p>
          
          {!showConfirmReset ? (
            <button
              onClick={() => {
                setSuccessText('');
                setShowConfirmReset(true);
              }}
              className="px-5 py-2.5 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-xl flex items-center gap-1 cursor-pointer transition shadow hover:shadow-rose-600/20"
            >
              <RotateCcw className="w-4 h-4" />
              <span>البدء في تصفير تقدم الطلاب وبدء ترم جديد...</span>
            </button>
          ) : (
            <div className="space-y-2 p-3 bg-white dark:bg-slate-950 border border-rose-200 rounded-xl">
              <span className="text-xs text-rose-800 font-bold block">⚠️ هل أنت جاد وعلى ثقة بمحو جميع درجات وتقدم الطلاب نهائياً وبدء فصل دراسي جديد؟</span>
              <div className="flex gap-2">
                <button
                  onClick={handleFullSemesterReset}
                  disabled={loading}
                  className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-xl cursor-pointer"
                >
                  {loading ? 'جاري محو البيانات...' : 'نعم، إفراغ وإفراغ جميع سجلات XP'}
                </button>
                <button
                  onClick={() => setShowConfirmReset(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 dark:text-slate-300 font-bold text-xs rounded-xl cursor-pointer"
                >
                  تراجع عن الإجراء
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

    </div>
  );
}
