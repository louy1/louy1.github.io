import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { getDevToken } from '../../lib/devToken';
import { 
  Plus, Trash2, Check, Sparkles, RefreshCw, 
  HelpCircle, ShieldAlert, BookOpen, Compass, 
  Layers, Brain, Atom, Globe, Crown, Apple, Microscope, Award
} from 'lucide-react';
import { motion } from 'motion/react';

const ICON_OPTIONS = [
  { name: 'BookOpen', icon: BookOpen, label: 'كتاب مفتوح' },
  { name: 'Brain', icon: Brain, label: 'دماغ / تفكير' },
  { name: 'Atom', icon: Atom, label: 'ذرة / فيزياء' },
  { name: 'Globe', icon: Globe, label: 'كرة أرضية' },
  { name: 'Compass', icon: Compass, label: 'بوصلة / भूगोल' },
  { name: 'Layers', icon: Layers, label: 'طبقات / مناهج' },
  { name: 'Crown', icon: Crown, label: 'تاج / تميز' },
  { name: 'Apple', icon: Apple, label: 'تفاحة / صحة' },
  { name: 'Microscope', icon: Microscope, label: 'مجهر / علوم' }
];

const COLOR_OPTIONS = [
  { name: 'amber', bgClass: 'bg-amber-500', textClass: 'text-amber-500', label: 'كهرماني / برتقالي' },
  { name: 'emerald', bgClass: 'bg-emerald-500', textClass: 'text-emerald-500', label: 'زمردي / أخضر' },
  { name: 'blue', bgClass: 'bg-blue-500', textClass: 'text-blue-500', label: 'أزرق كلاسيكي' },
  { name: 'rose', bgClass: 'bg-rose-500', textClass: 'text-rose-500', label: 'وردي / أحمر' },
  { name: 'purple', bgClass: 'bg-purple-500', textClass: 'text-purple-500', label: 'بنفسجي ملكي' },
  { name: 'indigo', bgClass: 'bg-indigo-500', textClass: 'text-indigo-500', label: 'نيلي غامق' },
];

export default function SectionsManager() {
  const { db, refreshData } = useApp();
  
  // State
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const [editingSectionId, setEditingSectionId] = useState<string | null>(null);

  // Form states
  const [title, setTitle] = useState('');
  const [slug, setSlug] = useState('');
  const [selectedIcon, setSelectedIcon] = useState('BookOpen');
  const [selectedColor, setSelectedColor] = useState('blue');

  const sectionsList = db.sections || [];
  const questionsList = db.questions || [];

  // Helper auto slug generator
  const handleTitleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setTitle(val);
    
    // Auto translate Arabic letters or spaces to clean english identifier
    const generatedSlug = val
      .trim()
      .toLowerCase()
      .replace(/[\s_]+/g, '-') // spaces to hyphen
      .replace(/[^\w-]/g, '') // remove special characters
      .substring(0, 15);
    setSlug(generatedSlug);
  };

  const handleCreateSection = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setSuccessMsg('');

    const token = getDevToken();
    if (!token) {
      setError('انتهت صلاحية الجلسة الخاصة بالمطور، يرجى تسجيل الدخول مجدداً.');
      setLoading(false);
      return;
    }

    const trimmedTitle = title.trim();
    const trimmedSlug = slug.trim().toLowerCase();

    if (!trimmedTitle) {
      setError('يرجى تحديد عنوان جذاب للقسم الدراسي الجديد.');
      setLoading(false);
      return;
    }

    if (!trimmedSlug || !/^[a-z0-9-]+$/.test(trimmedSlug)) {
      setError('يرجى كتابة رمز معرّف معتمد بالأحرف الإنجليزية والأرقام والشرطة فقط.');
      setLoading(false);
      return;
    }

    // Check conflict only when creating new
    if (!editingSectionId) {
      const exists = sectionsList.some(s => s.slug === trimmedSlug || s.id === trimmedSlug);
      if (exists) {
        setError('هناك قسم أو مادة دراسية مسجلة مسبقاً بنفس المعرّف الفريد! يرجى اختيار رمز معرّف آخر.');
        setLoading(false);
        return;
      }
    }

    try {
      const response = await fetch('/api/dev-action', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          token,
          action: 'upsert_section',
          payload: {
            id: editingSectionId || trimmedSlug, // Keep ID when editing
            slug: editingSectionId ? sectionsList.find(s => s.id === editingSectionId)?.slug || trimmedSlug : trimmedSlug,
            title: trimmedTitle,
            icon: selectedIcon,
            color: selectedColor,
            sort: sectionsList.length + 1,
            is_custom: true
          }
        })
      });

      const data = await response.json();
      if (response.ok) {
        setSuccessMsg(editingSectionId ? `🟢 تم تحديث بيانات المادة الدراسية (${trimmedTitle}) بنجاح!` : `🟢 تم إضافة المادة الدراسية الجديدة (${trimmedTitle}) وتفعيل القسم بالبوابة حياً بنجاح!`);
        setTitle('');
        setSlug('');
        setEditingSectionId(null);
        await refreshData();
      } else {
        setError(data.error || 'فشل تخليد القسم الجديد بالخادم.');
      }
    } catch (err) {
      setError('خطأ في الاتصال بالشبكة لإنشاء وتوثيق المادة.');
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteSection = async (sectionId: string, sectionTitle: string) => {
    const isConfirmed = window.confirm(`⚠️ تحذير نهائي: هل أنت متأكد تماماً من حذف المادة الدراسية "${sectionTitle}" بالكامل؟\n\nتنبيه: هذا الإجراء سيؤدي إلى حذف جميع أسئلة المادة، والأوسمة وحصيلة نقاط للطلاب المرتبطة بها نهائياً!`);
    if (!isConfirmed) return;

    setLoading(true);
    setError('');
    setSuccessMsg('');

    const token = getDevToken();
    try {
      const response = await fetch('/api/dev-action', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          token,
          action: 'delete_section',
          payload: { id: sectionId }
        })
      });
      if (response.ok) {
        setSuccessMsg(`🗑️ تم إقصاء المادة وحذف كافة البيانات والأسئلة التابعة لقسم "${sectionTitle}" بنجاح.`);
        await refreshData();
      } else {
        const data = await response.json();
        setError(data.error || 'فشل حذف القسم بالخادم.');
      }
    } catch (e) {
      setError('حدث عطل فني في الاتصال بالشبكة لإتمام إقالة المادة.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 text-right font-bold" dir="rtl">
      
      {/* Right side - ADD FORM (Col span 5) */}
      <div className="lg:col-span-5 space-y-6">
        
        {/* Decorative Header Block */}
        <div className="p-6 bg-gradient-to-br from-amber-500/10 via-amber-600/5 to-transparent border border-amber-500/20 dark:border-amber-500/10 rounded-3xl space-y-3 relative overflow-hidden backdrop-blur-xs">
          <div className="absolute top-0 left-0 w-24 h-24 bg-amber-500/10 rounded-full blur-2xl pointer-events-none" />
          
          <div className="flex items-center gap-2 mr-1">
            <div className="p-2 bg-amber-500 text-white rounded-xl shadow-md">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-black text-slate-800 dark:text-amber-400 flex items-center gap-1.5">
                <span>تخصيص وإضافة أقسام المواد للطلاب</span>
                <Sparkles className="w-3.5 h-3.5 text-amber-500 animate-pulse" />
              </h4>
              <p className="text-[10px] text-slate-400 dark:text-slate-500 mt-0.5">
                توسعة المنصة عبر إضافة مستويات تعليمية أو مواد منفصلة مخصصة للدراسة والاختبار بمرونة تامة.
              </p>
            </div>
          </div>
        </div>

        {/* Section Adder Form Container */}
        <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 p-6 rounded-3xl shadow-sm space-y-5">
          <div className="border-b border-slate-50 dark:border-slate-850 pb-3">
            <h4 className="text-xs font-black text-slate-800 dark:text-white flex items-center gap-1.5">
              <Plus className="w-4 h-4 text-amber-500" />
              <span>{editingSectionId ? 'تحديث وتعديل المادة الدراسية' : 'تهيئة وتوثيق مادة دراسية جديدة'}</span>
            </h4>
            <p className="text-[10px] text-slate-400 mt-1">{editingSectionId ? 'قم بتعديل المسميات وحزمتها اللونية وشعار البوابة بسهولة:' : 'املاً البيانات التالية ليتم إفراج المادة فوراً لجميع الطلاب والمشرفين:'}</p>
          </div>

          <form onSubmit={handleCreateSection} className="space-y-4">
            
            {/* Input 1: Title (Arabic display label) */}
            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-slate-600 mr-1">نوع المادة / اسم القسم الدراسي العربي:</label>
              <input
                type="text"
                required
                placeholder="مثال: أحياء الصف الثالث، لغة إنجليزية"
                value={title}
                onChange={handleTitleChange}
                className="w-full px-3.5 py-2.5 text-xs bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-none focus:ring-1 focus:ring-amber-500 font-bold transition text-right"
              />
            </div>

            {/* Input 2: English unique slug identifier */}
            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-slate-600 mr-1 flex items-center gap-1">
                <span>الرمز الفريد للقسم (slug بالإنجليزية):</span>
                <HelpCircle className="w-3 h-3 text-slate-400" title="معرّف بالإنجليزية لا يحتوي على مسافات، يربط الأسئلة بهذا القسم بشكل دائم." />
              </label>
              <input
                type="text"
                required
                placeholder="مثال: biology, english-level-1"
                value={slug}
                onChange={(e) => setSlug(e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, ''))}
                className="w-full px-3.5 py-2.5 text-xs bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-none focus:ring-1 focus:ring-amber-500 font-mono transition text-left"
              />
            </div>

            {/* Input 3: Icon Selector */}
            <div className="space-y-1.55">
              <label className="block text-xs font-bold text-slate-600 mr-1">شعار وأيقونة القسم التعليمي:</label>
              <div className="grid grid-cols-5 gap-1.5">
                {ICON_OPTIONS.map((opt) => {
                  const IconComp = opt.icon;
                  return (
                    <button
                      key={opt.name}
                      type="button"
                      onClick={() => setSelectedIcon(opt.name)}
                      title={opt.label}
                      className={`p-2 rounded-xl border text-center transition cursor-pointer flex flex-col items-center justify-center ${
                        selectedIcon === opt.name
                          ? 'border-amber-500 bg-amber-500/10 text-amber-600 dark:text-amber-400'
                          : 'border-slate-100 dark:border-slate-800 text-slate-450 hover:bg-slate-50'
                      }`}
                    >
                      <IconComp className="w-4 h-4" />
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Input 4: Color Picker Grid */}
            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-slate-600 mr-1">الحزمة اللونية المميزة للأزرار والمؤشرات:</label>
              <div className="grid grid-cols-6 gap-2">
                {COLOR_OPTIONS.map((opt) => (
                  <button
                    key={opt.name}
                    type="button"
                    onClick={() => setSelectedColor(opt.name)}
                    title={opt.label}
                    className={`w-full h-8 rounded-xl border flex items-center justify-center transition cursor-pointer relative ${
                      selectedColor === opt.name
                        ? 'border-slate-900 dark:border-white ring-2 ring-amber-500/30'
                        : 'border-transparent'
                    }`}
                  >
                    <span className={`w-5 h-5 rounded-lg ${opt.bgClass}`} />
                    {selectedColor === opt.name && (
                      <Check className="w-3 h-3 text-white absolute" />
                    )}
                  </button>
                ))}
              </div>
            </div>

            {/* Feedback messages */}
            {error && (
              <div className="p-2.5 bg-rose-50 text-rose-500 text-[10px] font-bold rounded-xl border border-rose-100">
                {error}
              </div>
            )}

            {successMsg && (
              <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 rounded-xl text-center text-[10.5px] font-bold leading-relaxed">
                {successMsg}
              </div>
            )}

            <div className="flex gap-2">
              <button
                id="section-adder-submit-btn"
                type="submit"
                disabled={loading}
                className="flex-grow py-3.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white font-black rounded-xl text-xs transition shadow-xs cursor-pointer flex items-center justify-center gap-1.5 select-none"
              >
                {loading ? (
                  <span className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                ) : (
                  <>
                    <Plus className="w-4 h-4 text-white" />
                    <span>{editingSectionId ? 'تأكيد وحفظ التغييرات' : 'تثبيت وإصدار القسم التعليمي الجديد'}</span>
                  </>
                )}
              </button>
              {editingSectionId && (
                <button
                  type="button"
                  onClick={() => {
                    setEditingSectionId(null);
                    setTitle('');
                    setSlug('');
                  }}
                  className="px-4 py-3 bg-slate-100 hover:bg-slate-200 text-slate-705 dark:bg-slate-800 dark:hover:bg-slate-750 dark:text-slate-350 font-bold rounded-xl text-xs transition cursor-pointer"
                >
                  إلغاء التعديل
                </button>
              )}
            </div>
          </form>
        </div>
      </div>

      {/* Left side - SECTIONS LIST (Col span 7) */}
      <div className="lg:col-span-7 space-y-4">
        
        {/* Quick Sync Header block */}
        <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 p-4 rounded-3xl shadow-sm flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-xs font-black text-slate-800 dark:text-white">جدول وحصيلة الأقسام الحالية بالبوابة</span>
            <span className="text-[9px] bg-amber-500/10 text-amber-600 px-2.5 py-0.5 rounded-full">
              إجمالي: {sectionsList.length} أقسام
            </span>
          </div>
          <button
            onClick={refreshData}
            className="p-1.5 border border-slate-100 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-950 rounded-xl text-slate-400 transition"
            title="مزامنة تحديثات الأقسام بالخادم"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable list container */}
        <div className="space-y-3 max-h-[560px] overflow-y-auto pr-1">
          {sectionsList.length === 0 ? (
            <div className="bg-white dark:bg-slate-900 border border-slate-150 dark:border-slate-800 p-12 rounded-3xl text-center space-y-3">
              <div className="w-12 h-12 bg-slate-50 dark:bg-slate-950 rounded-full flex items-center justify-center text-xl mx-auto">
                📚
              </div>
              <div>
                <h5 className="text-xs font-black text-slate-700 dark:text-slate-350">لا توجد أقسام دراسية بالبوابة مجملاً</h5>
                <p className="text-[10px] text-slate-450 mt-1 max-w-xs mx-auto">
                  يرجى تهيئة القسم التعليمي الأول عبر ملى بيانات الاستمارة الجانبية.
                </p>
              </div>
            </div>
          ) : (
            sectionsList.map((sect: any) => {
              // Extract icon
              const iconOption = ICON_OPTIONS.find(o => o.name === sect.icon) || ICON_OPTIONS[0];
              const IconComp = iconOption.icon;

              // Extract color
              const colorOption = COLOR_OPTIONS.find(c => c.name === sect.color) || COLOR_OPTIONS[0];

              // Calculate question count
              const linkedQuestions = questionsList.filter((q: any) => q.section_id === sect.id || q.section_id === sect.slug);

              return (
                <div
                  key={sect.id}
                  className="p-4 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl flex flex-col sm:flex-row items-center gap-4 transition duration-200 hover:shadow-xs hover:border-amber-500/20"
                >
                  
                  {/* Icon Block */}
                  <div className={`w-12 h-12 rounded-2xl ${colorOption.bgClass} text-white flex items-center justify-center flex-shrink-0 shadow-sm`}>
                    <IconComp className="w-5 h-5" />
                  </div>

                  {/* Metadata detailing */}
                  <div className="flex-grow text-center sm:text-right space-y-1">
                    <div className="flex flex-wrap items-center justify-center sm:justify-start gap-1.5">
                      <span className="text-xs font-bold text-slate-800 dark:text-white font-sans">
                        {sect.title}
                      </span>
                      {sect.is_custom ? (
                        <span className="text-[8px] font-black bg-purple-500 text-white px-2 py-0.5 rounded-full">
                          مادة مضافة مخصصة
                        </span>
                      ) : (
                        <span className="text-[8px] font-black bg-blue-500 text-white px-2 py-0.5 rounded-full">
                          مادة قياسية مدمجة
                        </span>
                      )}
                    </div>

                    <div className="text-[9.5px] text-slate-400 dark:text-slate-500 font-semibold flex flex-wrap items-center justify-center sm:justify-start gap-3">
                      <span>🏷️ معرّف الكود: <code className="font-mono bg-slate-50 dark:bg-slate-950 px-1 border border-slate-100 rounded">{sect.slug}</code></span>
                      <span>❓ إجمالي الأسئلة: <strong className="text-slate-700 dark:text-slate-350 font-black">{linkedQuestions.length} سؤال</strong></span>
                    </div>
                  </div>

                  {/* Actions (Force delete only possible on custom sections to keep default structure intact) */}
                  <div className="shrink-0 self-center flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => {
                        setEditingSectionId(sect.id);
                        setTitle(sect.title);
                        setSlug(sect.slug);
                        setSelectedIcon(sect.icon || 'BookOpen');
                        setSelectedColor(sect.color || 'blue');
                      }}
                      className="p-2 sm:p-2.5 bg-indigo-50 dark:bg-slate-800 hover:bg-indigo-100 dark:hover:bg-slate-755 text-indigo-550 dark:text-indigo-400 rounded-xl border border-indigo-100/20 hover:text-indigo-600 transition flex items-center justify-center cursor-pointer"
                      title="تعديل المادة وبياناتها"
                    >
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" /></svg>
                    </button>

                    {sect.is_custom ? (
                      <button
                        onClick={() => handleDeleteSection(sect.id, sect.title)}
                        className="p-2 sm:p-2.5 bg-rose-50 hover:bg-rose-100 text-rose-500 rounded-xl border border-rose-100/20 hover:text-rose-600 transition flex items-center justify-center cursor-pointer"
                        title="حذف وإبطال مفعول هذا القسم بكافة أسئلته"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    ) : (
                      <span className="text-[8px] text-slate-400 border border-slate-100 dark:border-slate-850 px-2 py-1 rounded-lg select-none bg-slate-50 dark:bg-slate-950 cursor-not-allowed">
                        قسم محمي دائم
                      </span>
                    )}
                  </div>

                </div>
              );
            })
          )}
        </div>

        {/* Informative advice alert box */}
        <div className="p-4 bg-slate-50 dark:bg-slate-950 border border-slate-105 dark:border-slate-800 rounded-2xl flex items-start gap-2 text-[10px] text-slate-400 leading-relaxed font-bold">
          <ShieldAlert className="w-4 h-4 text-amber-500 mt-0.5 shrink-0" />
          <div>
            <span className="font-black block text-slate-600 dark:text-slate-300">موصلية هيكلة الأقسام الذكية:</span>
            <span>
              جميع الأقسام التي تصدرها هنا ستظهر مباشرة للطلاب في واجهة الامتحان الرئيسية كبطاقة مادة مؤهلة لحصد نقاط الـ XP، ويمكن للمطور بناء وإضافة أسئلة بداخلها فوراً من خلال منتقي المادة في لوحة الأسئلة الشاملة.
            </span>
          </div>
        </div>

      </div>

    </div>
  );
}
