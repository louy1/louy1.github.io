import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { getDevToken } from '../../lib/devToken';
import { News } from '../../types';
import { Newspaper, Trash2, Plus } from 'lucide-react';

export default function NewsManager() {
  const { news, refreshData } = useApp();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // Form states
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !body.trim()) {
      setError('الرجاء تعبئة العنوان والوصف للمنشور.');
      return;
    }

    setLoading(true);
    setError('');

    const token = getDevToken();
    const payload: News = {
      id: `news_${Math.random().toString(36).substr(2, 9)}`,
      title: title.trim(),
      body: body.trim(),
      published_at: new Date().toISOString()
    };

    try {
      const response = await fetch('/api/dev-action', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          token,
          action: 'upsert_news',
          payload
        })
      });

      if (response.ok) {
        setTitle('');
        setBody('');
        await refreshData();
      } else {
        const data = await response.json();
        setError(data.error || 'فشل تحديث المنشور بالขادم.');
      }
    } catch (err) {
      setError('فشل الاتصال بالشبكة لحفظ الخبر.');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (newsId: string) => {
    setLoading(true);
    const token = getDevToken();

    try {
      const response = await fetch('/api/dev-action', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          token,
          action: 'delete_news',
          payload: { id: newsId }
        })
      });

      if (response.ok) {
        await refreshData();
      } else {
        console.error('فشل عملية الإزالة في الخادم.');
      }
    } catch (e) {
      console.error('خطأ في الاتصال بقاعدة البيانات.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 text-right" dir="rtl">
      
      {/* Right side list column */}
      <div className="lg:col-span-2 space-y-4">
        <div>
          <h4 className="text-base font-bold text-slate-800 dark:text-white flex items-center gap-1.5">
            <Newspaper className="w-5 h-5 text-blue-500" />
            <span>لوحة المنشورات التربوية والأخبار ({news.length})</span>
          </h4>
          <p className="text-xs text-slate-400 mt-0.5">البلاغات والقرارات الأكاديمية والوزارية لبثها بالشاشة الجانبية:</p>
        </div>

        <div className="space-y-4">
          {news.map(item => (
            <div
              key={item.id}
              className="p-5 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl flex items-center justify-between shadow-sm gap-4"
            >
              <div>
                <h5 className="font-bold text-sm text-slate-800 dark:text-white leading-snug">{item.title}</h5>
                <p className="text-xs text-slate-400 mt-1.5 font-bold">بث في: {new Date(item.published_at).toLocaleString('ar-EG')}</p>
                <p className="text-xs text-slate-500 mt-1 line-clamp-1">{item.body}</p>
              </div>

              <button
                onClick={() => handleDelete(item.id)}
                className="p-1.5 bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/20 text-rose-500 rounded-lg cursor-pointer transition"
                title="إزالة الخبر"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Write News Form */}
      <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 p-6 rounded-3xl h-fit space-y-6 shadow-sm">
        <div>
          <h4 className="text-base font-bold text-slate-800 dark:text-white">نشر بيان تربوي جديد</h4>
          <p className="text-xs text-slate-400 mt-1">املاً استمارات المنشور لإعلام جميع غرف الطلاب فورا المعاينة:</p>
        </div>

        <form onSubmit={handleCreate} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-500 mb-1.5">أبرز ترويسة وعنوان للخبر:</label>
            <input
              id="news-title-input"
              type="text"
              placeholder="مثال: بدء كسر التحدي التقييمي الأول"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-3.5 py-2 text-sm bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-800 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-500 mb-1.5">مضمون ومنطوق الخبر التربوي:</label>
            <textarea
              id="news-body-input"
              rows={4}
              placeholder="تبدأ فعاليات الاختبارات بموجب الملحق الدراسي ابتداء من مطلع الفصل..."
              value={body}
              onChange={(e) => setBody(e.target.value)}
              className="w-full px-3.5 py-2 text-sm bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-800 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-right leading-relaxed"
            />
          </div>

          {error && <span className="text-xs text-rose-500 font-bold block">{error}</span>}

          <button
            id="news-add-btn"
            type="submit"
            disabled={loading}
            className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>نشر بث الأخبار الآن</span>
          </button>
        </form>
      </div>

    </div>
  );
}
