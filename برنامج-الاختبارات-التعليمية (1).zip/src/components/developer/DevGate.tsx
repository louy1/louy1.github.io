import React, { useState } from 'react';
import { getDevToken, setDevToken, setDevRole } from '../../lib/devToken';
import { useApp } from '../../context/AppContext';
import { ShieldAlert, Key, Lock } from 'lucide-react';
import { motion } from 'motion/react';

interface DevGateProps {
  onSuccess: () => void;
}

export default function DevGate({ onSuccess }: DevGateProps) {
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const { student } = useApp();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!password.trim()) return;

    setLoading(true);
    setError('');

    try {
      const response = await fetch('/api/dev-auth', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          password: password.trim(),
          studentId: student?.id,
          studentName: student?.display_name,
          attemptedGate: 'supervisor_gate'
        })
      });

      if (response.ok) {
        const data = await response.json();
        setDevToken(data.token);
        setDevRole(data.role || 'master');
        onSuccess();
      } else {
        const data = await response.json();
        setError(data.error || 'رمز المطور المرسل غير مسموح به بالخادم.');
      }
    } catch (err) {
      setError('فشل التفاوض مع ميكانيزم الخادم للتحقق من الشفرة.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-md mx-auto text-center space-y-6 py-12" dir="rtl">
      
      <div className="w-16 h-16 bg-amber-500/10 text-amber-500 rounded-3xl mx-auto flex items-center justify-center border border-amber-500/20">
        <Lock className="w-8 h-8" />
      </div>

      <div className="space-y-1.5">
        <h3 className="text-xl font-bold text-slate-800 dark:text-white">منطقة المطورين المقفلة</h3>
        <p className="text-xs text-slate-400">الرجاء إدخال رمز المرور السري للدخول للوحة الإعدادات الكاملة:</p>
      </div>

      <form onSubmit={handleSubmit} className="p-6 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-3xl shadow-md space-y-4 text-right">
        <div>
          <label htmlFor="dev-gate-password" className="block text-xs font-semibold text-slate-500 mb-2 mr-1">ادخل كلمة المرور:</label>
          <div className="relative">
            <input
              id="dev-gate-password"
              type="password"
              placeholder="ادخل كلمة المرور"
              value={password}
              onChange={(e) => {
                setPassword(e.target.value);
                if (error) setError('');
              }}
              className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 text-right pr-11 text-sm font-mono"
              autoFocus
            />
            <div className="absolute inset-y-0 right-0 pr-4 flex items-center pointer-events-none text-slate-400">
              <Key className="w-4 h-4 text-slate-400" />
            </div>
          </div>
        </div>

        {error && (
          <span className="text-xs text-rose-500 font-bold block bg-rose-50 dark:bg-rose-950/10 p-3 rounded-lg border border-rose-100 dark:border-rose-950/40">{error}</span>
        )}

        <button
          type="submit"
          disabled={loading || !password}
          className="w-full py-3.5 bg-amber-500 hover:bg-amber-600 text-white font-bold rounded-xl shadow-md transition cursor-pointer text-sm flex items-center justify-center gap-1.5"
        >
          {loading ? (
            <span className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
          ) : (
            <>
              <ShieldAlert className="w-4 h-4" />
              <span>مصادقة الدخول كمسؤول</span>
            </>
          )}
        </button>
      </form>

    </div>
  );
}
