import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Trophy, BookOpen, AlertCircle, UserCheck, UserPlus, Key, Info
} from 'lucide-react';
import { motion } from 'motion/react';
import { getStableDeviceID } from '../lib/device';

// Client-side persistent unique device tracking derived from secure hardware fingerprint
const getDeviceToken = getStableDeviceID;

export default function OnboardingDialog() {
  const { setStudent, uiSettings } = useApp();
  
  // Dialog modes: 'login' or 'register'
  const [mode, setMode] = useState<'login' | 'register'>('login');
  
  // Login form states
  const [nameInput, setNameInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  
  // Register form states
  const [regCode, setRegCode] = useState('');
  const [regName, setRegName] = useState('');
  const [regPassword, setRegPassword] = useState('');

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  const disableAccountCreation = uiSettings['disable_account_creation'] === 'on';

  React.useEffect(() => {
    if (disableAccountCreation && mode !== 'login') {
      setMode('login');
    }
  }, [disableAccountCreation, mode]);

  const welcomeMessage = uiSettings['welcome_message'] || 'مرحباً بك في بوابتك لتطوير المهارات التعليمية وبناء المعرفة الفعالة مع المطور!';
  const appTitle = uiSettings['app_title_ar'] || 'أكاديمية الاختبارات التعليمية';

  const toggleMode = () => {
    if (disableAccountCreation) return;
    setError('');
    setSuccessMessage('');
    if (mode === 'login') {
      setMode('register');
    } else {
      setMode('login');
    }
  };

  // Submit handler for student registration
  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccessMessage('');

    const code = regCode.trim();
    const name = regName.trim();
    const password = regPassword.trim();

    if (!code) {
      setError('الرجاء إدخال كود التفعيل المخصص المكون من رموز.');
      return;
    }

    if (!name) {
      setError('الرجاء إدخال الاسم الثلاثي بالكامل.');
      return;
    }

    if (!password) {
      setError('الرجاء تعيين كلمة مرور جديدة للحساب.');
      return;
    }

    // Word validation (Triple Name check)
    const parts = name.split(/\s+/);
    if (parts.length < 3) {
      setError('يرجى كتابة الاسم الثلاثي بالكامل (الاسم، اسم الأب والجد) لمنع تداخل الحسابات ولتأكيد العضوية.');
      return;
    }

    setLoading(true);

    try {
      const response = await fetch('/api/students/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          code,
          name,
          studentPassword: password,
          deviceId: getDeviceToken()
        })
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'فشلت عملية إنشاء الحساب وتفعيل الرمز.');
      }

      setSuccessMessage('تهانينا، تم إنشاء الحساب بنجاح وتفعيل كود الاشتراك! يمكنك الآن تسجيل الدخول مباشرة بالأسفل.');
      
      // Auto-populate the logins form to make it seamless
      setNameInput(name);
      setPasswordInput(password);

      // Reset values
      setRegCode('');
      setRegName('');
      setRegPassword('');
      setMode('login');
    } catch (err: any) {
      setError(err.message || 'حدث خطأ أثناء الاتصال بالخادم لإنشاء الحساب.');
    } finally {
      setLoading(false);
    }
  };

  // Submit handler for the login form
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccessMessage('');
    
    const trimmedName = nameInput.trim();
    const trimmedPassword = passwordInput.trim();

    if (!trimmedName) {
      setError('الرجاء إدخال اسمك واسم الأب والجد بالكامل.');
      return;
    }

    if (!trimmedPassword) {
      setError('الرجاء كتابة كلمة المرور للدخول لحسابك وتأمين هويتك.');
      return;
    }

    // Checking if it's the developer email:
    const devEmailSetting = uiSettings['dev_email']?.trim() || 'Developer060@gmail.com';
    const isDeveloper = trimmedName.toLowerCase() === devEmailSetting.toLowerCase();

    // Word validation for everyone except developers
    if (!isDeveloper) {
      const parts = trimmedName.split(/\s+/);
      if (parts.length < 3) {
        setError('يرجى كتابة الاسم الثلاثي بالكامل (الاسم، اسم الأب والجد) لمنع التداخل وحفظ سجلك التعليمي.');
        return;
      }
    }

    setLoading(true);

    try {
      // Under the hood, we supply the schoolPin automatically from the system settings
      const schoolPinSetting = uiSettings['school_pin_code'] || 'awdrgyjilp';

      const response = await fetch('/api/students/onboard', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          name: trimmedName,
          studentPassword: trimmedPassword,
          schoolPin: schoolPinSetting,
          deviceId: getDeviceToken() 
        })
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'عذراً، فشلت عملية التحقق أو تسجيل حسابك الجديد.');
      }

      setStudent(data.student);
    } catch (err: any) {
      setError(err.message || 'حدث عطل أثناء تهيئة حسابك. حاول ثانية.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md overflow-y-auto" dir="rtl">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        transition={{ duration: 0.4, ease: 'easeOut' }}
        className="w-full max-w-lg bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-3xl shadow-2xl overflow-hidden relative my-8"
      >
        {/* Top gradient boundary line */}
        <div className="absolute top-0 left-0 right-0 h-2 bg-gradient-to-r from-amber-500 via-yellow-500 to-rose-500" />
        
        <div className="p-8 relative">
          <div className="text-center">
            
            {/* Visual Icon Header area */}
            <div className="mx-auto w-16 h-16 bg-amber-50 dark:bg-amber-950/40 rounded-2xl flex items-center justify-center mb-4 text-amber-500 border border-amber-100 dark:border-amber-900">
              <Trophy className="w-8 h-8 animate-bounce" />
            </div>

            <h2 className="text-2xl font-black text-slate-900 dark:text-white mb-2 leading-snug">
              {appTitle}
            </h2>
            
            <p className="text-slate-500 dark:text-slate-400 text-xs mb-6 font-bold leading-relaxed max-w-sm mx-auto">
              {welcomeMessage}
            </p>

            {/* ERROR DISPLAY */}
            {error && (
              <motion.div 
                initial={{ opacity: 0, y: -5 }}
                animate={{ opacity: 1, y: 0 }}
                className="p-3.5 mb-5 bg-rose-50 dark:bg-rose-950/30 border border-rose-100 dark:border-rose-900 text-rose-600 dark:text-rose-400 text-xs rounded-2xl font-bold leading-relaxed text-right flex items-start gap-1.5"
              >
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-rose-500" />
                <span>{error}</span>
              </motion.div>
            )}

            {/* SUCCESS DISPLAY */}
            {successMessage && (
              <motion.div 
                initial={{ opacity: 0, y: -5 }}
                animate={{ opacity: 1, y: 0 }}
                className="p-3.5 mb-5 bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-100 dark:border-emerald-900 text-emerald-600 dark:text-emerald-400 text-xs rounded-2xl font-bold leading-relaxed text-right flex items-start gap-1.5"
              >
                <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 mt-1.5 shrink-0" />
                <span>{successMessage}</span>
              </motion.div>
            )}

            {/* MODE SWITCHER COMPONENT */}
            {!disableAccountCreation && (
              <div className="grid grid-cols-2 bg-slate-50 dark:bg-slate-950 p-1 rounded-2xl border border-slate-100 dark:border-slate-850 mb-6 font-bold text-xs">
                <button
                  type="button"
                  onClick={() => { setMode('login'); setError(''); setSuccessMessage(''); }}
                  className={`py-2 px-3 rounded-xl transition ${mode === 'login' ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-sm' : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-300'}`}
                >
                  تسجيل الدخول
                </button>
                <button
                  type="button"
                  onClick={() => { setMode('register'); setError(''); setSuccessMessage(''); }}
                  className={`py-2 px-3 rounded-xl transition ${mode === 'register' ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-sm' : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-300'}`}
                >
                  إنشاء حساب جديد
                </button>
              </div>
            )}

            {/* MODE: LOGIN FORM */}
            {mode === 'login' ? (
              <form onSubmit={handleSubmit} className="space-y-5 text-right font-bold">
                
                {/* INPUT 1: Full Name */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2 mr-1">
                    الاسم واسم الأب والجد (الاسم الكامل ثلاثياً):
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="مثال: أحمد عبدالملك الصنعاني"
                    value={nameInput}
                    onChange={(e) => setNameInput(e.target.value)}
                    disabled={loading}
                    className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-800 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 text-right font-medium transition-all text-xs"
                  />
                </div>

                {/* INPUT 2: Password */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2 mr-1">
                    كلمة المرور الخاصة بحسابك الدراسي:
                  </label>
                  <input
                    type="password"
                    required
                    placeholder="أدخل كلمة المرور الخاصة بحسابك"
                    value={passwordInput}
                    onChange={(e) => setPasswordInput(e.target.value)}
                    disabled={loading}
                    className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-800 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 text-center font-mono transition-all text-xs"
                  />
                </div>

                {/* Unified Action Button */}
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-3.5 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-400 text-white rounded-2xl font-black transition shadow cursor-pointer text-xs flex items-center justify-center gap-1.5"
                >
                  {loading ? (
                    <span className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <>
                      <UserCheck className="w-4 h-4" />
                      <span>{disableAccountCreation ? 'الدخول والبدء المباشر بالتطبيق' : 'تسجيل الدخول ومتابعة مساق الدراسة'}</span>
                    </>
                  )}
                </button>

                <div className="pt-2 text-center">
                  {!disableAccountCreation ? (
                    <button
                      type="button"
                      onClick={toggleMode}
                      className="text-[11px] text-blue-500 hover:text-blue-600 dark:text-blue-400 transition"
                    >
                      ليس لديك حساب؟ انقر هنا لتفعيل كود التفعيل وإنشاء حساب جديد.
                    </button>
                  ) : (
                    <div className="px-3 py-2 bg-emerald-500/10 text-emerald-700 dark:text-emerald-450 border border-emerald-500/15 rounded-xl text-[11px] font-extrabold flex items-center gap-1.5 justify-center">
                      🔐 نظام تسجيل الدخول المباشر مفعل: اكتب اسمك والباسوورد للدخول وبناء ملفك فوراً!
                    </div>
                  )}
                </div>
              </form>
            ) : (
              /* MODE: REGISTER FORM */
              <form onSubmit={handleRegisterSubmit} className="space-y-5 text-right font-bold">
                
                {/* REG INPUT 1: Activation code */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2 mr-1 flex items-center gap-1">
                    <Key className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                    <span>كود التفعيل المخصص لمرة واحدة (الكود المكتسب):</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="أدخل الرمز التعريفي / كود التفعيل المخصص"
                    value={regCode}
                    onChange={(e) => setRegCode(e.target.value)}
                    disabled={loading}
                    className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-800 rounded-2xl focus:outline-none focus:ring-2 focus:ring-amber-500 text-center font-mono font-medium transition-all text-xs"
                  />
                  <span className="text-[10px] font-bold text-slate-400 mt-1 block mr-1 leading-relaxed">
                    * كود التفعيل صالح للاستخدام مرة واحدة لربطه مع حسابك وباسمك فقط.
                  </span>
                </div>

                {/* REG INPUT 2: Full name */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2 mr-1">
                    اسم المستخدم المطلوب (الاسم الكامل ثلاثياً):
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="اكتب اسم الطالب الكامل ثلاثياً"
                    value={regName}
                    onChange={(e) => setRegName(e.target.value)}
                    disabled={loading}
                    className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-800 rounded-2xl focus:outline-none focus:ring-2 focus:ring-amber-500 text-right font-medium transition-all text-xs"
                  />
                </div>

                {/* REG INPUT 3: Chosen password */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2 mr-1">
                    اختر تعيين كلمة مرور قوية لحسابك الجديد:
                  </label>
                  <input
                    type="password"
                    required
                    placeholder="أدخل باسوورد الدخول الخاص بك"
                    value={regPassword}
                    onChange={(e) => setRegPassword(e.target.value)}
                    disabled={loading}
                    className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-800 rounded-2xl focus:outline-none focus:ring-2 focus:ring-amber-500 text-center font-mono transition-all text-xs"
                  />
                </div>

                {/* Submit Account Creation button */}
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-3.5 bg-amber-500 hover:bg-amber-600 disabled:bg-slate-400 text-white rounded-2xl font-black transition shadow cursor-pointer text-xs flex items-center justify-center gap-1.5"
                >
                  {loading ? (
                    <span className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <>
                      <UserPlus className="w-4 h-4" />
                      <span>تأكيد إنشاء الحساب وتفعيل الرمز الدراسي</span>
                    </>
                  )}
                </button>

                <div className="pt-2 text-center">
                  <button
                    type="button"
                    onClick={toggleMode}
                    className="text-[11px] text-amber-600 hover:text-amber-700 dark:text-amber-400 transition"
                  >
                    تبحث عن تسجيل الدخول الحساب؟ اضغط العودة للواجهة السابقة.
                  </button>
                </div>
              </form>
            )}

          </div>

          {/* Footer info panels */}
          <div className="mt-8 pt-6 border-t border-slate-100 dark:border-slate-800 flex justify-center gap-6 text-slate-405 dark:text-slate-600 text-xs">
            <div className="flex items-center gap-1.5 font-bold">
              <Trophy className="w-4 h-4 text-amber-500" />
              <span>أولوية التعلم والتميز الأكاديمي</span>
            </div>
            <div className="flex items-center gap-1.5 font-bold">
              <BookOpen className="w-4 h-4 text-purple-400" />
              <span>مراجعة فورية مع المشرفين</span>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
