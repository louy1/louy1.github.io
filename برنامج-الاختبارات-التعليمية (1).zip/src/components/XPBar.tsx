import { Trophy, Flame, Zap } from 'lucide-react';
import { motion } from 'motion/react';

interface XPBarProps {
  totalXp: number;
}

export default function XPBar({ totalXp }: XPBarProps) {
  const currentLevel = Math.floor(totalXp / 100) + 1;
  const xpInCurrentLevel = totalXp % 100;
  const nextLevelXp = 100;
  const progressPercent = Math.min(100, Math.max(0, (xpInCurrentLevel / nextLevelXp) * 100));

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-3xl p-6 shadow-sm relative overflow-hidden" dir="rtl">
      {/* Decorative top background elements */}
      <div className="absolute top-0 left-0 w-24 h-24 bg-amber-500/5 blur-2xl rounded-full" />
      <div className="absolute bottom-0 right-0 w-24 h-24 bg-blue-500/5 blur-2xl rounded-full" />

      <div className="flex flex-col md:flex-row items-center justify-between gap-4 relative z-10">
        
        {/* Left item: Level Indicator Badge */}
        <div className="flex items-center gap-4 text-right">
          <div className="w-14 h-14 bg-amber-500 dark:bg-amber-600 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-amber-500/20 relative">
            <span className="text-xl font-black font-mono">{currentLevel}</span>
            <div className="absolute -top-1 -right-1">
              <Flame className="w-4 h-4 text-amber-300 fill-amber-400 animate-pulse" />
            </div>
          </div>
          <div>
            <h4 className="font-bold text-slate-800 dark:text-white flex items-center gap-1.5 leading-snug">
              <span>المستوى الحالي</span>
              <span className="text-xs text-amber-500 font-mono">({totalXp} XP)</span>
            </h4>
            <p className="text-xs text-slate-400 dark:text-slate-500 mt-1 leading-relaxed">
              تحتاج إلى <span className="font-bold font-mono text-slate-600 dark:text-slate-300">{nextLevelXp - xpInCurrentLevel} XP</span> للمستوى التالي
            </p>
          </div>
        </div>

        {/* Middle item: Dynamic Progress Slider bar */}
        <div className="flex-grow w-full md:max-w-xl">
          <div className="flex justify-between items-center text-[10px] uppercase font-bold text-slate-400 dark:text-slate-500 mb-2">
            <span className="font-mono">مستوى {currentLevel}</span>
            <span className="font-mono">مستوى {currentLevel + 1}</span>
          </div>
          <div className="w-full h-3 bg-slate-100 dark:bg-slate-950 rounded-full overflow-hidden relative border border-slate-200/45 dark:border-slate-800/40">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${progressPercent}%` }}
              transition={{ duration: 0.6, ease: 'easeOut' }}
              className="h-full bg-gradient-to-r from-amber-500 via-orange-500 to-yellow-500 rounded-full relative"
            >
              <div className="absolute inset-0 bg-[linear-gradient(45deg,rgba(255,255,255,.15)_25%,transparent_25%,transparent_50%,rgba(255,255,255,.15)_50%,rgba(255,255,255,.15)_75%,transparent_75%,transparent)] bg-[length:1rem_1rem] animate-[shimmer_1.5s_linear_infinite]" />
            </motion.div>
          </div>
          <div className="flex justify-between items-center mt-1.5 text-[11px] font-bold text-slate-500 dark:text-slate-400">
            <span>المرصود: <span className="font-mono">{xpInCurrentLevel}</span> / 100 XP</span>
            <span className="font-mono text-amber-500">{Math.round(progressPercent)}%</span>
          </div>
        </div>

        {/* Right item: Trophy total indicators */}
        <div className="flex items-center gap-2.5 px-4 py-2 bg-amber-50 dark:bg-amber-950/20 border border-amber-100/40 dark:border-amber-950 rounded-2xl">
          <Trophy className="w-5 h-5 text-amber-500 fill-amber-500/20" />
          <div className="text-right">
            <span className="block text-[9px] uppercase font-bold text-slate-400 dark:text-slate-500">مجموع الجوائز</span>
            <span className="text-xs font-black text-slate-800 dark:text-amber-400">عبقري السلسلة</span>
          </div>
        </div>

      </div>
    </div>
  );
}
