import { useState, useRef, useEffect } from 'react';
import { Question } from '../types';
import { detectDir } from '../lib/detectDir';
import { Check, X, ArrowLeft, Award, HelpCircle, Lightbulb } from 'lucide-react';
import { motion } from 'motion/react';
import { useApp } from '../context/AppContext';

interface QuestionCardProps {
  key?: string | number;
  question: Question;
  questionIndex: number;
  totalQuestions: number;
  onAnswer: (scoreChange: number, isCorrect: boolean) => void;
  onNext?: () => void;
}

export default function QuestionCard({ question, questionIndex, totalQuestions, onAnswer, onNext }: QuestionCardProps) {
  const { uiSettings } = useApp();
  const [selectedKey, setSelectedKey] = useState<string | null>(null);
  const [isSubmitted, setIsSubmitted] = useState<boolean>(false);
  const [showVideoExplanation, setShowVideoExplanation] = useState<boolean>(false);

  const timerRef = useRef<any>(null);
  const rawDelay = uiSettings?.quiz_auto_advance_delay || '3';
  const autoAdvanceDelay = Number(rawDelay);

  const { parsed_json, points_correct, points_wrong } = question;
  const { questionText, options, correctAnswer, image_url, video_url } = parsed_json;

  // Detect direction of question text
  const questionDir = detectDir(questionText);

  useEffect(() => {
    return () => {
      if (timerRef.current) {
        clearTimeout(timerRef.current);
      }
    };
  }, []);

  const handleOptionClick = (key: string) => {
    if (isSubmitted) return;
    setSelectedKey(key);
    setIsSubmitted(true);

    const isCorrect = key === correctAnswer;
    const scoreChange = isCorrect ? points_correct : -points_wrong;

    onAnswer(scoreChange, isCorrect);

    if (timerRef.current) {
      clearTimeout(timerRef.current);
    }

    timerRef.current = setTimeout(() => {
      handleNext();
    }, autoAdvanceDelay * 1000);
  };

  const handleSubmit = () => {
    // Legacy support, though selection now triggers directly
    if (!selectedKey || isSubmitted) return;
    setIsSubmitted(true);

    const isCorrect = selectedKey === correctAnswer;
    const scoreChange = isCorrect ? points_correct : -points_wrong;

    onAnswer(scoreChange, isCorrect);
  };

  const handleNext = () => {
    if (timerRef.current) {
      clearTimeout(timerRef.current);
      timerRef.current = null;
    }
    setSelectedKey(null);
    setIsSubmitted(false);
    setShowVideoExplanation(false);
    if (onNext) {
      onNext();
    }
  };

  const getEmbedUrl = (url: string) => {
    if (!url) return '';
    let regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
    let match = url.match(regExp);
    if (match && match[2].length === 11) {
      return `https://www.youtube.com/embed/${match[2]}`;
    }
    return url;
  };

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-3xl p-6 sm:p-8 shadow-md relative" dir="rtl">
      
      {/* Header status bar */}
      <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-5 mb-6 text-xs font-bold text-slate-400 dark:text-slate-500">
        <div className="flex items-center gap-2">
          <HelpCircle className="w-4 h-4 text-blue-500" />
          <span>السؤال <span className="text-slate-800 dark:text-slate-200 font-mono font-black">{questionIndex}</span> من أصل <span className="font-mono">{totalQuestions}</span></span>
        </div>
        
        <div className="flex items-center gap-3">
          <span className="px-2.5 py-1 bg-green-50 dark:bg-green-950/20 text-green-600 dark:text-green-400 border border-green-100 dark:border-green-950/40 rounded-lg">
            +{points_correct} XP للصح
          </span>
          {points_wrong > 0 && (
            <span className="px-2.5 py-1 bg-rose-50 dark:bg-rose-950/20 text-rose-600 dark:text-rose-400 border border-rose-100 dark:border-rose-950/40 rounded-lg">
              -{points_wrong} XP للغلط
            </span>
          )}
        </div>
      </div>

      {/* Image above the question */}
      {image_url && (
        <div className="mb-6 overflow-hidden rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm max-h-[320px] flex items-center justify-center bg-slate-50 dark:bg-slate-950">
          <img 
            src={image_url} 
            alt="صورة توضيحية للسؤال" 
            className="w-full h-auto max-h-[320px] object-contain transition-transform hover:scale-102 duration-300" 
            referrerPolicy="no-referrer"
          />
        </div>
      )}

      {/* Question Title text & Video Lamp Trigger */}
      <div className="flex items-start justify-between gap-4 mb-8">
        <div 
          className={`text-lg sm:text-xl font-bold text-slate-800 dark:text-white leading-snug flex-grow ${
            questionDir === 'rtl' ? 'text-right' : 'text-left'
          }`}
          dir={questionDir}
        >
          {questionText}
        </div>

        {video_url && (
          <button
            type="button"
            onClick={() => setShowVideoExplanation(!showVideoExplanation)}
            className={`shrink-0 p-2.5 rounded-2xl transition duration-200 border cursor-pointer relative group flex items-center justify-center ${
              showVideoExplanation
                ? 'bg-amber-500/10 border-amber-500 text-amber-600 dark:text-amber-400 shadow-sm shadow-amber-500/10'
                : 'bg-amber-500/5 hover:bg-amber-500/10 border-amber-500/20 text-amber-500 hover:text-amber-600 dark:hover:text-amber-400 hover:border-amber-500/40'
            }`}
            title="شاهد الشرح بالفيديو لهذا السؤال"
          >
            <span className="absolute -top-1 -right-1 flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-amber-500"></span>
            </span>
            <Lightbulb className={`w-5 h-5 ${showVideoExplanation ? 'animate-pulse' : ''}`} />
          </button>
        )}
      </div>

      {/* Video player collapsable menu */}
      {video_url && showVideoExplanation && (
        <motion.div
          initial={{ opacity: 0, height: 0, marginBottom: 0 }}
          animate={{ opacity: 1, height: 'auto', marginBottom: 24 }}
          exit={{ opacity: 0, height: 0, marginBottom: 0 }}
          className="overflow-hidden border border-amber-500/20 bg-amber-500/5 rounded-2xl p-4 transition-all"
        >
          <div className="flex items-center justify-between mb-3 text-right">
            <div className="flex items-center gap-2 text-amber-600 dark:text-amber-400 font-extrabold text-xs">
              <Lightbulb className="w-4 h-4 text-amber-500" />
              <span>فيديو توضيحي وشرح تفصيلي لحل السؤال:</span>
            </div>
            <button
              type="button"
              onClick={() => setShowVideoExplanation(false)}
              className="text-xs text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 font-bold"
            >
              إغلاق ×
            </button>
          </div>

          <div className="relative aspect-video w-full rounded-xl overflow-hidden shadow-md bg-black">
            {video_url.endsWith('.mp4') || video_url.endsWith('.webm') || video_url.endsWith('.ogg') ? (
              <video 
                src={video_url} 
                controls 
                className="w-full h-full object-cover"
              />
            ) : (
              <iframe
                src={getEmbedUrl(video_url)}
                title="شرح السؤال"
                className="w-full h-full border-0 absolute top-0 left-0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                allowFullScreen
              />
            )}
          </div>
        </motion.div>
      )}

      {/* Options grid list */}
      <div className="space-y-4">
        {options.map((option, idx) => {
          const optionDir = detectDir(option.text);
          const isSelected = selectedKey === option.key;
          const isCorrectAnswer = option.key === correctAnswer;

          let btnStyles = 'border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/40 hover:border-blue-500 dark:hover:border-blue-900 text-slate-700 dark:text-slate-200';
          let badgeStyles = 'bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-400';

          if (isSubmitted) {
            if (isCorrectAnswer) {
              // Highlight correct answer in green
              btnStyles = 'border-green-500 dark:border-green-600 bg-green-50 dark:bg-green-950/20 text-green-700 dark:text-green-300 shadow-sm';
              badgeStyles = 'bg-green-500 text-white';
            } else if (isSelected) {
              // User answered wrong option in red
              btnStyles = 'border-rose-500 dark:border-rose-600 bg-rose-50 dark:bg-rose-950/20 text-rose-700 dark:text-rose-300 shadow-sm';
              badgeStyles = 'bg-rose-500 text-white';
            } else {
              // Remaining disabled options
              btnStyles = 'border-slate-100 dark:border-slate-800/40 bg-slate-50/20 dark:bg-slate-900/10 text-slate-400 dark:text-slate-600 opacity-60 pointer-events-none';
              badgeStyles = 'bg-slate-100 dark:bg-slate-900 text-slate-400 dark:text-slate-600';
            }
          } else if (isSelected) {
            btnStyles = 'border-blue-600 dark:border-blue-500 bg-blue-50 dark:bg-blue-950/30 text-blue-700 dark:text-blue-300 ring-2 ring-blue-500/10';
            badgeStyles = 'bg-blue-600 text-white';
          }

          return (
            <motion.button
              id={`option-${option.key}`}
              key={option.key}
              disabled={isSubmitted}
              onClick={() => handleOptionClick(option.key)}
              whileHover={{ scale: isSubmitted ? 1 : 1.005 }}
              whileTap={{ scale: isSubmitted ? 1 : 0.995 }}
              className={`w-full px-5 py-4 border rounded-2xl flex items-center gap-4 text-right transition-all cursor-pointer font-medium ${btnStyles}`}
            >
              {/* Option Key index identifier */}
              <div className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold text-sm shrink-0 font-mono ${badgeStyles}`}>
                {option.key}
              </div>

              {/* Option text with line-specific layouts */}
              <div 
                className={`flex-grow leading-relaxed ${
                  optionDir === 'rtl' ? 'text-right' : 'text-left'
                }`}
                dir={optionDir}
              >
                {option.text}
              </div>

              {/* Status Icons on submission */}
              {isSubmitted && (
                <div className="shrink-0">
                  {isCorrectAnswer ? (
                    <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center text-white">
                      <Check className="w-4 h-4" />
                    </div>
                  ) : isSelected ? (
                    <div className="w-6 h-6 bg-rose-500 rounded-full flex items-center justify-center text-white">
                      <X className="w-4 h-4" />
                    </div>
                  ) : null}
                </div>
              )}
            </motion.button>
          );
        })}
      </div>

      {/* Action panel footer */}
      <div className="mt-8 pt-6 border-t border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
        
        {/* Status result summary text */}
        <div className="text-right flex-grow">
          {isSubmitted && (
            <motion.div
              initial={{ opacity: 0, y: 5 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex items-center gap-2"
            >
              <div className={`p-2.5 rounded-xl ${selectedKey === correctAnswer ? 'bg-green-50 dark:bg-green-950/20 text-green-600' : 'bg-rose-50 dark:bg-rose-950/20 text-rose-600'}`}>
                <Award className="w-5 h-5" />
              </div>
              <div>
                <span className={`text-sm font-bold block ${selectedKey === correctAnswer ? 'text-green-600 dark:text-green-400' : 'text-rose-600 dark:text-rose-400'}`}>
                  {selectedKey === correctAnswer ? 'أحسنت! إجابة صحيحة بالكامل.' : 'للأسف، إجابة غير موفقة.'}
                </span>
                <span className="text-[10px] text-slate-400 dark:text-slate-500 mt-0.5 block">
                  {selectedKey === correctAnswer ? `لقد حصدت +${points_correct} XP بنجاح!` : points_wrong > 0 ? `تم خصم -${points_wrong} XP كعقوبة خطأ.` : 'لم يتم خصم نقاط عقوبة.'}
                </span>
              </div>
            </motion.div>
          )}
        </div>

        {/* Action Button trigger */}
        <div className="w-full sm:w-auto shrink-0">
          {isSubmitted && (
            <div className="text-xs text-indigo-500 font-bold flex items-center justify-center gap-1.5 px-4 py-2 bg-indigo-50 dark:bg-slate-950 border border-indigo-100 dark:border-slate-850 rounded-xl">
              <span className="w-2 h-2 bg-indigo-600 rounded-full animate-ping" />
              <span>جاري الانتقال تلقائياً...</span>
            </div>
          )}
        </div>

      </div>

    </div>
  );
}
