import { News } from '../types';
import { Calendar, Award } from 'lucide-react';

interface NewsCardProps {
  key?: string | number;
  news: News;
}

export default function NewsCard({ news }: NewsCardProps) {
  const formattedDate = new Date(news.published_at).toLocaleDateString('ar-EG', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  return (
    <div className="p-5 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-3xl shadow-sm text-right flex flex-col gap-3" dir="rtl">
      
      <div className="flex items-center gap-2 text-[10px] font-bold text-blue-600 dark:text-blue-400">
        <Calendar className="w-3.5 h-3.5" />
        <span>{formattedDate}</span>
      </div>

      <div>
        <h4 className="text-base font-bold text-slate-800 dark:text-white mb-2 leading-snug">
          {news.title}
        </h4>
        <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
          {news.body}
        </p>
      </div>

      <div className="mt-2 pt-3 border-t border-slate-100/50 dark:border-slate-800/40 flex items-center gap-1.5 text-[10px] text-slate-400 dark:text-slate-500 font-semibold uppercase">
        <Award className="w-3.5 h-3.5 text-blue-500/80" />
        <span>منشور تربوي معتمد</span>
      </div>

    </div>
  );
}
