import { Achievement } from '../types';
import * as LucideIcons from 'lucide-react';
import { Lock, Sparkles, CheckCircle2 } from 'lucide-react';
import { motion } from 'motion/react';

interface AchievementBadgeProps {
  key?: string | number;
  achievement: Achievement;
  isUnlocked: boolean;
  unlockedAt?: string;
}

export default function AchievementBadge({ achievement, isUnlocked, unlockedAt }: AchievementBadgeProps) {
  const IconComponent = (LucideIcons as any)[achievement.icon] || LucideIcons.Award;

  return (
    <motion.div
      initial={{ opacity: 0, hover: { scale: 1.02 } }}
      animate={{ opacity: 1 }}
      className={`p-5 rounded-2xl border transition-all flex items-center gap-4 relative overflow-hidden ${
        isUnlocked
          ? 'bg-gradient-to-br from-amber-500/10 via-yellow-500/5 to-transparent border-amber-300 dark:border-amber-900/60 shadow-md shadow-amber-500/5'
          : 'bg-slate-50 dark:bg-slate-900/40 border-slate-200 dark:border-slate-800 opacity-60'
      }`}
    >
      {/* Decorative spark for unlocked gold badges */}
      {isUnlocked && (
        <div className="absolute top-1 left-1">
          <Sparkles className="w-3.5 h-3.5 text-amber-500 animate-pulse" />
        </div>
      )}

      {/* Badge graphic icon */}
      <div className={`w-14 h-14 rounded-2xl flex items-center justify-center shrink-0 border relative ${
        isUnlocked
          ? 'bg-amber-500 text-white border-amber-400 shadow-lg shadow-amber-500/35'
          : 'bg-slate-100 dark:bg-slate-800 text-slate-400 border-slate-200 dark:border-slate-700'
      }`}>
        <IconComponent className="w-7 h-7" />
        
        {/* Lock/Unlock indicators */}
        <div className="absolute -bottom-1 -right-1">
          {isUnlocked ? (
            <div className="w-5.5 h-5.5 bg-green-500 rounded-full border-2 border-white dark:border-slate-900 flex items-center justify-center text-white">
              <CheckCircle2 className="w-3.5 h-3.5" />
            </div>
          ) : (
            <div className="w-5.5 h-5.5 bg-slate-200 dark:bg-slate-700 rounded-full border-2 border-white dark:border-slate-900 flex items-center justify-center text-slate-500 dark:text-slate-400">
              <Lock className="w-3 h-3" />
            </div>
          )}
        </div>
      </div>

      {/* Description text */}
      <div className="text-right flex-grow">
        <h4 className={`text-sm font-bold ${isUnlocked ? 'text-amber-600 dark:text-amber-400' : 'text-slate-500 dark:text-slate-400'}`}>
          {achievement.title}
        </h4>
        
        <p className="text-xs text-slate-400 dark:text-slate-500 mt-1 leading-relaxed">
          {achievement.condition_json.type === 'answered_count' && `حل عدد ${achievement.condition_json.value} أسئلة بنجاح`}
          {achievement.condition_json.type === 'total_xp' && `تجميع إجمالي ${achievement.condition_json.value} من نقاط XP`}
          {achievement.condition_json.type === 'correct_count' && `إجابة صحيحة لعدد ${achievement.condition_json.value} أسئلة في جلسة اليوم`}
          {achievement.condition_json.type === 'section_xp' && `تجميع قدره ${achievement.condition_json.value} XP في مادة الكورسات`}
        </p>

        {isUnlocked && unlockedAt ? (
          <span className="block text-[10px] text-green-500 font-bold mt-1.5 font-mono">
            تم الفتح: {new Date(unlockedAt).toLocaleDateString('ar-EG')}
          </span>
        ) : (
          <span className="block text-[10px] text-amber-500 font-bold mt-1.5">
            المكافأة: +{achievement.xp_reward} XP
          </span>
        )}
      </div>

    </motion.div>
  );
}
