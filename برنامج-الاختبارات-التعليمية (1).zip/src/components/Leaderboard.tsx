import React from 'react';
import { useApp } from '../context/AppContext';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Trophy, Medal, Crown, X, Zap, Flame, Star, Sparkles, Award, User
} from 'lucide-react';

interface LeaderboardProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function Leaderboard({ isOpen, onClose }: LeaderboardProps) {
  const { students, progress, student } = useApp();

  // Compute cumulative XP for each student
  const leaderboardData = students
    .map((st) => {
      const studentProgress = progress.filter((p) => p.student_id === st.id);
      const totalXp = studentProgress.reduce((sum, p) => sum + p.xp, 0);
      return {
        id: st.id,
        name: st.display_name,
        xp: totalXp,
        isMe: student?.id === st.id,
      };
    })
    .sort((a, b) => b.xp - a.xp); // Sort by highest XP

  // Take top 5
  const topFive = leaderboardData.slice(0, 5);

  // Find current user's general rank if not in top 5
  const myRankIndex = leaderboardData.findIndex((item) => item.isMe);
  const myRank = myRankIndex !== -1 ? myRankIndex + 1 : null;
  const myData = myRankIndex !== -1 ? leaderboardData[myRankIndex] : null;

  // Render rank award badge element
  const renderRankBadge = (index: number) => {
    switch (index) {
      case 0:
        return (
          <div className="relative flex items-center justify-center">
            <motion.div
              animate={{ rotate: [0, 10, -10, 0] }}
              transition={{ repeat: Infinity, duration: 4, ease: "easeInOut" }}
              className="w-10 h-10 bg-gradient-to-tr from-amber-400 via-yellow-300 to-amber-500 rounded-full flex items-center justify-center text-white shadow-lg shadow-amber-500/30 border-2 border-yellow-200"
            >
              <Crown className="w-5.5 h-5.5" />
            </motion.div>
            <div className="absolute -top-1 -right-1">
              <Sparkles className="w-4 h-4 text-yellow-400 animate-pulse" />
            </div>
          </div>
        );
      case 1:
        return (
          <div className="w-10 h-10 bg-gradient-to-tr from-slate-300 via-slate-100 to-slate-400 rounded-full flex items-center justify-center text-slate-700 shadow-md border-2 border-white dark:border-slate-800">
            <Medal className="w-5.5 h-5.5" />
          </div>
        );
      case 2:
        return (
          <div className="w-10 h-10 bg-gradient-to-tr from-amber-600 via-amber-500 to-amber-700 rounded-full flex items-center justify-center text-white shadow-md border-2 border-amber-300/30">
            <Trophy className="w-5 h-5" />
          </div>
        );
      default:
        return (
          <div className="w-10 h-10 bg-slate-100 dark:bg-slate-800 rounded-full flex items-center justify-center font-black text-slate-500 dark:text-slate-400 font-mono text-sm border border-slate-200/55 dark:border-slate-700/50">
            #{index + 1}
          </div>
        );
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div 
          id="leaderboard-modal-overlay"
          className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4 transition-all"
          onClick={onClose}
        >
          <motion.div
            id="leaderboard-modal-container"
            initial={{ scale: 0.9, opacity: 0, y: 30 }}
            animate={{ scale: 1, opacity: 1, y: 0, transition: { type: 'spring', damping: 20 } }}
            exit={{ scale: 0.9, opacity: 0, y: -30 }}
            onClick={(e) => e.stopPropagation()}
            className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800/80 rounded-3xl p-6 sm:p-8 max-w-md w-full relative overflow-hidden shadow-2xl flex flex-col max-h-[85vh]"
          >
            {/* Visual design ornaments */}
            <div className="absolute -top-24 -left-24 w-48 h-48 bg-blue-500/10 dark:bg-blue-500/5 rounded-full blur-2xl pointer-events-none" />
            <div className="absolute -bottom-24 -right-24 w-48 h-48 bg-amber-500/10 dark:bg-amber-500/5 rounded-full blur-2xl pointer-events-none" />

            {/* Header section */}
            <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800/80">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 bg-gradient-to-tr from-amber-500 to-yellow-400 rounded-xl flex items-center justify-center text-white shadow-md shadow-amber-500/15">
                  <Trophy className="w-5 h-5 animate-bounce" />
                </div>
                <div>
                  <h3 className="text-lg font-black text-slate-800 dark:text-white">قائمة المتصدرين وطنيًا</h3>
                  <span className="text-[11px] text-slate-400 dark:text-slate-500 block mt-0.5">أفضل نجوم الفصل الدراسي الحالي:</span>
                </div>
              </div>
              
              <button
                onClick={onClose}
                className="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800/65 rounded-xl transition cursor-pointer"
                aria-label="Close"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Rankings list container */}
            <div className="overflow-y-auto py-5 space-y-3.5 flex-grow pr-0.5" dir="rtl">
              {topFive.length === 0 ? (
                <div className="text-center py-12 text-slate-400 text-xs space-y-2">
                  <Star className="w-8 h-8 text-slate-300 mx-auto animate-pulse" />
                  <p>لا توجد بيانات نقاط للطلاب حالياً.</p>
                  <p className="text-[11px]">كُن أول المنضمين للوحة الشرف بحلّ المسائل!</p>
                </div>
              ) : (
                topFive.map((player, index) => {
                  const isGold = index === 0;
                  return (
                    <motion.div
                      key={player.id}
                      initial={{ scale: 0.95, opacity: 0, x: -15 }}
                      animate={{ scale: 1, opacity: 1, x: 0, transition: { delay: index * 0.05 } }}
                      className={`flex items-center justify-between p-3 rounded-2xl border transition-all ${
                        player.isMe
                          ? 'bg-blue-50/70 dark:bg-blue-600/10 border-blue-200 dark:border-blue-500/25 shadow-sm shadow-blue-500/5'
                          : isGold
                          ? 'bg-amber-500/5 dark:bg-amber-500/5 border-amber-300/40 dark:border-amber-500/10'
                          : 'bg-slate-50/50 dark:bg-slate-900/40 border-slate-100/50 dark:border-slate-800/40 hover:bg-slate-50 dark:hover:bg-slate-800/40'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        {renderRankBadge(index)}
                        <div className="space-y-0.5">
                          <span className={`text-xs font-black leading-tight flex items-center gap-1.5 ${
                            player.isMe ? 'text-blue-700 dark:text-blue-400' : 'text-slate-800 dark:text-white'
                          }`}>
                            {player.name}
                            {player.isMe && (
                              <span className="bg-blue-100 dark:bg-blue-500/20 text-blue-800 dark:text-blue-300 text-[9px] font-black px-1.5 py-0.5 rounded-full">
                                أنت
                              </span>
                            )}
                          </span>
                          
                          {/* Mini dynamic rank level indicator */}
                          <span className="text-[10px] text-slate-400 dark:text-slate-500 block font-bold">
                            المرتبة {index + 1} • {Math.floor(player.xp / 100) + 1} المستوى
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5 bg-white dark:bg-slate-950 px-2.5 py-1.5 rounded-xl border border-slate-100 dark:border-slate-800/80">
                        <Zap className={`w-3.5 h-3.5 ${isGold ? 'text-amber-500' : 'text-slate-400 dark:text-slate-500'}`} />
                        <span className="text-xs font-black font-mono text-slate-700 dark:text-slate-300">
                          {player.xp} <span className="text-[10px] text-slate-450 dark:text-slate-500">XP</span>
                        </span>
                      </div>
                    </motion.div>
                  );
                })
              )}

              {/* Display user's specific ranking footer if not in top 5 */}
              {myRank !== null && myRank > 5 && myData && (
                <>
                  <div className="border-t border-dashed border-slate-200 dark:border-slate-800/80 my-4" />
                  <motion.div
                    initial={{ y: 15, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    className="flex items-center justify-between p-3.5 bg-blue-500/10 border border-blue-450/20 rounded-2xl"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-blue-500/20 text-blue-600 dark:text-blue-400 rounded-full flex items-center justify-center font-black text-xs font-mono">
                        #{myRank}
                      </div>
                      <div className="space-y-0.5">
                        <span className="text-xs font-black text-blue-700 dark:text-blue-400 flex items-center gap-1.5">
                          {myData.name}
                          <span className="bg-blue-600/15 text-blue-800 dark:text-blue-300 text-[9px] font-black px-2 py-0.5 rounded-full">
                            رتبتك الحالية
                          </span>
                        </span>
                        <span className="text-[10px] text-slate-500 dark:text-slate-400 block">
                          مسافة قصيرة عن الدخول في لائحة الـ 5 الأوائل!
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 bg-white dark:bg-slate-950 px-2.5 py-1.5 rounded-xl border border-slate-100 dark:border-slate-900">
                      <Zap className="w-3.5 h-3.5 text-blue-500" />
                      <span className="text-xs font-black font-mono text-slate-700 dark:text-slate-300">
                        {myData.xp} <span className="text-[9px] text-slate-400">XP</span>
                      </span>
                    </div>
                  </motion.div>
                </>
              )}
            </div>

            {/* Inspiring footer text with button */}
            <div className="mt-2 text-center space-y-4">
              <p className="text-[10.5px] text-slate-400 dark:text-slate-650 leading-relaxed border-t border-slate-100 dark:border-slate-800/50 pt-4">
                تُحسب لوحة المتصدرين بناءً على مجموع تراكم النتيجة والأوسمة المحصودة بجميع المواد الدراسية.
              </p>
              
              <button
                onClick={onClose}
                className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white font-black rounded-2xl text-xs shadow-md shadow-blue-500/15 transition cursor-pointer"
              >
                متابعة المجهود الدراسي
              </button>
            </div>

          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
