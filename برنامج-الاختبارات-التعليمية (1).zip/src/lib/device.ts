/**
 * Robust Client Hardware Fingerprinting & Device ID persistence helper
 */
export function getStableDeviceID(): string {
  if (typeof window === 'undefined') return 'server_side_fallback';

  let devId = localStorage.getItem('school_device_token') || localStorage.getItem('real_device_id');

  // 1. Try reading from persistent browser cookies
  if (!devId) {
    try {
      const cookieMatch = document.cookie.match(/(?:^|; )real_device_id=([^;]*)/);
      if (cookieMatch) {
        devId = decodeURIComponent(cookieMatch[1]);
      }
    } catch (e) {
      console.warn('Cookie reading failed', e);
    }
  }

  // 2. Generate immutable canvas + hardware fingerprint if not found
  if (!devId) {
    try {
      // Hardware details
      const screenWidth = window.screen?.width || 0;
      const screenHeight = window.screen?.height || 0;
      const colorDepth = window.screen?.colorDepth || 0;
      const pixelRatio = window.devicePixelRatio || 1;
      const cpuThreads = navigator.hardwareConcurrency || 4;
      const language = (navigator.languages || [navigator.language || 'en']).join('-');
      const parsedUA = navigator.userAgent ? navigator.userAgent.replace(/[^a-zA-Z0-9]/g, '').slice(0, 35) : 'unknown_ua';

      // Advanced Canvas Render Fingerprint
      let canvasFingerprint = '';
      try {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        if (ctx) {
          canvas.width = 150;
          canvas.height = 30;
          ctx.textBaseline = 'top';
          ctx.font = "12px 'Arial'";
          ctx.fillStyle = '#f60';
          ctx.fillRect(10, 5, 100, 15);
          ctx.fillStyle = '#069';
          ctx.fillText('EducSchool_App_Fingerprint', 15, 10);
          canvasFingerprint = canvas.toDataURL().slice(-40); // Grab part of base64
        }
      } catch (ce) {
        canvasFingerprint = 'canvas_blocked';
      }

      // Generate base seed
      const randomSeed = Math.random().toString(36).substring(2, 9);
      const timestamp = Date.now().toString(36);

      // Construct a clean, highly specific identifier
      // Replace non-alphanumeric chars to guarantee URL/API safety
      const finger = `hw_${screenWidth}x${screenHeight}_cd${colorDepth}_pr${pixelRatio}_cpu${cpuThreads}_lg${language}_ua${parsedUA}`.replace(/[^a-zA-Z0-9]/g, '_');
      const canvasHash = canvasFingerprint.replace(/[^a-zA-Z0-9]/g, '').slice(0, 15);

      devId = `dev_${finger}_cv${canvasHash}_${randomSeed}_${timestamp}`;
    } catch (err) {
      // Fallback if APIs are completely blocked/restricted
      devId = 'dev_gen_fallback_' + Math.random().toString(36).substring(2, 11) + '_' + Date.now().toString(36);
    }
  }

  // 3. Ensure sync/persistence on client across all storage mediums
  try {
    localStorage.setItem('school_device_token', devId);
    localStorage.setItem('real_device_id', devId);
    
    // Cookie valid for 10 years
    document.cookie = `real_device_id=${encodeURIComponent(devId)}; max-age=315360000; path=/; SameSite=Lax; SameSite=Lax`;
  } catch (err) {
    console.error('Failed to persist stable device ID', err);
  }

  return devId;
}
