/**
 * Detects RTL vs LTR layout direction by inspecting the first strong direction character.
 * Helpful for rendering multi-lingual educational material elegantly.
 */
export function detectDir(text: string): 'rtl' | 'ltr' {
  if (!text) return 'rtl'; // Default to Arabic RTL for this app

  // Remove numerical values, spaces, and punctuation at the start
  const clean = text.replace(/^[\s\d.,()\-+=\[\]{}!@#$%^&*_*?:؛؟"'«»`~]*/, '');
  if (!clean) return 'rtl';

  const firstChar = clean.charCodeAt(0);

  // Arabic unicode ranges:
  // Arabic (0600–06FF)
  // Arabic Supplement (0750–077F)
  // Arabic Extended-A (08A0–08FF)
  // Arabic Presentation Forms-A (FB50–FDFF)
  // Arabic Presentation Forms-B (FE70–FEFF)
  if (
    (firstChar >= 0x0600 && firstChar <= 0x06FF) ||
    (firstChar >= 0x0750 && firstChar <= 0x077F) ||
    (firstChar >= 0x08A0 && firstChar <= 0x08FF) ||
    (firstChar >= 0xFB50 && firstChar <= 0xFDFF) ||
    (firstChar >= 0xFE70 && firstChar <= 0xFEFF)
  ) {
    return 'rtl';
  }

  // If first strong character is Latin
  if (
    (firstChar >= 65 && firstChar <= 90) || // A-Z
    (firstChar >= 97 && firstChar <= 122)   // a-z
  ) {
    return 'ltr';
  }

  return 'rtl'; // default to app standard RTL
}
