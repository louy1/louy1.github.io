import { QuestionParsed, QuestionOption, Question } from '../types';

export interface ParseError {
  lineNum: number;
  lineText: string;
  message: string;
}

export interface ParseResult {
  questions: Omit<Question, 'id' | 'section_id'>[];
  errors: ParseError[];
}

/**
 * Parses raw text into questions list with high-fidelity error reporting.
 * Accepted format:
 * 1. نص السؤال؟
 * أ. خيار أول
 * ب. خيار ثاني
 * ج. خيار ثالث
 * ب# *+3 *-1
 */
export function parseQuestionsText(rawText: string): ParseResult {
  const resultQuestions: Omit<Question, 'id' | 'section_id'>[] = [];
  const errors: ParseError[] = [];

  const lines = rawText.split(/\r?\n/);
  
  let currentQuestionText = '';
  let currentOptions: QuestionOption[] = [];
  let currentCorrectAnswer = '';
  let pointsCorrect = 1;
  let pointsWrong = 0;
  let qHeaderLineIndex = -1;
  let currentImageUrl = '';
  let currentVideoUrl = '';

  const globalImagesMap: { [key: number]: string } = {};
  const globalVideosMap: { [key: number]: string } = {};
  let lastMatchedQNum: number | null = null;

  function commitCurrentQuestion() {
    if (!currentQuestionText && currentOptions.length === 0 && !currentCorrectAnswer) {
      return; // Nothing to commit
    }

    const currentLineNum = qHeaderLineIndex + 1;

    if (!currentQuestionText) {
      errors.push({
        lineNum: currentLineNum,
        lineText: `السؤال رقم ${resultQuestions.length + 1}`,
        message: 'عنوان السؤال فارغ.'
      });
      return;
    }

    if (currentOptions.length < 2) {
      errors.push({
        lineNum: currentLineNum,
        lineText: currentQuestionText,
        message: `السؤال يجب أن يحتوي على خيارين على الأقل. وجدنا: ${currentOptions.length}`
      });
      return;
    }

    if (!currentCorrectAnswer) {
      errors.push({
        lineNum: currentLineNum,
        lineText: currentQuestionText,
        message: 'لم يتم تحديد الإجابة الصحيحة (مثل: ب#).'
      });
      return;
    }

    // Verify correct answer starts with one of the options
    const optionKeys = currentOptions.map(o => o.key);
    if (!optionKeys.includes(currentCorrectAnswer)) {
      errors.push({
        lineNum: currentLineNum,
        lineText: currentQuestionText,
        message: `الإجابة الصحيحة المحددة "${currentCorrectAnswer}" ليست من ضمن الخيارات المتاحة: (${optionKeys.join(', ')})`
      });
      return;
    }

    const finalQNum = lastMatchedQNum || (resultQuestions.length + 1);
    const finalImageUrl = globalImagesMap[finalQNum] !== undefined ? globalImagesMap[finalQNum] : currentImageUrl;
    const finalVideoUrl = globalVideosMap[finalQNum] !== undefined ? globalVideosMap[finalQNum] : currentVideoUrl;

    resultQuestions.push({
      raw_text: '', // filled when saving
      parsed_json: {
        questionText: currentQuestionText,
        options: currentOptions,
        correctAnswer: currentCorrectAnswer,
        image_url: finalImageUrl || undefined,
        video_url: finalVideoUrl || undefined
      },
      points_correct: pointsCorrect,
      points_wrong: pointsWrong,
      sort: resultQuestions.length + 1
    });

    // Reset for next
    currentQuestionText = '';
    currentOptions = [];
    currentCorrectAnswer = '';
    pointsCorrect = 1;
    pointsWrong = 0;
    qHeaderLineIndex = -1;
    currentImageUrl = '';
    currentVideoUrl = '';
    lastMatchedQNum = null;
  }

  for (let i = 0; i < lines.length; i++) {
    const lineNum = i + 1;
    const rawLine = lines[i];
    const line = rawLine.trim();

    if (!line) continue; // skip empty lines

    // Check specific Image with number -> e.g. "1.()" or "1.(http://imageUrl)"
    const specificImgMatch = line.match(/^(\d+)\.\s*\((.*?)\)$/);
    if (specificImgMatch) {
      const qNum = parseInt(specificImgMatch[1], 10);
      globalImagesMap[qNum] = specificImgMatch[2].trim();
      continue;
    }

    // Check specific Video with number -> e.g. "1.!()" or "1.!(http://videoUrl)"
    const specificVidMatch = line.match(/^(\d+)\.\s*!\((.*?)\)$/);
    if (specificVidMatch) {
      const qNum = parseInt(specificVidMatch[1], 10);
      globalVideosMap[qNum] = specificVidMatch[2].trim();
      continue;
    }

    // Check relative Video explanation without number -> e.g. "!()" or "!(http://videoUrl)"
    const relativeVidMatch = line.match(/^!\((.*?)\)$/);
    if (relativeVidMatch) {
      currentVideoUrl = relativeVidMatch[1].trim();
      continue;
    }

    // Check relative Image without number -> e.g. "()" or "(http://imageUrl)"
    const relativeImgMatch = line.match(/^\((.*?)\)$/);
    if (relativeImgMatch) {
      currentImageUrl = relativeImgMatch[1].trim();
      continue;
    }

    // Rule 1: Question title start -> e.g., "1. نص السؤال" (ends with . and contains a text)
    // Matches an integer followed by a period and a space or text
    const questMatch = line.match(/^(\d+)\.\s*(.*)/);
    if (questMatch) {
      commitCurrentQuestion();
      lastMatchedQNum = parseInt(questMatch[1], 10);
      currentQuestionText = questMatch[2].trim();
      qHeaderLineIndex = i;
      continue;
    }

    // Rule 2: Choice line -> e.g. "أ. خيار أول" or "A. Option one"
    // Matches single Arabic block char or English char, followed by period
    const optionMatch = line.match(/^([أبجد different_chars_or_english_textA-Za-zآ-ي])\.\s*(.*)/);
    if (optionMatch) {
      if (qHeaderLineIndex === -1) {
        errors.push({
          lineNum,
          lineText: rawLine,
          message: 'تم العثور على خيار قبل تحديد رأس السؤال.'
        });
        continue;
      }
      currentOptions.push({
        key: optionMatch[1].trim(),
        text: optionMatch[2].trim()
      });
      continue;
    }

    // Rule 3: Correct answer indicator -> e.g. "ب# *+3 *-1" or "ب+ *+2 *-0" or "أ$" or "ج%"
    // Matches single char followed immediately by: #, $, %, +
    const answerMatch = line.match(/^([أبجد different_chars_or_english_textA-Za-zآ-ي])([#\$%\+])\s*(.*)?/);
    if (answerMatch) {
      if (qHeaderLineIndex === -1) {
        errors.push({
          lineNum,
          lineText: rawLine,
          message: 'تم العثور على سطر الإجابة الصحيحة قبل تحديد رأس السؤال.'
        });
        continue;
      }
      currentCorrectAnswer = answerMatch[1].trim();

      const detailsStr = answerMatch[3] || '';
      
      // Parse optional parameters: *+N or *-N
      // N can be positive integer
      const ptsCorrectMatch = detailsStr.match(/\*\+(\d+)/);
      if (ptsCorrectMatch) {
        pointsCorrect = parseInt(ptsCorrectMatch[1], 10);
      }

      const ptsWrongMatch = detailsStr.match(/\*-(\d+)/);
      if (ptsWrongMatch) {
        pointsWrong = parseInt(ptsWrongMatch[1], 10);
      }
      continue;
    }

    // Support points modifiers on separate lines e.g. "*+3" and "*-2"
    const ptsCorrectLineMatch = line.match(/^\*\+(\d+)/);
    if (ptsCorrectLineMatch) {
      if (qHeaderLineIndex !== -1) {
        pointsCorrect = parseInt(ptsCorrectLineMatch[1], 10);
        continue;
      }
    }

    const ptsWrongLineMatch = line.match(/^\*-(\d+)/);
    if (ptsWrongLineMatch) {
      if (qHeaderLineIndex !== -1) {
        pointsWrong = parseInt(ptsWrongLineMatch[1], 10);
        continue;
      }
    }

    // Unrecognized format warning/error unless it's within question header context
    errors.push({
      lineNum,
      lineText: rawLine,
      message: 'سطر غير مفهوم. يجب أن يبدأ برقم وسام (مثال: 1.)، أو برمز خيار (مثال: أ.)، أو برمز إجابة صحيحة (مثال: ب#).'
    });
  }

  // Commit last remaining question
  commitCurrentQuestion();

  return {
    questions: resultQuestions,
    errors
  };
}
