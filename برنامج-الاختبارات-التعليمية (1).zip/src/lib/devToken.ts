const DEV_TOKEN_KEY = 'educational_tests_dev_token';
const DEV_ROLE_KEY = 'educational_tests_dev_role';

export function getDevToken(): string | null {
  return localStorage.getItem(DEV_TOKEN_KEY);
}

export function setDevToken(token: string): void {
  localStorage.setItem(DEV_TOKEN_KEY, token);
}

export function getDevRole(): 'supervisor' | 'master' | null {
  return localStorage.getItem(DEV_ROLE_KEY) as 'supervisor' | 'master' | null;
}

export function setDevRole(role: 'supervisor' | 'master'): void {
  localStorage.setItem(DEV_ROLE_KEY, role);
}

export function removeDevToken(): void {
  localStorage.removeItem(DEV_TOKEN_KEY);
  localStorage.removeItem(DEV_ROLE_KEY);
}

export function isDevLoggedIn(): boolean {
  return !!getDevToken();
}
