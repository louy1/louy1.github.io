import { useState, useEffect } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import Layout from './components/Layout';
import Index from './pages/Index';
import SubjectPage from './pages/SubjectPage';
import ProgressPage from './pages/ProgressPage';
import SettingsPage from './pages/SettingsPage';
import DeveloperPage from './pages/DeveloperPage';
import OnboardingDialog from './components/OnboardingDialog';
import ChatPage from './pages/ChatPage';
import CommunityChatPage from './pages/CommunityChatPage';
import { Lock, ShieldAlert, Trophy, ShieldCheck } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

function AppContent() {
  const { student, loading, activeAlert, setActiveAlert, refreshData } = useApp();
  const [activePage, setActivePage] = useState<'home' | 'subject' | 'progress' | 'chat' | 'settings' | 'developer' | 'community_chat'>('home');
  const [activeSectionSlug, setActiveSectionSlug] = useState<string | null>(null);

  // Dedicated Ban state countdown
  const [bannedCountdown, setBannedCountdown] = useState(0);

  const isCurrentlyBanned = student && student.banned_until && new Date(student.banned_until) > new Date();

  useEffect(() => {
    if (!student || !student.banned_until) return;

    const interval = setInterval(() => {
      const expires = new Date(student.banned_until!).getTime();
      const left = Math.max(0, Math.round((expires - Date.now()) / 1000));
      setBannedCountdown(left);

      if (left <= 0) {
        clearInterval(interval);
        refreshData();
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [student, student?.banned_until]);

  // If loading the main AppContext setup, show a loading spinner
  if (loading && !student) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center text-slate-100" dir="rtl">
        <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mb-4" />
        <span className="text-sm font-bold text-slate-400">جاري تحميل البوابة التعليمية للأكاديمية...</span>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 transition-colors duration-300">
      
      {/* Onboarding Dialog overlay if student has not completed initial registration */}
      {!student && <OnboardingDialog />}

      {/* Main navigation layouts frame wrapping standard inner pages */}
      {student && !isCurrentlyBanned && (
        <Layout activePage={activePage} setActivePage={setActivePage}>
          {activePage === 'home' && (
            <Index
              onSelectSection={(slug) => {
                setActiveSectionSlug(slug);
                setActivePage('subject');
              }}
              setActivePage={setActivePage}
            />
          )}

          {activePage === 'subject' && (
            <SubjectPage
              sectionSlug={activeSectionSlug || ''}
              onGoBack={() => {
                setActivePage('home');
                setActiveSectionSlug(null);
              }}
            />
          )}

          {activePage === 'progress' && <ProgressPage />}

          {activePage === 'chat' && <ChatPage onExit={() => setActivePage('home')} />}

          {activePage === 'community_chat' && <CommunityChatPage />}

          {activePage === 'settings' && (
            <SettingsPage onEnterDevMode={() => setActivePage('developer')} />
          )}

          {activePage === 'developer' && <DeveloperPage />}
        </Layout>
      )}

      {/* Lock/Ban overlay block for student screen */}
      {isCurrentlyBanned && (
        <div className="fixed inset-0 bg-slate-950 text-white z-50 flex flex-col items-center justify-center p-6 text-center select-none" dir="rtl">
          <motion.div 
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="max-w-md space-y-6"
          >
            <div className="w-16 h-16 bg-rose-500/10 text-rose-500 rounded-3xl flex items-center justify-center border border-rose-500/20 mx-auto">
              <Lock className="w-8 h-8 animate-pulse text-rose-500" />
            </div>
            
            <div className="space-y-2">
              <h2 className="text-xl font-bold text-rose-500">حسابك معلق مؤقتاً بقرار إداري</h2>
              <p className="text-xs text-slate-400 leading-relaxed">لقد تم تقييد وصولك وتجميد الإجابات لديك لمخالفة قوانين الفصل الدراسي والآداب.</p>
            </div>

            <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl">
              <span className="block text-[10px] text-slate-500 font-bold mb-1">السبب المعلن للحظر:</span>
              <span className="text-xs text-slate-200 font-bold">{student.banned_reason || 'مخالفة لوائح المناهج والآداب التعليمية.'}</span>
            </div>

            <div className="space-y-2">
              <span className="text-xs text-amber-500 font-bold block">سيتم تفعيل وفك الحظر تلقائياً بعد:</span>
              <div className="text-2xl font-black font-mono text-white bg-slate-900/50 px-4 py-2 rounded-xl inline-block border border-slate-800/40">
                {bannedCountdown > 60 
                  ? `${Math.floor(bannedCountdown / 60)}د : ${bannedCountdown % 60}ث`
                  : `${bannedCountdown} ثانية`
                }
              </div>
            </div>

            <p className="text-[10px] text-slate-505 leading-relaxed">
              يرجى غلق هذا التنبيه عند انتهاء المؤقت؛ والالتزام بقواعد ومصادقات المعلم المباشرة.
            </p>
          </motion.div>
        </div>
      )}

      {/* Real-time Alerts Dialog popup overlay */}
      <AnimatePresence>
        {activeAlert && (
          <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in" dir="rtl">
            <motion.div 
              initial={{ y: 15, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 15, opacity: 0 }}
              className="w-full max-w-sm bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 rounded-3xl space-y-4 text-center shadow-2xl relative"
            >
              <div className={`w-14 h-14 rounded-2xl mx-auto flex items-center justify-center border ${
                activeAlert.type === 'warning' 
                  ? 'bg-amber-500/10 text-amber-500 border-amber-500/20'
                  : activeAlert.type === 'alert'
                  ? 'bg-rose-500/10 text-rose-500 border-rose-500/20 animate-pulse'
                  : activeAlert.type === 'congratulations'
                  ? 'bg-green-500/10 text-green-500 border-green-500/20'
                  : 'bg-blue-500/10 text-blue-500 border-blue-500/20'
              }`}>
                {activeAlert.type === 'warning' && <ShieldAlert className="w-7 h-7" />}
                {activeAlert.type === 'alert' && <Lock className="w-7 h-7" />}
                {activeAlert.type === 'congratulations' && <Trophy className="w-7 h-7 text-amber-500 animate-bounce" />}
                {activeAlert.type !== 'warning' && activeAlert.type !== 'alert' && activeAlert.type !== 'congratulations' && <ShieldCheck className="w-7 h-7" />}
              </div>

              <div className="space-y-1.5">
                <h4 className="text-slate-900 dark:text-white font-bold text-sm">
                  {activeAlert.type === 'warning' && 'تنبيه إداري عاجل!'}
                  {activeAlert.type === 'alert' && 'إنذار رسمي صارم!'}
                  {activeAlert.type === 'congratulations' && 'تهنئة وتكريم خاص!'}
                  {activeAlert.type !== 'warning' && activeAlert.type !== 'alert' && activeAlert.type !== 'congratulations' && 'رسالة من الإدارة'}
                </h4>
                <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed font-extrabold px-1">
                  {activeAlert.text}
                </p>
              </div>

              <button
                onClick={() => setActiveAlert(null)}
                className={`w-full py-2.5 text-white font-bold rounded-xl text-xs transition cursor-pointer ${
                  activeAlert.type === 'alert' 
                    ? 'bg-rose-500 hover:bg-rose-600'
                    : 'bg-blue-600 hover:bg-blue-700'
                }`}
              >
                فهمت هذا التوجيه
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
