import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Student, Section, Question, Progress, Achievement, StudentAchievement, Ad, News, UISetting, StudentNote, PreRegisteredCode, IntrusionLog, CodeShareConflict, DeviceBlock, PaymentReceipt, PaymentRequest, PrivateMessage } from '../types';
import { isDevLoggedIn, getDevToken } from '../lib/devToken';
import { getStableDeviceID } from '../lib/device';

interface AppContextType {
  student: Student | null;
  students: Student[];
  theme: 'light' | 'dark';
  devMode: boolean;
  sections: Section[];
  questions: Question[];
  achievements: Achievement[];
  studentAchievements: StudentAchievement[];
  progress: Progress[];
  ads: Ad[];
  news: News[];
  uiSettings: Record<string, string>;
  studentNotes: StudentNote[];
  preRegisteredCodes: PreRegisteredCode[];
  intrusionLogs: IntrusionLog[];
  codeShareConflicts: CodeShareConflict[];
  deviceBlocks: DeviceBlock[];
  paymentReceipts: PaymentReceipt[];
  paymentRequests: PaymentRequest[];
  privateMessages: PrivateMessage[];
  kickedStudents: Student[];
  db: {
    students: Student[];
    pre_registered_codes: PreRegisteredCode[];
    intrusion_logs: IntrusionLog[];
    code_share_conflicts: CodeShareConflict[];
    device_blocks: DeviceBlock[];
    payment_receipts: PaymentReceipt[];
    payment_requests: PaymentRequest[];
    kicked_students: Student[];
  };
  addNote: (sectionId: string, sectionTitle: string, noteText: string) => Promise<void>;
  deleteNote: (noteId: string) => Promise<void>;
  loading: boolean;
  activeAlert: { text: string; type: string } | null;
  setActiveAlert: (alert: { text: string; type: string } | null) => void;
  setStudent: (s: Student | null) => void;
  setTheme: (t: 'light' | 'dark') => void;
  setDevMode: (d: boolean) => void;
  updateProgress: (sectionId: string, xpAmount: number, isCorrect: boolean) => Promise<{ progress: Progress; newlyUnlockedIds: string[] }>;
  updateUISettings: (settings: Record<string, string>) => void;
  refreshData: () => Promise<void>;
  resetLocalStudent: () => Promise<void>;
  setQuestions: (qs: Question[] | ((prev: Question[]) => Question[])) => void;
  setSections: (ss: Section[] | ((prev: Section[]) => Section[])) => void;
}

export function playNotificationSound(type: 'ping' | 'warning' | 'kick' | 'ban' | 'congratulations' | 'pardon' = 'ping') {
  try {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextClass) return;
    const ctx = new AudioContextClass();

    if (type === 'ping' || (type as any) === 'congratulations') {
      // High-pitched sweet double beep for general chat messages and notifications
      const osc1 = ctx.createOscillator();
      const gain1 = ctx.createGain();
      osc1.connect(gain1);
      gain1.connect(ctx.destination);
      osc1.frequency.setValueAtTime(880, ctx.currentTime);
      gain1.gain.setValueAtTime(0.12, ctx.currentTime);
      gain1.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.12);
      osc1.start();
      osc1.stop(ctx.currentTime + 0.12);

      setTimeout(() => {
        try {
          const osc2 = ctx.createOscillator();
          const gain2 = ctx.createGain();
          osc2.connect(gain2);
          gain2.connect(ctx.destination);
          osc2.frequency.setValueAtTime(1109, ctx.currentTime);
          gain2.gain.setValueAtTime(0.12, ctx.currentTime);
          gain2.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.2);
          osc2.start();
          osc2.stop(ctx.currentTime + 0.2);
        } catch (e) {}
      }, 90);
    } else if (type === 'warning') {
      // Triple urgent beep for warnings or critical alerts
      [0, 140, 280].forEach((delay) => {
        setTimeout(() => {
          try {
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.connect(gain);
            gain.connect(ctx.destination);
            osc.type = 'triangle';
            osc.frequency.setValueAtTime(620, ctx.currentTime);
            gain.gain.setValueAtTime(0.15, ctx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.12);
            osc.start();
            osc.stop(ctx.currentTime + 0.12);
          } catch (e) {}
        }, delay);
      });
    } else if (type === 'ban' || type === 'kick' || (type as any) === 'alert') {
      // low tone rapid descender for banishment or expulsion
      const duration = 0.55;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(280, ctx.currentTime);
      osc.frequency.linearRampToValueAtTime(90, ctx.currentTime + duration);
      gain.gain.setValueAtTime(0.2, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + duration);
      osc.start();
      osc.stop(ctx.currentTime + duration);
    } else if (type === 'pardon') {
      // A rising cheerful arpeggio for pardon/congratulations/unban
      [0, 90, 180, 270].forEach((delay, idx) => {
        const freqs = [523.25, 659.25, 783.99, 1046.50]; // C5, E5, G5, C6
        setTimeout(() => {
          try {
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.connect(gain);
            gain.connect(ctx.destination);
            osc.frequency.setValueAtTime(freqs[idx], ctx.currentTime);
            gain.gain.setValueAtTime(0.1, ctx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.25);
            osc.start();
            osc.stop(ctx.currentTime + 0.25);
          } catch (e) {}
        }, delay);
      });
    }

    if (navigator.vibrate) {
      navigator.vibrate([120, 60, 120]);
    }
  } catch (e) {
    console.warn('Audio Context error or locked', e);
  }
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const [student, setStudentState] = useState<Student | null>(null);
  const [students, setStudents] = useState<Student[]>([]);
  const [theme, setTheme] = useState<'light' | 'dark'>('dark');
  const [devMode, setDevMode] = useState<boolean>(false);

  // Database states
  const [sections, setSections] = useState<Section[]>([]);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [studentAchievements, setStudentAchievements] = useState<StudentAchievement[]>([]);
  const [progress, setProgress] = useState<Progress[]>([]);
  const [ads, setAds] = useState<Ad[]>([]);
  const [news, setNews] = useState<News[]>([]);
  const [uiSettings, setUiSettings] = useState<Record<string, string>>({});
  const [studentNotes, setStudentNotes] = useState<StudentNote[]>([]);
  const [preRegisteredCodes, setPreRegisteredCodes] = useState<PreRegisteredCode[]>([]);
  const [intrusionLogs, setIntrusionLogs] = useState<IntrusionLog[]>([]);
  const [codeShareConflicts, setCodeShareConflicts] = useState<CodeShareConflict[]>([]);
  const [deviceBlocks, setDeviceBlocks] = useState<DeviceBlock[]>([]);
  const [paymentReceipts, setPaymentReceipts] = useState<PaymentReceipt[]>([]);
  const [paymentRequests, setPaymentRequests] = useState<PaymentRequest[]>([]);
  const [privateMessages, setPrivateMessages] = useState<PrivateMessage[]>([]);
  const [kickedStudents, setKickedStudents] = useState<Student[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [activeAlert, setActiveAlert] = useState<{ text: string; type: string } | null>(null);

  // Load local student on startup
  useEffect(() => {
    const saved = localStorage.getItem('onboarded_student');
    if (saved) {
      try {
        setStudentState(JSON.parse(saved));
      } catch (e) {
        console.error('Error parsing loaded student', e);
      }
    }

    const savedTheme = localStorage.getItem('app_theme');
    if (savedTheme === 'dark' || savedTheme === 'light') {
      setTheme(savedTheme);
    }
  }, []);

  const setStudent = (newStudent: Student | null) => {
    setStudentState(newStudent);
    if (newStudent) {
      localStorage.setItem('onboarded_student', JSON.stringify(newStudent));
    } else {
      localStorage.removeItem('onboarded_student');
    }
  };

  const changeTheme = (newTheme: 'light' | 'dark') => {
    setTheme(newTheme);
    localStorage.setItem('app_theme', newTheme);
  };

  // Sync dark/light class on document
  useEffect(() => {
    const root = window.document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [theme]);

  // Fetch all db configuration
  const refreshData = async () => {
    try {
      const saved = localStorage.getItem('onboarded_student');
      let queryParams = '';
      if (saved) {
        try {
          const parsed = JSON.parse(saved);
          const devId = getStableDeviceID();
          queryParams = `?studentId=${encodeURIComponent(parsed.id)}&deviceId=${encodeURIComponent(devId)}`;
        } catch (e) {}
      }
      const res = await fetch(`/api/db${queryParams}`);
      if (res.ok) {
        let data = await res.json();

        // Detect if server database got reset (e.g. of ephemeral Cloud Run boot)
        // If so, and we are logged in as developer and have a local custom backup, silently restore it!
        const isDefaultState = (data.sections || []).length === 4 && 
                               !(data.sections || []).some((s: any) => s.is_custom === true) &&
                               (data.questions || []).length === 3 &&
                               (data.students || []).length === 0;

        if (!isDefaultState) {
          localStorage.setItem('local_db_backup', JSON.stringify(data));
        } else if (isDevLoggedIn() && getDevToken()) {
          const rawBackup = localStorage.getItem('local_db_backup');
          if (rawBackup) {
            try {
              const backup = JSON.parse(rawBackup);
              if (backup.sections && backup.sections.length > 0) {
                console.log('Detected server reset! Silently restoring custom database backup from developer client storage...');
                const restoreRes = await fetch('/api/dev-action', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({
                    token: getDevToken(),
                    action: 'restore_db_backup',
                    payload: backup
                  })
                });
                if (restoreRes.ok) {
                  const refetchRes = await fetch('/api/db');
                  if (refetchRes.ok) {
                    data = await refetchRes.json();
                  }
                }
              }
            } catch (err) {
              console.error('Failed to parse or restore db backup', err);
            }
          }
        }

        setSections(data.sections.sort((a: Section, b: Section) => a.sort - b.sort));
        setQuestions(data.questions.sort((a: Question, b: Question) => a.sort - b.sort));
        setAchievements(data.achievements);
        setStudentAchievements(data.student_achievements);
        setProgress(data.progress);
        setAds(data.ads.filter((a: Ad) => a.active));
        setNews(data.news.sort((a: News, b: News) => new Date(b.published_at).getTime() - new Date(a.published_at).getTime()));
        setStudents(data.students || []);
        setStudentNotes(data.student_notes || []);
        setPreRegisteredCodes(data.pre_registered_codes || []);
        setIntrusionLogs(data.intrusion_logs || []);
        setCodeShareConflicts(data.code_share_conflicts || []);
        setDeviceBlocks(data.device_blocks || []);
        setPaymentReceipts(data.payment_receipts || []);
        setPaymentRequests(data.payment_requests || []);
        setPrivateMessages(data.private_messages || []);
        setKickedStudents(data.kicked_students || []);
        
        const settingsMap: Record<string, string> = {};
        data.ui_settings.forEach((s: UISetting) => {
          settingsMap[s.key] = s.value;
        });
        setUiSettings(settingsMap);

        // Synced student lookup
        const saved = localStorage.getItem('onboarded_student');
        if (saved) {
          const parsed = JSON.parse(saved);
          const freshStud = (data.students || []).find((s: any) => s.id === parsed.id);
          if (!freshStud) {
            // Robust Session Guard: Only clear the session if explicitly kicked/banned from the server.
            // This completely prevents unwanted logouts on database cold boots or scale-to-zero container recycles.
            const isKicked = (data.kicked_students || []).some((ks: any) => ks.id === parsed.id);
            if (isKicked) {
              setStudentState(null);
              localStorage.removeItem('onboarded_student');
              setActiveAlert({ text: 'تم طرد حسابك وإلغاء صلاحية جلستك من الفصل بقرار معتمد من الإدارة.', type: 'alert' });
            } else {
              console.warn('Student record temporarily not found in sync stream. Preserving session for retry.');
            }
          } else {
            // If student is currently banned, immediately force logout!
            if (freshStud.banned_until && new Date(freshStud.banned_until) > new Date()) {
              setStudentState(null);
              localStorage.removeItem('onboarded_student');
              setActiveAlert({ 
                text: `⛔ تم حظر حسابك الدراسي وجهازك بالكامل بقرار إداري. السبب: ${freshStud.banned_reason || 'غير محدد'}.`, 
                type: 'alert' 
              });
            } else {
              setStudentState(freshStud);
              localStorage.setItem('onboarded_student', JSON.stringify(freshStud));
              
              // Clear temporary ban alerts now that we can load the student successfully!
              setActiveAlert(prev => {
                if (prev && (prev.text.includes('حظر') || prev.text.includes('طرد'))) {
                  return null;
                }
                return prev;
              });
            }
          }
        }
      } else if (res.status === 403) {
        try {
          const errData = await res.json();
          setStudentState(null);
          localStorage.removeItem('onboarded_student');
          setActiveAlert({
            text: errData.error || '⛔ تم حظر هذا الحساب أو هذا الجهاز بالكامل بقرار إداري.',
            type: 'alert'
          });
        } catch (je) {}
      }
    } catch (e) {
      console.error('Failed to pull updated database states', e);
    } finally {
      setLoading(false);
    }
  };

  // Initial load
  useEffect(() => {
    refreshData();
    // Request permission for system-level native push notifications
    if ('Notification' in window && Notification.permission === 'default') {
      Notification.requestPermission().catch(console.warn);
    }
  }, []);

  // Server-Sent Events (SSE) Real-Time subscription hook
  useEffect(() => {
    const eventSource = new EventSource('/api/realtime');

    eventSource.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        if (data && data.table === 'student_action') {
          const actionPayload = data.data;
          
          if (data.eventType === 'GLOBAL_MESSAGE') {
            setActiveAlert({ text: actionPayload.message.text, type: actionPayload.message.type });
            playNotificationSound(actionPayload.message.type || 'warning');
            
            if ('Notification' in window && Notification.permission === 'granted') {
              new Notification('إعلان عام جديد من المنصة 🔔', {
                body: actionPayload.message.text,
                dir: 'rtl'
              });
            }
          } else {
            // Check if it applies to us (loaded from localstorage)
            const saved = localStorage.getItem('onboarded_student');
            if (saved) {
              const activeUser = JSON.parse(saved);
              if (actionPayload.studentId === activeUser.id) {
                if (data.eventType === 'KICK') {
                  setStudentState(null);
                  localStorage.removeItem('onboarded_student');
                  playNotificationSound('kick');
                  setActiveAlert({ text: 'تم طرد حسابك وإلغاء صلاحية جلستك من الفصل بقرار معتمد من الإدارة.', type: 'alert' });
                  
                  if ('Notification' in window && Notification.permission === 'granted') {
                    new Notification('تنبيه هام ⛔', {
                      body: 'تم طرد حسابك وإلغاء صلاحية جلستك من الفصل بقرار مبرر من الإدارة.',
                      dir: 'rtl'
                    });
                  }
                } else if (data.eventType === 'BAN') {
                  if (actionPayload.bannedUntil) {
                    setStudentState(null);
                    localStorage.removeItem('onboarded_student');
                    playNotificationSound('ban');
                    setActiveAlert({ 
                      text: `⛔ تم حظر حسابك الدراسي وجهازك بالكامل بقرار إداري. السبب: ${actionPayload.reason || 'مخالفة لقواعد المنصة'}.`, 
                      type: 'alert' 
                    });
                    
                    if ('Notification' in window && Notification.permission === 'granted') {
                      new Notification('تم حظر حسابك ⛔', {
                        body: `السبب: ${actionPayload.reason || 'مخالفة لقواعد المنصة'}`,
                        dir: 'rtl'
                      });
                    }
                  } else {
                    // Unbanning trigger
                    playNotificationSound('pardon');
                    refreshData();
                    
                    if ('Notification' in window && Notification.permission === 'granted') {
                      new Notification('تم رفع الحظر 🎉', {
                        body: 'تم إلغاء تجميد حسابك الدراسي بنجاح! يمكنك الدخول الفوري الآن.',
                        dir: 'rtl'
                      });
                    }
                  }
                } else if (data.eventType === 'MESSAGE') {
                  setActiveAlert({ text: actionPayload.message.text, type: actionPayload.message.type });
                  playNotificationSound(actionPayload.message.type || 'ping');
                  
                  if ('Notification' in window && Notification.permission === 'granted') {
                    new Notification('تنبيه جديد من المعلم 📌', {
                      body: actionPayload.message.text,
                      dir: 'rtl'
                    });
                  }
                }
              }
            } else {
              // Even if we are currently not logged in (e.g. on onboarding display), if our student ID is unbanned, refresh!
              if (data.eventType === 'BAN' && !actionPayload.bannedUntil) {
                // Play unbanned success arpeggio
                playNotificationSound('pardon');
                refreshData();
                
                if ('Notification' in window && Notification.permission === 'granted') {
                  new Notification('تم رفع الحظر 🎉', {
                    body: 'تم تفعيل الحساب الدراسي ورفع القيود بنجاح!',
                    dir: 'rtl'
                  });
                }
              }
            }
          }
        } else if (data && data.table) {
          console.log(`Realtime Update received for table ${data.table}:`, data);
          if (data.table === 'community_messages') {
            // Dispatch a highly optimized window event to notify active CommunityChat screens instantly.
            // This prevents calling refreshData() and secures maximum client responsiveness.
            window.dispatchEvent(new CustomEvent('community_message_received', { detail: data }));
          } else if (data.table === 'private_messages') {
            // Update local state in-place to avoid heavy API db loads.
            if (data.eventType === 'INSERT') {
              const msg = data.data;
              setPrivateMessages(prev => {
                if (prev.some(m => m.id === msg.id)) return prev;

                // Play Audio and Trigger phone vibration
                const isDev = isDevLoggedIn() && getDevToken();
                const studentSaved = localStorage.getItem('onboarded_student');

                if (isDev) {
                  // Admin/Master hears high-quality chime when a student replies or opens a ticket
                  if (msg.sender === 'student') {
                    playNotificationSound('ping');
                    if ('Notification' in window && Notification.permission === 'granted') {
                      new Notification(`رسالة جديدة من ${msg.student_name || 'طالب'} 💬`, {
                        body: msg.text,
                        dir: 'rtl'
                      });
                    }
                  }
                } else if (studentSaved) {
                  try {
                    const activeUser = JSON.parse(studentSaved);
                    // Student hears high-quality chime when Developer sends a direct message
                    if (msg.sender === 'developer' && msg.student_id === activeUser.id) {
                      playNotificationSound('ping');
                      if ('Notification' in window && Notification.permission === 'granted') {
                        new Notification('رسالة خاصة جديدة من المعلم 💬', {
                          body: msg.text,
                          dir: 'rtl'
                        });
                      }
                    }
                  } catch (e) {}
                }

                return [...prev, msg];
              });
            } else if (data.eventType === 'DELETE') {
              setPrivateMessages(prev => prev.filter(m => m.id !== data.data.id));
            }
          } else if (data.table === 'students') {
            if (data.eventType === 'UPDATE') {
              setStudents(prev => prev.map(s => s.id === data.data.id ? data.data : s));
              // Also update the active student state if it's the current user logged in
              const saved = localStorage.getItem('onboarded_student');
              if (saved) {
                try {
                  const activeUser = JSON.parse(saved);
                  if (activeUser.id === data.data.id) {
                    const wasBanned = studentState && studentState.banned_until !== null;
                    setStudentState(data.data);
                    localStorage.setItem('onboarded_student', JSON.stringify(data.data));

                    // If the student is currently unbanned dynamically, trigger praise arpeggio!
                    if (data.data.banned_until === null) {
                      setActiveAlert(null);
                      if (wasBanned) {
                        playNotificationSound('pardon');
                        if ('Notification' in window && Notification.permission === 'granted') {
                          new Notification('تم إلغاء الحظر 🎉', {
                            body: 'لقد تم رفع الحظر عن حسابك بنجاح الآن بواسطة المعلم! يمكنك العودة للدراسة.',
                            dir: 'rtl'
                          });
                        }
                      }
                    }
                  }
                } catch (e) {}
              }
            } else if (data.eventType === 'INSERT') {
              setStudents(prev => {
                if (prev.some(s => s.id === data.data.id)) return prev;
                return [...prev, data.data];
              });
            } else if (data.eventType === 'DELETE') {
              setStudents(prev => prev.filter(s => s.id !== data.data.id));
            }
          } else if (data.table === 'community_groups') {
            // Dispatch event to allow real-time group listing updates without heavy fetch.
            window.dispatchEvent(new CustomEvent('community_groups_received', { detail: data }));
          } else if (['sections', 'questions', 'achievements', 'ads', 'news', 'ui_settings', 'student_notes', 'pre_registered_codes', 'intrusion_logs', 'payment_receipts', 'payment_requests'].includes(data.table)) {
            // Re-sync only if a critical system table changed
            refreshData();
          }
        }
      } catch (err) {
        // Ping or malformed events ignored
      }
    };

    eventSource.onerror = () => {
      console.warn('Realtime updates disconnected. Attempting automatic reconnection...');
    };

    return () => {
      eventSource.close();
    };
  }, []);

  // Update progress after correctly or incorrectly answering an item
  const updateProgress = async (sectionId: string, xpAmount: number, isCorrect: boolean) => {
    if (!student) {
      throw new Error('يجب تسجيل الدخول كطالب أولاً.');
    }

    const response = await fetch('/api/progress/update', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        studentId: student.id,
        sectionId,
        xpAmount,
        isCorrect
      })
    });

    if (!response.ok) {
      const errData = await response.json();
      throw new Error(errData.error || 'فشل تحديث التقدم الدراسي.');
    }

    const result = await response.json();
    // Re-fetch to synchronize and fire notifications
    await refreshData();
    return result;
  };

  const resetLocalStudent = async () => {
    if (student) {
      try {
        await fetch('/api/students/reset', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ studentId: student.id })
        });
      } catch (e) {
        console.error(e);
      }
    }
    setStudent(null);
    await refreshData();
  };

  const updateUISettings = (newSettings: Record<string, string>) => {
    setUiSettings(prev => ({ ...prev, ...newSettings }));
  };

  const addNote = async (sectionId: string, sectionTitle: string, noteText: string) => {
    if (!student) throw new Error('يجب تسجيل الدخول كطالب أولاً.');
    const response = await fetch('/api/notes/add', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        studentId: student.id,
        sectionId,
        sectionTitle,
        noteText
      })
    });
    if (!response.ok) {
      const err = await response.json();
      throw new Error(err.error || 'فشل حفظ الملاحظة الشخصية.');
    }
    await refreshData();
  };

  const deleteNote = async (noteId: string) => {
    if (!student) throw new Error('يجب تسجيل الدخول كطالب أولاً.');
    const response = await fetch('/api/notes/delete', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        studentId: student.id,
        noteId
      })
    });
    if (!response.ok) {
      const err = await response.json();
      throw new Error(err.error || 'فشل حذف الملاحظة.');
    }
    await refreshData();
  };

  return (
    <AppContext.Provider
      value={{
        student,
        students,
        theme,
        devMode,
        sections,
        questions,
        achievements,
        studentAchievements,
        progress,
        ads,
        news,
        uiSettings,
        studentNotes,
        preRegisteredCodes,
        intrusionLogs,
        codeShareConflicts,
        deviceBlocks,
        paymentReceipts,
        paymentRequests,
        privateMessages,
        kickedStudents,
        db: {
          students,
          pre_registered_codes: preRegisteredCodes,
          intrusion_logs: intrusionLogs,
          code_share_conflicts: codeShareConflicts,
          device_blocks: deviceBlocks,
          payment_receipts: paymentReceipts,
          payment_requests: paymentRequests,
          kicked_students: kickedStudents,
        },
        addNote,
        deleteNote,
        loading,
        activeAlert,
        setActiveAlert,
        setStudent,
        setTheme: changeTheme,
        setDevMode,
        updateProgress,
        updateUISettings,
        refreshData,
        resetLocalStudent,
        setQuestions,
        setSections
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}
