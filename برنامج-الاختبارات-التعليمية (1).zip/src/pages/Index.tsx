import { useApp } from '../context/AppContext';
import XPBar from '../components/XPBar';
import SubjectCard from '../components/SubjectCard';
import AdBlock from '../components/AdBlock';
import NewsCard from '../components/NewsCard';
import { Section } from '../types';
import { BookOpen, AlertCircle, RefreshCw, Star, ArrowLeft } from 'lucide-react';
import { motion } from 'motion/react';

interface IndexProps {
  onSelectSection: (sectionSlug: string) => void;
  setActivePage: (p: 'home' | 'subject' | 'progress' | 'settings' | 'developer') => void;
}

export default function Index({ onSelectSection, setActivePage }: IndexProps) {
  const { sections, questions, progress, ads, news, loading, refreshData, student } = useApp();

  const totalXp = progress.reduce((sum, p) => sum + p.xp, 0);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center p-24" dir="rtl">
        <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mb-4" />
        <span className="text-sm font-bold text-slate-500">جاري تحميل منصة الاختبارات...</span>
      </div>
    );
  }

  return (
    <div className="space-y-8" dir="rtl">
      
      {/* Top Banner section */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-6 bg-gradient-to-l from-blue-900/35 via-slate-900/40 to-transparent border border-blue-900/30 dark:border-blue-800/30 rounded-[2rem] p-6 sm:p-8 text-white relative overflow-hidden shadow-lg shadow-blue-950/20 backdrop-blur-sm">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom_right,_var(--tw-gradient-stops))] from-blue-500/10 via-transparent to-transparent pointer-events-none" />
        
        <div className="text-right space-y-3 relative z-10">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-blue-500/10 backdrop-blur-sm text-xs font-bold rounded-lg border border-blue-500/20 text-blue-400">
            <Star className="w-3.5 h-3.5 text-amber-300 fill-amber-300/30" />
            <span>نظام النقاط XP مفعّل!</span>
          </span>
          <h2 className="text-2xl sm:text-3xl font-black tracking-tight leading-snug">
            أهلاً بك يا {student?.display_name || 'طالبنا العزيز'}!
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 max-w-lg leading-relaxed font-medium">
            استكشف الأقسام التعليمية المدرجة بالأسفل، اختبر معلوماتك، اربح XP لتتخطى مستويات الأذكياء وحافظ على سلسلة الإجابة اليومية!
          </p>
        </div>

        <div className="shrink-0 relative z-10 w-full sm:w-auto">
          <button 
            id="quick-progress-btn"
            onClick={() => setActivePage('progress')}
            className="w-full sm:w-auto px-6 py-3.5 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-2xl shadow-lg shadow-blue-600/20 border border-blue-500/20 active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer text-sm"
          >
            <span>عرض نتائج تقدمي</span>
            <ArrowLeft className="w-4 h-4 shrink-0" />
          </button>
        </div>
      </div>

      {/* Realtime progress tracker */}
      <XPBar totalXp={totalXp} />

      {/* Main Responsive Grid arrangement */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
        
        {/* Right side: Sections deck & commercials */}
        <div className="lg:col-span-2 space-y-8">
          
          <div className="text-right">
            <h3 className="text-xl font-bold text-slate-800 dark:text-white flex items-center gap-2">
              <BookOpen className="w-5.5 h-5.5 text-blue-600" />
              <span>المواد والأقسام التعليمية</span>
            </h3>
            <p className="text-xs text-slate-400 dark:text-slate-500 mt-1 leading-relaxed">
              اختر مادة للبدء بحل الأسئلة التفاعلية وكسب نقاط الخبرة والدراسة:
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {sections.length === 0 ? (
              <div className="col-span-2 p-12 bg-white dark:bg-slate-900 border border-dashed border-slate-200 dark:border-slate-800 rounded-3xl flex flex-col items-center justify-center text-center">
                <AlertCircle className="w-10 h-10 text-amber-500 mb-3" />
                <span className="text-sm font-bold text-slate-500">لم يتم إدراج أي أقسام حتى الآن.</span>
                <span className="text-xs text-slate-400 mt-1">يرجى من المطور إدراج أقسام جديدة من لوحة التحكم.</span>
              </div>
            ) : (
              sections.map((sect: Section) => (
                <SubjectCard
                  key={sect.id}
                  section={sect}
                  questions={questions}
                  progress={progress}
                  onSelect={() => onSelectSection(sect.slug)}
                />
              ))
            )}
          </div>

          {/* Dynamic Commercial/Instructional Block */}
          {ads.length > 0 && (
            <div className="space-y-4">
              <div className="text-right">
                <h4 className="text-sm font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">لوحة الإعلانات والتحديات</h4>
              </div>
              <div className="space-y-4">
                {ads.map(ad => (
                  <AdBlock key={ad.id} ad={ad} />
                ))}
              </div>
            </div>
          )}

        </div>

        {/* Left side: News sidebar feeds */}
        <div className="space-y-8 lg:sticky lg:top-24">
          
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-extrabold text-slate-800 dark:text-white uppercase">آخر الأخبار التعليمية</h4>
            <button
              onClick={refreshData}
              className="p-1 px-2.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-900 dark:hover:bg-slate-800 text-slate-500 rounded-lg text-xs flex items-center gap-1 cursor-pointer transition font-bold"
              title="تحديث البيانات فوراً"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>تحديث</span>
            </button>
          </div>

          <div className="space-y-6">
            {news.length === 0 ? (
              <div className="p-8 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-3xl text-center">
                <span className="text-xs font-bold text-slate-400">لا توجد أخبار مدرجة بالوقت الحالي.</span>
              </div>
            ) : (
              news.map(item => (
                <NewsCard key={item.id} news={item} />
              ))
            )}
          </div>

        </div>

      </div>

    </div>
  );
}
