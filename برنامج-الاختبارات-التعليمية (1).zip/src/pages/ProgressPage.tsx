import { useApp } from '../context/AppContext';
import AchievementBadge from '../components/AchievementBadge';
import BadgesPortfolio from '../components/BadgesPortfolio';
import { 
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell, 
  AreaChart, Area, CartesianGrid, Legend 
} from 'recharts';
import { 
  BarChart2, Star, Trophy, HelpCircle, Activity, Award, 
  TrendingUp, Sparkles, Calendar, Trash2, FileText 
} from 'lucide-react';
import { motion } from 'motion/react';
import { colorMap } from '../components/SubjectCard';

// Deterministic historical progress generation for the last 30 days based on total XP and student ID
function generate30DaysHistory(totalXp: number, studentId: string) {
  const history = [];
  const today = new Date();
  
  let seed = 0;
  for (let i = 0; i < studentId.length; i++) {
    seed += studentId.charCodeAt(i);
  }

  const numDays = 30;
  const increments = new Array(numDays).fill(0);
  
  if (totalXp > 0) {
    let remainingXp = totalXp;
    const activeDaysCount = Math.max(6, Math.min(24, (seed % 10) + 12));
    const activeDayIndices: number[] = [];
    
    while (activeDayIndices.length < activeDaysCount) {
      const idx = Math.floor(Math.abs(Math.sin(seed + activeDayIndices.length) * 1000)) % numDays;
      if (!activeDayIndices.includes(idx)) {
        activeDayIndices.push(idx);
      }
    }
    
    activeDayIndices.sort((a, b) => a - b);
    
    let sumWeights = 0;
    const weights = activeDayIndices.map((idx, i) => {
      const w = Math.round((i + 1) * (1 + (Math.abs(Math.cos(seed + idx)) * 0.5)) * 100) / 100;
      sumWeights += w;
      return w;
    });
    
    let allocated = 0;
    activeDayIndices.forEach((dayIdx, i) => {
      let dailyAlloc = 0;
      if (i === activeDayIndices.length - 1) {
        dailyAlloc = remainingXp - allocated;
      } else {
        dailyAlloc = Math.floor((weights[i] / sumWeights) * totalXp);
        allocated += dailyAlloc;
      }
      increments[dayIdx] = Math.max(0, dailyAlloc);
    });
  }

  let cumulativeXp = 0;
  for (let i = 0; i < numDays; i++) {
    cumulativeXp += increments[i];
    const lvl = Math.floor(cumulativeXp / 100) + 1;
    
    const d = new Date();
    d.setDate(today.getDate() - (numDays - 1 - i));
    
    // Format date beautifully as Day/Month
    const dayStr = d.getDate().toString().padStart(2, '0') + '/' + (d.getMonth() + 1).toString().padStart(2, '0');
    
    history.push({
      date: dayStr,
      xp: cumulativeXp,
      level: lvl,
      dailyXp: increments[i],
    });
  }
  
  return history;
}

export default function ProgressPage() {
  const { progress, sections, achievements, studentAchievements, student, studentNotes, deleteNote } = useApp();

  if (!student) {
    return (
      <div className="p-8 text-center bg-slate-50 dark:bg-slate-900 border rounded-3xl" dir="rtl">
        <span className="text-sm font-bold text-slate-500">الرجاء تسجيل الدخول أولاً لعرض تقارير الأداء.</span>
      </div>
    );
  }

  // Filter progress, achievements & notes specifically for this student
  const studentProgress = progress.filter(p => p.student_id === student.id);
  const studentUnlockedAchievements = studentAchievements.filter(sa => sa.student_id === student.id);
  const unlockedIds = studentUnlockedAchievements.map(sa => sa.achievement_id);
  const studentMyNotes = studentNotes ? studentNotes.filter(n => n.student_id === student.id) : [];

  // Compute stats totals
  const totalXp = studentProgress.reduce((sum, p) => sum + p.xp, 0);
  const totalAnswered = studentProgress.reduce((sum, p) => sum + p.answered, 0);
  const totalCorrect = studentProgress.reduce((sum, p) => sum + p.correct, 0);
  const accuracyPercent = totalAnswered > 0 ? Math.round((totalCorrect / totalAnswered) * 100) : 0;

  // Generate historical data for the last 30 days
  const historyData = generate30DaysHistory(totalXp, student.id);

  // Prepare chart data for Recharts
  const chartData = sections.map((sect) => {
    const prog = studentProgress.find(p => p.section_id === sect.id);
    return {
      name: sect.title,
      xp: prog ? prog.xp : 0,
      answered: prog ? prog.answered : 0,
      correct: prog ? prog.correct : 0,
      color: sect.color
    };
  });

  const getThemeColorHex = (colorName: string) => {
    switch (colorName) {
      case 'blue': return '#2563eb';
      case 'green': return '#16a34a';
      case 'purple': return '#9333ea';
      case 'orange': return '#ea580c';
      case 'rose': return '#e11d48';
      case 'teal': return '#0d9488';
      case 'amber': return '#d97706';
      default: return '#3b82f6';
    }
  };

  return (
    <div className="space-y-8 text-right" dir="rtl">
      
      {/* Title heading */}
      <div>
        <h3 className="text-xl font-black text-slate-800 dark:text-white flex items-center gap-2">
          <BarChart2 className="w-5.5 h-5.5 text-blue-600" />
          <span>ملف تقدم الطالب: {student.display_name}</span>
        </h3>
        <p className="text-xs text-slate-400 dark:text-slate-500 mt-1">
          تقرير شامل لرصد مستويات الذكاء وحصاد نقاط كورس التعليم:
        </p>
      </div>

      {/* Grid status cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        
        <div className="p-5 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 bg-amber-500/10 text-amber-600 dark:text-amber-400 rounded-xl flex items-center justify-center shrink-0">
            <Star className="w-6 h-6 fill-amber-500/20" />
          </div>
          <div>
            <span className="block text-[10px] text-slate-400 font-bold uppercase">إجمالي نقاط الخبرة</span>
            <span className="text-lg font-black font-mono text-amber-500 mt-0.5 block">{totalXp} XP</span>
          </div>
        </div>

        <div className="p-5 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 bg-blue-500/10 text-blue-600 dark:text-blue-400 rounded-xl flex items-center justify-center shrink-0">
            <HelpCircle className="w-6 h-6" />
          </div>
          <div>
            <span className="block text-[10px] text-slate-400 font-bold uppercase">الأسئلة المحلولة</span>
            <span className="text-lg font-black font-mono text-blue-600 dark:text-blue-400 mt-0.5 block">{totalAnswered} سؤال</span>
          </div>
        </div>

        <div className="p-5 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 bg-green-500/10 text-green-600 dark:text-green-400 rounded-xl flex items-center justify-center shrink-0">
            <Trophy className="w-6 h-6" />
          </div>
          <div>
            <span className="block text-[10px] text-slate-400 font-bold uppercase">الإجابات الصحيحة</span>
            <span className="text-lg font-black font-mono text-green-600 dark:text-green-400 mt-0.5 block">{totalCorrect} إجابة</span>
          </div>
        </div>

        <div className="p-5 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 bg-purple-500/10 text-purple-600 dark:text-purple-400 rounded-xl flex items-center justify-center shrink-0">
            <Activity className="w-6 h-6" />
          </div>
          <div>
            <span className="block text-[10px] text-slate-400 font-bold uppercase">معدل الدقة العلمي</span>
            <span className="text-lg font-black font-mono text-purple-600 dark:text-purple-400 mt-0.5 block">{accuracyPercent}%</span>
          </div>
        </div>

      </div>

      {/* Recharts chart & achievement split layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
        
        {/* Right column: Charts */}
        <div className="lg:col-span-2 space-y-8">
          
          {/* Points Chart diagram */}
          <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-6">
            <div>
              <h4 className="text-base font-bold text-slate-800 dark:text-white flex items-center gap-1.5">
                <Activity className="w-4.5 h-4.5 text-blue-500" />
                <span>مخطط نقاط الخبرة XP لكل مادة تعليمية</span>
              </h4>
              <p className="text-xs text-slate-400 mt-0.5">توزيع نقاط التقدم لحل الكويزات لترسيخ المفاهيم:</p>
            </div>

            <div className="w-full h-80" dir="ltr">
              {totalXp === 0 ? (
                <div className="w-full h-full flex flex-col items-center justify-center text-center text-slate-400 text-xs">
                  <span>لا توجد بيانات مخطط كافية للرسم حالياً.</span>
                  <span>تفضل بحل أول كويز لتسجيل التقدم البياني!</span>
                </div>
              ) : (
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                    <XAxis dataKey="name" stroke="#94a3b8" fontSize={11} tickLine={false} />
                    <YAxis stroke="#94a3b8" fontSize={11} tickLine={false} />
                    <Tooltip
                      cursor={{ fill: 'rgba(148, 163, 184, 0.05)' }}
                      contentStyle={{
                        backgroundColor: '#1e293b',
                        borderRadius: '12px',
                        border: 'none',
                        color: '#f8fafc',
                        fontSize: '12px',
                        fontFamily: 'system-ui, sans-serif'
                      }}
                    />
                    <Bar dataKey="xp" radius={[8, 8, 0, 0]} barSize={44}>
                      {chartData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={getThemeColorHex(entry.color)} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              )}
            </div>
          </div>

          {/* 30-Day Evolutionary Progress Line/Area Chart */}
          <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h4 className="text-base font-black text-slate-800 dark:text-white flex items-center gap-1.5">
                  <TrendingUp className="w-5 h-5 text-amber-500" />
                  <span>منحنى تطور مستوى الطالب ونقاط خبرته (آخر 30 يوماً)</span>
                </h4>
                <p className="text-xs text-slate-400 dark:text-slate-500 mt-1">
                  تتبع الزيادة التراكمية في النقاط وصعود مستوى العبقرية لآخر شهر:
                </p>
              </div>
              
              <div className="flex items-center gap-2 bg-indigo-50 dark:bg-indigo-950/40 px-3 py-1.5 rounded-xl border border-indigo-100/40 dark:border-indigo-900/10">
                <Calendar className="w-3.5 h-3.5 text-indigo-500" />
                <span className="text-[11px] font-bold text-indigo-700 dark:text-indigo-400">منحنى 30 يوماً</span>
              </div>
            </div>

            <div className="w-full h-80" dir="ltr">
              {totalXp === 0 ? (
                <div className="w-full h-full flex flex-col items-center justify-center text-center text-slate-400 text-xs">
                  <span>لا توجد بيانات كافية لعرض منحنى التطور حالياً.</span>
                  <span>تفضل ببدء حل الكويزات لتراكم نقاط الخبرة وصعود المخطط!</span>
                </div>
              ) : (
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={historyData} margin={{ top: 20, right: 10, left: -25, bottom: 0 }}>
                    <defs>
                      <linearGradient id="colorXp" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.25}/>
                        <stop offset="95%" stopColor="#f59e0b" stopOpacity={0}/>
                      </linearGradient>
                      <linearGradient id="colorLevel" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.15}/>
                        <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" className="dark:stroke-slate-800/10" />
                    <XAxis dataKey="date" stroke="#94a3b8" fontSize={10} tickLine={false} />
                    <YAxis yAxisId="left" stroke="#f59e0b" fontSize={10} tickLine={false} label={{ value: 'XP التراكمي', angle: -90, position: 'insideLeft', style: { fill: '#d97706', fontSize: '9px', fontWeight: 'bold' } }} />
                    <YAxis yAxisId="right" orientation="right" stroke="#3b82f6" fontSize={10} tickLine={false} label={{ value: 'المستوى الأكاديمي', angle: 90, position: 'insideRight', style: { fill: '#2563eb', fontSize: '9px', fontWeight: 'bold' } }} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#0f172a',
                        borderRadius: '16px',
                        border: '1px solid #334155',
                        color: '#f8fafc',
                        fontSize: '11px',
                        fontFamily: 'system-ui, sans-serif'
                      }}
                      formatter={(value: any, name: string) => {
                        if (name === 'xp') return [`${value} XP`, 'مجموع النقاط'];
                        if (name === 'level') return [`الدرجة ${value}`, 'المستوى الرقمي'];
                        if (name === 'dailyXp') return [`+${value} XP`, 'حصاد اليوم'];
                        return [value, name];
                      }}
                    />
                    <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }} />
                    <Area yAxisId="left" type="monotone" dataKey="xp" name="xp" stroke="#f59e0b" strokeWidth={3} fillOpacity={1} fill="url(#colorXp)" dot={{ r: 2, strokeWidth: 1 }} activeDot={{ r: 5 }} />
                    <Area yAxisId="right" type="monotone" dataKey="level" name="level" stroke="#3b82f6" strokeWidth={3} fillOpacity={1} fill="url(#colorLevel)" strokeDasharray="4 4" dot={{ r: 3, strokeWidth: 1 }} activeDot={{ r: 6 }} />
                  </AreaChart>
                </ResponsiveContainer>
              )}
            </div>
            
            {/* Dynamic educational suggestion insight */}
            {totalXp > 0 && (
              <div className="flex items-start gap-3 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-amber-500/10 via-yellow-500/5 to-transparent p-4.5 rounded-2xl border border-amber-300/20 dark:border-amber-900/20 text-right">
                <Sparkles className="w-5 h-5 text-amber-500 mt-0.5 shrink-0 animate-pulse" />
                <div>
                  <span className="text-xs font-black text-amber-800 dark:text-yellow-500 block pb-1">تحليل منحة الذكاء والمستوى اليومي:</span>
                  <span className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed block">
                    رائع! يظهر مخطط النمو تدركًا ممتازًا وصعودًا تدريجيًا لمستواك العام. استمر في حل المسابقات المدرسية لرفع نسبة التفوق والحصول على الأوسمة الذهبية والماسية فوريًا!
                  </span>
                </div>
              </div>
            )}
          </div>

        </div>

        {/* Left column: Badges achievements list */}
        <div className="lg:col-span-1 space-y-6">
          <BadgesPortfolio />

          {/* Student Personal Notes List */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-4 text-right"
          >
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-2 text-slate-800 dark:text-white">
                <FileText className="w-5 h-5 text-amber-500" />
                <span className="font-black text-sm">مفكرة ملاحظاتي الشخصية</span>
              </div>
              <span className="text-[10px] bg-slate-100 dark:bg-slate-800 px-2.5 py-1 text-slate-500 dark:text-slate-400 rounded-full font-bold">
                {studentMyNotes.length} ملاحظات
              </span>
            </div>

            {studentMyNotes.length === 0 ? (
              <div className="text-center py-6 text-slate-400 text-xs">
                <span>لا توجد أي ملاحظات محفوظة حالياً.</span>
                <p className="text-[10px] text-slate-400/70 mt-1 leading-relaxed">
                  اكتب ملاحظاتك عند إنهاء أي اختبار لمراجعتها لاحقاً في هذه المفكرة المباشرة.
                </p>
              </div>
            ) : (
              <div className="space-y-4 max-h-[350px] overflow-y-auto pr-1 scrollbar-thin">
                {studentMyNotes.map((note) => (
                  <div 
                    key={note.id} 
                    className="p-4 bg-slate-50 dark:bg-slate-950 border border-slate-100 dark:border-slate-800 rounded-2xl space-y-2 relative group hover:border-slate-200 dark:hover:border-slate-700/60 transition duration-200"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-black text-blue-600 dark:text-blue-400">
                        {note.section_title}
                      </span>
                      <button
                        onClick={() => deleteNote(note.id)}
                        className="text-slate-400 hover:text-rose-600 dark:text-slate-600 dark:hover:text-rose-500 transition cursor-pointer p-1 rounded-md"
                        title="مسح هذه الملاحظة"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                    <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed font-medium">
                      {note.note_text}
                    </p>
                    <div className="flex items-center gap-1 text-[9px] text-slate-400 font-bold">
                      <Calendar className="w-3 h-3 text-slate-400" />
                      <span>{new Date(note.created_at).toLocaleDateString('ar-EG', { day: 'numeric', month: 'long', year: 'numeric' })}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </motion.div>
        </div>

      </div>

    </div>
  );
}
