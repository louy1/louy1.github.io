import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Users, MessageSquare, Send, Image, Video, VideoOff, Mic, MicOff, Square, Play, Pause, 
  Settings, Lock, LockOpen, Volume2, ShieldAlert, BadgeInfo, Trash2, ArrowRight, CornerUpLeft, X
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface Group {
  id: string;
  name: string;
  creator_id: string;
  creator_name: string;
  is_frozen: boolean;
  allow_images: boolean;
  allow_audio: boolean;
  allow_videos?: boolean;
  created_at: string;
}

interface Message {
  id: string;
  group_id: string;
  sender_id: string;
  sender_name: string;
  text: string;
  image_url?: string;
  audio_url?: string;
  video_url?: string;
  reply_to_id?: string;
  reply_to_name?: string;
  reply_to_text?: string;
  created_at: string;
}

export default function CommunityChatPage() {
  const { student, db } = useApp();
  const isDev = student?.id === 'developer_main' || student?.display_name === (db?.ui_settings?.find(s => s.key === 'dev_email')?.value || 'Developer060@gmail.com');
  const abortControllerRef = useRef<AbortController | null>(null);

  const [groups, setGroups] = useState<Group[]>([]);
  const [activeGroupId, setActiveGroupId] = useState<string>('general');
  const [messages, setMessages] = useState<Message[]>([]);
  
  // Custom states for writing messsage
  const [text, setText] = useState('');
  const [sending, setSending] = useState(false);
  const [imageFile, setImageFile] = useState<string | null>(null);
  const [videoFile, setVideoFile] = useState<string | null>(null);
  const [isReadingFile, setIsReadingFile] = useState(false);
  const [replyingTo, setReplyingTo] = useState<Message | null>(null);

  // Lightbox modal state for viewing images/videos inline
  const [activeMediaLightbox, setActiveMediaLightbox] = useState<{ type: 'image' | 'video'; url: string } | null>(null);

  // Group creation modal states
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newGroupName, setNewGroupName] = useState('');
  const [allowImages, setAllowImages] = useState(true);
  const [allowAudio, setAllowAudio] = useState(true);
  const [allowVideos, setAllowVideos] = useState(true);
  const [modalError, setModalError] = useState('');

  // Voice recording states
  const [recording, setRecording] = useState(false);
  const [recordingDuration, setRecordingDuration] = useState(0);
  const [audioBlobBase64, setAudioBlobBase64] = useState<string | null>(null);
  
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordingTimerRef = useRef<any>(null);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  // Load groups and messages on mount or when active group changes
  useEffect(() => {
    fetchGroups();
  }, []);

  useEffect(() => {
    fetchMessages();
    
    // Setup optimized fast polling interval for instant community chat feel
    const interval = setInterval(() => {
      fetchMessages();
    }, 1500);

    return () => clearInterval(interval);
  }, [activeGroupId]);

  // Real-time Event Listeners for instant updates without any lag or freezes
  useEffect(() => {
    const handleMessageReceived = (event: Event) => {
      const customEvent = event as CustomEvent;
      const payload = customEvent.detail;
      
      if (payload && payload.table === 'community_messages') {
        const msg = payload.data;
        if (msg.group_id === activeGroupId) {
          if (payload.eventType === 'INSERT') {
            setMessages(prev => {
              if (prev.some(m => m.id === msg.id)) return prev;
              return [...prev, msg];
            });
            setTimeout(() => {
              messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
            }, 100);
          } else if (payload.eventType === 'DELETE') {
            setMessages(prev => prev.filter(m => m.id !== msg.id));
          }
        }
      }
    };

    const handleGroupsReceived = (event: Event) => {
      const customEvent = event as CustomEvent;
      const payload = customEvent.detail;
      if (payload && payload.table === 'community_groups') {
        fetchGroups();
      }
    };

    window.addEventListener('community_message_received', handleMessageReceived);
    window.addEventListener('community_groups_received', handleGroupsReceived);

    return () => {
      window.removeEventListener('community_message_received', handleMessageReceived);
      window.removeEventListener('community_groups_received', handleGroupsReceived);
    };
  }, [activeGroupId]);

  const fetchGroups = async () => {
    try {
      const res = await fetch('/api/community/groups');
      const data = await res.json();
      if (res.ok) {
        setGroups(data);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const fetchMessages = async () => {
    try {
      const res = await fetch(`/api/community/messages?groupId=${activeGroupId}`);
      const data = await res.json();
      if (res.ok) {
        setMessages(data);
        setTimeout(() => {
          messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
        }, 150);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleCreateGroup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newGroupName.trim()) {
      setModalError('الرجاء كتابة اسم المجموعة الجديدة.');
      return;
    }

    if (!isDev) {
      setModalError('عذراً! المطور هو الشخص الوحيد المخول بإنشاء مجموعات وغرف الدردشة الجماعية.');
      return;
    }

    const finalCreatorId = isDev ? 'developer_main' : (student?.id || 'guest');
    const finalCreatorName = isDev ? (db?.ui_settings?.find(s => s.key === 'dev_display_name')?.value || 'المطور الرئيسي') : (student?.display_name || 'طالب مجهول');

    try {
      const res = await fetch('/api/community/groups', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: newGroupName.trim(),
          creatorId: finalCreatorId,
          creatorName: finalCreatorName,
          allowImages,
          allowAudio,
          allowVideos
        })
      });

      const data = await res.json();
      if (!res.ok) {
        setModalError(data.error || 'فشل إنشاء المجموعة.');
      } else {
        setShowCreateModal(false);
        setNewGroupName('');
        setAllowImages(true);
        setAllowAudio(true);
        setAllowVideos(true);
        setModalError('');
        // Reload & activate new group
        fetchGroups();
        setActiveGroupId(data.id);
      }
    } catch (e) {
      setModalError('حدث خطأ أثناء التفاوض مع خادم الدردشة.');
    }
  };

  const handleVideoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 25 * 1024 * 1024) {
      alert('⚠️ حجم الفيديو كبير جداً! يرجى اختيار مقطع فيديو أقل من 25 ميغابايت لضمان سرعة إرساله.');
      return;
    }

    setIsReadingFile(true);
    const reader = new FileReader();
    reader.onload = () => {
      setVideoFile(reader.result as string);
      setImageFile(null);
      setAudioBlobBase64(null);
      setIsReadingFile(false);
    };
    reader.onerror = () => {
      alert('⚠️ فشل قراءة الفيديو.');
      setIsReadingFile(false);
    };
    reader.readAsDataURL(file);
  };

  // Convert local file to base64
  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      alert('⚠️ حجم الصورة كبير جداً! يرجى اختيار صورة أقل من 5 ميغابايت لضمان سرعة الإرسال.');
      return;
    }

    setIsReadingFile(true);
    const reader = new FileReader();
    reader.onload = () => {
      setImageFile(reader.result as string);
      setVideoFile(null);
      setAudioBlobBase64(null);
      setIsReadingFile(false);
    };
    reader.onerror = () => {
      alert('⚠️ فشل قراءة الصورة.');
      setIsReadingFile(false);
    };
    reader.readAsDataURL(file);
  };

  // Recording Audio controls
  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      
      // Allow browser to determine its preferred default MIME type to ensure compatibility (Safari uses audio/mp4, Chrome uses audio/webm)
      let options: any = null;
      if (typeof MediaRecorder.isTypeSupported === 'function') {
        if (MediaRecorder.isTypeSupported('audio/webm')) {
          options = { mimeType: 'audio/webm' };
        } else if (MediaRecorder.isTypeSupported('audio/mp4')) {
          options = { mimeType: 'audio/mp4' };
        }
      }
      
      const mediaRecorder = options ? new MediaRecorder(stream, options) : new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      
      const chunks: Blob[] = [];
      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) chunks.push(e.data);
      };

      mediaRecorder.onstop = () => {
        const recordedMimeType = mediaRecorder.mimeType || 'audio/webm';
        const blob = new Blob(chunks, { type: recordedMimeType });
        const reader = new FileReader();
        reader.onloadend = () => {
          setAudioBlobBase64(reader.result as string);
        };
        reader.readAsDataURL(blob);
        
        // Stop all audio tracks to free up mic icon
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start();
      setRecording(true);
      setRecordingDuration(0);

      recordingTimerRef.current = setInterval(() => {
        setRecordingDuration(prev => prev + 1);
      }, 1000);

    } catch (e) {
      alert('⚠️ تعذر تشغيل الميكروفون! يرجى السماح للبرنامج بتصريح استخدام الميكروفون لتتمكن من إرسال البصمات الصوتية.');
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && recording) {
      mediaRecorderRef.current.stop();
      clearInterval(recordingTimerRef.current);
      setRecording(false);
    }
  };

  const cancelRecording = () => {
    if (mediaRecorderRef.current && recording) {
      mediaRecorderRef.current.stop();
      clearInterval(recordingTimerRef.current);
      setRecording(false);
      setTimeout(() => {
        setAudioBlobBase64(null);
      }, 100);
    }
  };

  const handleSendMessage = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!text.trim() && !imageFile && !audioBlobBase64 && !videoFile) return;

    // Reset previous controller if any
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }

    const controller = new AbortController();
    abortControllerRef.current = controller;
    setSending(true);

    try {
      const res = await fetch('/api/community/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          groupId: activeGroupId,
          senderId: student?.id || 'guest',
          senderName: student?.display_name || 'طالب',
          text: text,
          image: imageFile,
          audio: audioBlobBase64,
          video: videoFile,
          replyToId: replyingTo?.id || undefined,
          replyToName: replyingTo?.sender_name || undefined,
          replyToText: replyingTo ? (replyingTo.text ? replyingTo.text : (replyingTo.image_url ? '📸 صورة' : replyingTo.audio_url ? '🎙️ بصمة صوتية' : replyingTo.video_url ? '🎥 مقطع فيديو' : 'مرفق')) : undefined
        }),
        signal: controller.signal
      });

      const data = await res.json();
      if (!res.ok) {
        alert(data.error || 'فشل إرسال الرسالة.');
      } else {
        setText('');
        setImageFile(null);
        setAudioBlobBase64(null);
        setVideoFile(null);
        setReplyingTo(null);
        setMessages(prev => [...prev, data]);
        setTimeout(() => {
          messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
        }, 100);
      }
    } catch (err: any) {
      if (err.name === 'AbortError') {
        console.log('تم إلغاء رفع الملف والرسالة بنجاح.');
      } else {
        alert('فشل الاتصال بخادم الدردشة أو تجاوز الحد المسموح به لحجم الملف.');
      }
    } finally {
      setSending(false);
      abortControllerRef.current = null;
    }
  };

  const cancelSendingMessage = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      setSending(false);
      alert('🚫 تم إلغاء عملية رفع وإرسال الملف بنجاح.');
    }
  };

  const handleDeleteMessage = async (msgId: string) => {
    const finalUserId = isDev ? 'developer_main' : (student?.id || 'guest');
    try {
      const res = await fetch(`/api/community/messages/${msgId}?userId=${finalUserId}`, {
        method: 'DELETE'
      });
      const data = await res.json();
      if (res.ok) {
        setMessages(prev => prev.filter(m => m.id !== msgId));
      } else {
        alert(data.error || 'فشل حذف الرسالة.');
      }
    } catch (e) {
      alert('فشل الاتصال بالخادم لحذف الرسالة.');
    }
  };

  const scrollToAndHighlightMessage = (targetMsgId: string) => {
    const element = document.getElementById(`msg-${targetMsgId}`);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'center' });
      // Apply beautiful highlighting ring and scaling animation feedback
      element.classList.add('ring-4', 'ring-amber-500', 'ring-offset-2', 'scale-[1.02]', 'z-50', 'transition-all', 'duration-300');
      setTimeout(() => {
        element.classList.remove('ring-4', 'ring-amber-500', 'ring-offset-2', 'scale-[1.02]', 'z-50');
      }, 2000);
    } else {
      alert('⚠️ عذراً! هذه الرسالة الأصلية التي تم الرد عليها غير موجودة في الشاشة الحالية أو تم حذفها.');
    }
  };

  const handleDeleteGroup = async (e: React.MouseEvent, grpId: string) => {
    e.stopPropagation();

    const finalUserId = isDev ? 'developer_main' : (student?.id || 'guest');
    try {
      const res = await fetch(`/api/community/groups/${grpId}?userId=${finalUserId}`, {
        method: 'DELETE'
      });
      const data = await res.json();
      if (res.ok) {
        if (activeGroupId === grpId) {
          setActiveGroupId('general');
        }
        fetchGroups();
      } else {
        alert(data.error || 'فشل حذف المجموعة.');
      }
    } catch (err) {
      alert('حدث خطأ أثناء محاولة الاتصال بالخادم لحذف المجموعة.');
    }
  };

  // Group settings editor actions (moderator / creator only)
  const activeGroup = groups.find(g => g.id === activeGroupId);
  const isGroupOwner = activeGroup && (activeGroup.creator_id === student?.id || isDev);

  const toggleGroupFreeze = async () => {
    if (!activeGroup) return;
    try {
      const res = await fetch(`/api/community/groups/${activeGroup.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          editorId: student?.id || 'guest',
          isFrozen: !activeGroup.is_frozen
        })
      });
      if (res.ok) {
        fetchGroups();
      }
    } catch (e) {
      console.error(e);
    }
  };

  const toggleGroupImages = async () => {
    if (!activeGroup) return;
    try {
      const res = await fetch(`/api/community/groups/${activeGroup.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          editorId: student?.id || 'guest',
          allowImages: !activeGroup.allow_images
        })
      });
      if (res.ok) {
        fetchGroups();
      }
    } catch (e) {
      console.error(e);
    }
  };

  const toggleGroupAudio = async () => {
    if (!activeGroup) return;
    try {
      const res = await fetch(`/api/community/groups/${activeGroup.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          editorId: student?.id || 'guest',
          allowAudio: !activeGroup.allow_audio
        })
      });
      if (res.ok) {
        fetchGroups();
      }
    } catch (e) {
      console.error(e);
    }
  };

  const toggleGroupVideos = async () => {
    if (!activeGroup) return;
    try {
      const res = await fetch(`/api/community/groups/${activeGroup.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          editorId: student?.id || 'guest',
          allowVideos: activeGroup.allow_videos === false
        })
      });
      if (res.ok) {
        fetchGroups();
      }
    } catch (e) {
      console.error(e);
    }
  };

  const formatDuration = (sec: number) => {
    const mins = Math.floor(sec / 60);
    const secs = sec % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-6 text-right" dir="rtl">
      
      {/* Right Column: Groups / Rooms List */}
      <div className="md:col-span-1 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-3xl p-5 shadow-sm space-y-4 flex flex-col h-[650px] overflow-hidden">
        <div className="space-y-1">
          <h2 className="text-sm font-black text-slate-850 dark:text-slate-100 flex items-center gap-1.5">
            <Users className="w-4 h-4 text-amber-500" />
            <span>مجتمع الدردشة والغرف</span>
          </h2>
          <p className="text-[10px] text-slate-400">تحدث وشارك الآراء مع زملائك بالمنصة:</p>
        </div>

        {isDev && (
          <button
            onClick={() => setShowCreateModal(true)}
            className="w-full py-2.5 bg-gradient-to-l from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white rounded-xl text-xs font-black transition flex items-center justify-center gap-1.5 shadow-sm cursor-pointer"
          >
            <span>➕ إنشاء مجموعة مخصصة</span>
          </button>
        )}

        <div className="flex-1 overflow-y-auto space-y-2 pr-1 custom-scroll">
          {/* Default General Room */}
          <button
            onClick={() => setActiveGroupId('general')}
            className={`w-full p-3 rounded-2xl border text-right transition flex items-center justify-between group ${
              activeGroupId === 'general'
                ? 'bg-amber-50 dark:bg-amber-950/20 border-amber-300 dark:border-amber-800'
                : 'bg-slate-50/50 dark:bg-slate-950/40 hover:bg-slate-100 border-slate-50 dark:border-slate-850'
            }`}
          >
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-amber-500 rounded-xl flex items-center justify-center text-white text-xs font-black shadow-sm">
                عام
              </div>
              <div>
                <h4 className="text-xs font-black text-slate-800 dark:text-slate-250">الغرفة العامة للمجتمع</h4>
                <p className="text-[9px] text-slate-400">مفتوحة لكافة المشتركين</p>
              </div>
            </div>
            {activeGroupId === 'general' && (
              <span className="w-2 h-2 bg-amber-500 rounded-full animate-ping" />
            )}
          </button>

          {/* User Created Groups */}
          {groups.map((grp) => (
            <button
              key={grp.id}
              onClick={() => setActiveGroupId(grp.id)}
              className={`w-full p-3 rounded-2xl border text-right transition flex items-center justify-between group ${
                activeGroupId === grp.id
                  ? 'bg-amber-50 dark:bg-amber-950/20 border-amber-300 dark:border-amber-800'
                  : 'bg-slate-50/50 dark:bg-slate-950/40 hover:bg-slate-100 border-slate-50 dark:border-slate-850'
              }`}
            >
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-slate-200 dark:bg-slate-800 rounded-xl flex items-center justify-center text-slate-700 dark:text-slate-300 text-xs font-black">
                  {grp.name.charAt(0)}
                </div>
                <div>
                  <h4 className="text-xs font-black text-slate-800 dark:text-slate-250 truncate max-w-[110px]">{grp.name}</h4>
                  <p className="text-[9px] text-slate-400 truncate max-w-[110px]">بواسطة: {grp.creator_name}</p>
                </div>
              </div>
              <div className="flex items-center gap-1.5">
                {grp.is_frozen && <Lock className="w-3.5 h-3.5 text-rose-500 shrink-0" />}
                {isDev && (
                  <span
                    onClick={(e) => handleDeleteGroup(e, grp.id)}
                    className="p-1 text-slate-400 hover:text-rose-500 hover:bg-rose-550/10 rounded-lg transition-all cursor-pointer select-none"
                    title="حذف هذه المجموعة"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </span>
                )}
                {activeGroupId === grp.id && (
                  <span className="w-2 h-2 bg-amber-500 rounded-full animate-pulse shrink-0" />
                )}
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Left Column: Chat Area */}
      <div className="md:col-span-3 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-3xl p-5 shadow-sm flex flex-col h-[650px] overflow-hidden relative">
        
        {/* Chat Active Thread Header */}
        <div className="pb-3 border-b border-slate-100 dark:border-slate-850 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 bg-amber-100 dark:bg-amber-950/40 text-amber-600 dark:text-amber-400 rounded-xl flex items-center justify-center">
              <MessageSquare className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-black text-slate-800 dark:text-white">
                {activeGroupId === 'general' ? 'الغرفة العامة للمجتمع' : activeGroup?.name}
              </h3>
              <p className="text-[10px] text-slate-400">
                {activeGroupId === 'general' 
                  ? 'مساحة علمية لتبادل النقاش والتناصح بين كافة الطلاب والمطورين' 
                  : `مجموعة إشرافية خاصة. المشرف العام: ${activeGroup?.creator_name}`
                }
              </p>
            </div>
          </div>

          {/* Inline Moderator / Creator Controls */}
          {activeGroupId !== 'general' && isGroupOwner && activeGroup && (
            <div className="flex items-center gap-2 bg-slate-50 dark:bg-slate-950 px-2.5 py-1.5 rounded-xl border border-slate-100 dark:border-slate-800/60">
              <span className="text-[9px] font-black text-amber-500 ml-1 flex items-center gap-0.5">
                <Settings className="w-3 h-3 animate-spin" />
                <span>إدارتك:</span>
              </span>
              
              {/* Frozen Toggle */}
              <button
                onClick={toggleGroupFreeze}
                title={activeGroup.is_frozen ? 'فك قفل الإيقاف' : 'إيقاف الدردشة مؤقتاً'}
                className={`p-1 rounded cursor-pointer transition ${activeGroup.is_frozen ? 'bg-rose-100 text-rose-500' : 'hover:bg-slate-200 text-slate-400'}`}
              >
                {activeGroup.is_frozen ? <Lock className="w-3.5 h-3.5" /> : <LockOpen className="w-3.5 h-3.5" />}
              </button>

              {/* Allow Images Toggle */}
              <button
                onClick={toggleGroupImages}
                title={activeGroup.allow_images ? 'منع تداول الصور' : 'السماح بالصور'}
                className={`p-1 rounded cursor-pointer transition ${activeGroup.allow_images ? 'hover:bg-slate-200 text-emerald-500' : 'bg-slate-100 text-slate-400'}`}
              >
                <Image className="w-3.5 h-3.5" />
              </button>

              {/* Allow Audio Toggle */}
              <button
                onClick={toggleGroupAudio}
                title={activeGroup.allow_audio ? 'منع البصمات الصوتية' : 'السماح بالبصمة الصوتية'}
                className={`p-1 rounded cursor-pointer transition ${activeGroup.allow_audio ? 'hover:bg-slate-200 text-blue-500' : 'bg-slate-100 text-slate-400'}`}
              >
                <Volume2 className="w-3.5 h-3.5" />
              </button>

              {/* Allow Videos Toggle */}
              <button
                onClick={toggleGroupVideos}
                title={activeGroup.allow_videos !== false ? 'منع مقاطع الفيديو' : 'السماح بمقاطع الفيديو'}
                className={`p-1 rounded cursor-pointer transition ${activeGroup.allow_videos !== false ? 'hover:bg-slate-200 text-purple-500' : 'bg-slate-100 text-slate-400'}`}
              >
                <Video className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
        </div>

        {/* Message Log Thread */}
        <div className="flex-1 overflow-y-auto py-4 space-y-3 pr-1 custom-scroll">
          {messages.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-2">
              <div className="w-12 h-12 bg-slate-50 dark:bg-slate-950 text-slate-350 dark:text-slate-600 rounded-full flex items-center justify-center border border-slate-100 dark:border-slate-800">
                💬
              </div>
              <h4 className="text-xs font-black text-slate-500">لا توجد رسائل سابقة هنا</h4>
              <p className="text-[10px] text-slate-450">كن أول من يفتتح النقاش ويرسل رسالة ترحيبية للطلاب زملائك!</p>
            </div>
          ) : (
            messages.map((msg) => {
              const isOwnMessage = msg.sender_id === student?.id;
              const isMsgSenderDev = msg.sender_id === 'developer_main' || msg.sender_name === 'Developer060@gmail.com';
              
              return (
                <div
                  key={msg.id}
                  id={`msg-${msg.id}`}
                  className={`flex ${isOwnMessage ? 'justify-start' : 'justify-end'} gap-2 max-w-[85%] ${
                    isOwnMessage ? 'mr-0 ml-auto flex-row-reverse' : 'ml-0 mr-auto flex-row'
                  }`}
                >
                  {/* Sender Avatar */}
                  <div className={`w-8 h-8 rounded-full shrink-0 flex items-center justify-center font-bold text-xs shadow-sm ${
                    isMsgSenderDev 
                      ? 'bg-rose-500 text-white'
                      : isOwnMessage 
                        ? 'bg-amber-500 text-white' 
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-705 dark:text-slate-300'
                  }`}>
                    {isMsgSenderDev ? '👑' : msg.sender_name.charAt(0)}
                  </div>

                  <div className="space-y-1 text-right">
                    {/* Username & date header */}
                    <div className="flex items-center gap-1.5 justify-start flex-row-reverse">
                      <span className="text-[9px] text-slate-400">
                        {new Date(msg.created_at).toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' })}
                      </span>
                      {(isOwnMessage || isDev) && (
                        <button
                          type="button"
                          onClick={() => handleDeleteMessage(msg.id)}
                          className="mr-1 text-slate-400 hover:text-rose-500 rounded transition cursor-pointer select-none"
                          title="حذف هذه الرسالة"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      )}
                      
                      <button
                        type="button"
                        onClick={() => {
                          setReplyingTo(msg);
                          // Scroll to active reply box
                          document.getElementById('chat-composer-form')?.scrollIntoView({ behavior: 'smooth' });
                        }}
                        className="mr-1 text-slate-400 hover:text-amber-500 rounded transition cursor-pointer select-none"
                        title="التعليق والرد على هذه الرسالة"
                      >
                        <CornerUpLeft className="w-3 h-3" />
                      </button>

                      <span className={`text-[10px] font-black ${
                        isMsgSenderDev 
                          ? 'text-rose-500 flex items-center gap-0.5'
                          : 'text-slate-700 dark:text-slate-300'
                      }`}>
                        {isMsgSenderDev ? (db?.ui_settings?.find(s => s.key === 'dev_display_name')?.value || 'المطور الرئيسي') : msg.sender_name}
                        {isMsgSenderDev && <span className="bg-rose-100 text-rose-600 text-[8px] font-black px-1.5 py-0.5 rounded-full">المطور</span>}
                      </span>
                    </div>

                    {/* Chat Bubble Body */}
                    <div className={`p-3 rounded-2xl text-xs leading-relaxed space-y-2 relative shadow-xs ${
                      isMsgSenderDev
                        ? 'bg-gradient-to-l from-rose-500/10 to-transparent border border-rose-500/20 text-slate-800 dark:text-slate-200'
                        : isOwnMessage
                          ? 'bg-amber-500 text-white rounded-tr-none'
                          : 'bg-slate-50 dark:bg-slate-850 text-slate-800 dark:text-slate-200 rounded-tl-none'
                    }`}>
                      {msg.reply_to_id && (
                        <div 
                          onClick={() => scrollToAndHighlightMessage(msg.reply_to_id!)}
                          className={`p-2 mb-2 rounded-lg border-r-2 text-[10px] text-right flex flex-col gap-0.5 cursor-pointer hover:bg-opacity-80 active:scale-95 transition-all duration-150 ${
                            isOwnMessage 
                              ? 'bg-black/15 border-white/60 text-slate-100' 
                              : 'bg-amber-500/10 border-amber-500 text-amber-900 dark:text-amber-200 bg-slate-100/90 dark:bg-slate-800/90'
                          }`}
                          title="انقر للانتقال للرسالة الأصلية وتظليلها"
                        >
                          <span className="font-bold flex items-center gap-1 justify-end">
                            <span>↩️ رداً على {msg.reply_to_name}</span>
                            <span className="text-[8px] font-medium bg-amber-500/20 px-1 py-0.5 rounded shrink-0 text-amber-900">اضغط للعرض</span>
                          </span>
                          <span className="line-clamp-1 opacity-90">{msg.reply_to_text}</span>
                        </div>
                      )}

                      {msg.text && <p className="whitespace-pre-wrap">{msg.text}</p>}
                      
                      {msg.image_url && (
                        <div className="relative group rounded-xl overflow-hidden shadow-xs max-w-[240px] border border-black/5 bg-slate-100">
                          <img 
                            src={msg.image_url} 
                            alt="community attached file" 
                            className="w-full max-h-[200px] object-cover cursor-zoom-in hover:scale-102 hover:brightness-95 transition-all duration-200" 
                            onClick={() => setActiveMediaLightbox({ type: 'image', url: msg.image_url })}
                          />
                          <button
                            type="button"
                            onClick={() => setActiveMediaLightbox({ type: 'image', url: msg.image_url })}
                            className="absolute top-1.5 left-1.5 p-1 px-2 text-[9px] bg-black/60 hover:bg-black/85 text-white font-black rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-150 flex items-center gap-1 cursor-pointer"
                          >
                            <span>🔍 تكبير</span>
                          </button>
                        </div>
                      )}

                      {msg.video_url && (
                        <div className="relative group rounded-xl overflow-hidden shadow-xs max-w-[240px] border border-black/5 bg-slate-105">
                          <video 
                            src={msg.video_url} 
                            controls 
                            className="w-full max-h-[200px]" 
                          />
                          <button
                            type="button"
                            onClick={() => setActiveMediaLightbox({ type: 'video', url: msg.video_url })}
                            className="absolute top-1.5 left-1.5 p-1 px-1.5 text-[9px] bg-black/60 hover:bg-black/85 text-white font-black rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-150 flex items-center gap-1 cursor-pointer z-10"
                          >
                            <span>📺 ملء الشاشة</span>
                          </button>
                        </div>
                      )}

                      {msg.audio_url && (
                        <div className="flex items-center gap-2 bg-black/5 p-2 rounded-xl min-w-[200px]">
                          <audio src={msg.audio_url} controls className="w-full h-8 opacity-80" />
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Floating Warning panel if group is currently frozen */}
        {activeGroup?.is_frozen && (
          <div className="p-3 bg-rose-50 dark:bg-rose-950/20 text-rose-600 dark:text-rose-400 border border-rose-100 dark:border-rose-900 rounded-2xl flex items-center gap-2 mb-2 justify-center">
            <Lock className="w-4 h-4 text-rose-500" />
            <span className="text-[10px] font-black">لقد قام مشرف المجموعة بإيقاف استقبال الرسائل مؤقتاً في هذه الغرفة.</span>
          </div>
        )}

        {/* Message Composer Footer Form */}
        <form id="chat-composer-form" onSubmit={handleSendMessage} className="pt-3 border-t border-slate-100 dark:border-slate-850 space-y-3">
          
          {/* Replying Preview Indicator */}
          {replyingTo && (
            <div className="flex items-center gap-3 bg-indigo-500/10 p-2.5 border border-indigo-500/20 rounded-xl justify-between text-right" dir="rtl">
              <div className="flex flex-col gap-0.5 text-right w-full">
                <span className="text-[10px] text-indigo-650 dark:text-indigo-400 font-extrabold flex items-center gap-1">
                  <span>↩️ رد على رسالة: {replyingTo.sender_name}</span>
                </span>
                <span className="text-[9px] text-slate-500 dark:text-slate-350 line-clamp-1 italic">
                  {replyingTo.text ? replyingTo.text : (replyingTo.image_url ? '📸 صورة مرفقة' : replyingTo.audio_url ? '🎙️ بصمة صوتية' : replyingTo.video_url ? '🎥 مقطع فيديو' : 'مرفق')}
                </span>
              </div>
              <button
                type="button"
                onClick={() => setReplyingTo(null)}
                className="p-1 px-2 text-[9px] bg-rose-500 hover:bg-rose-600 text-white font-black rounded-lg transition shrink-0 cursor-pointer"
                title="إلغاء الرد"
              >
                إلغاء ✕
              </button>
            </div>
          )}

          {/* File Reading Status */}
          {isReadingFile && (
            <div className="flex items-center gap-2 bg-indigo-500/10 p-2 border border-indigo-500/20 rounded-xl justify-center animate-pulse">
              <span className="text-[10px] text-indigo-500 font-bold flex items-center gap-1.5">
                <span className="w-2 h-2 bg-indigo-500 rounded-full animate-ping" />
                <span>⏳ جاري قراءة وتجهيز الملف... يرجى الانتظار ثوانٍ</span>
              </span>
            </div>
          )}

          {/* Active Attachments Bar Indicators */}
          {(imageFile || audioBlobBase64 || videoFile) && (
            <div className="flex flex-col gap-3.5 bg-amber-500/10 p-3.5 border border-amber-500/20 rounded-xl">
              <div className="flex items-center gap-3 justify-between">
                <span className="text-[10px] text-amber-500 font-bold flex items-center gap-1">
                  <BadgeInfo className="w-4 h-4 ml-1" />
                  {imageFile ? '📸 تم إرفاق صورة جاهزة للرفع والمشاركة' : videoFile ? '🎥 تم إرفاق مقطع فيديو جاهز للمعاينة والرفع' : '🎙️ تم تسجيل بصمة صوتية جاهزة للإرسال'}
                </span>
                <button
                  type="button"
                  onClick={() => {
                    setImageFile(null);
                    setAudioBlobBase64(null);
                    setVideoFile(null);
                  }}
                  className="px-2.5 py-1 bg-rose-500 hover:bg-rose-600 active:bg-rose-700 text-white rounded-lg text-[9px] font-black cursor-pointer transition select-none"
                >
                  مسح المرفق ✕
                </button>
              </div>

              {/* Interactive media player / preview space to watch fully inside the program */}
              <div className="flex justify-center p-2 bg-white/40 dark:bg-black/30 rounded-xl border border-dashed border-amber-500/20 max-h-[180px] overflow-auto">
                {imageFile && (
                  <img src={imageFile} className="max-h-[150px] rounded-lg object-contain shadow-xs border border-amber-500/10" alt="صورة مرفقة للمعاينة" />
                )}
                {videoFile && (
                  <div className="w-full max-w-[340px] flex flex-col items-center gap-1.5 p-1">
                    <video src={videoFile} controls className="max-h-[130px] rounded-lg bg-black shadow-md border border-black/10" />
                    <span className="text-[9px] text-slate-500 dark:text-slate-400 font-black text-center">📺 يمكنك تشغيل واستعراض الفيديو بالكامل الآن لتأكيد المحتوى قبل الإرسال</span>
                  </div>
                )}
                {audioBlobBase64 && (
                  <div className="flex flex-col items-center gap-3 w-full max-w-sm">
                    <audio src={audioBlobBase64} controls className="w-full h-9 rounded-lg" />
                    <div className="flex items-center gap-2 w-full justify-center">
                      <button
                        type="button"
                        onClick={() => handleSendMessage()}
                        disabled={sending}
                        className="flex-1 py-2 px-3 bg-emerald-500 hover:bg-emerald-600 disabled:bg-slate-300 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 shadow-xs cursor-pointer select-none"
                      >
                        <Send className="w-3.5 h-3.5 transform rotate-180" />
                        <span>إرسال البصمة الصوتية الآن</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => setAudioBlobBase64(null)}
                        className="py-2 px-3 bg-rose-550 hover:bg-rose-600 active:bg-rose-700 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-1 shadow-xs cursor-pointer select-none"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>إلغاء وحذف</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Composer Main Inputs */}
          <div className="flex items-center gap-2">
            
            {/* Image Upload Input */}
            {activeGroup?.allow_images !== false || isGroupOwner ? (
              <label className="w-10 h-10 bg-slate-105 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-750 text-slate-500 hover:text-slate-700 dark:text-slate-350 rounded-xl flex items-center justify-center cursor-pointer transition shrink-0 relative">
                <Image className="w-4 h-4" />
                <input 
                  type="file" 
                  accept="image/*" 
                  className="hidden" 
                  onChange={handleImageChange}
                />
              </label>
            ) : null}

            {/* Video Upload Input */}
            {activeGroup?.allow_videos !== false || isGroupOwner ? (
              <label className="w-10 h-10 bg-slate-105 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-750 text-slate-500 hover:text-slate-700 dark:text-slate-350 rounded-xl flex items-center justify-center cursor-pointer transition shrink-0 relative">
                <Video className="w-4 h-4" />
                <input 
                  type="file" 
                  accept="video/*" 
                  className="hidden" 
                  onChange={handleVideoChange}
                />
              </label>
            ) : null}

            {/* Audio Recording Toggle */}
            {activeGroup?.allow_audio !== false || isGroupOwner ? (
              <div className="shrink-0 flex items-center gap-1.5">
                {recording ? (
                  <div className="flex items-center gap-1 bg-rose-500 text-white px-3 h-10 rounded-xl text-xs font-black animate-pulse">
                    <Square className="w-3.5 h-3.5 mr-1 cursor-pointer fill-current" onClick={stopRecording} />
                    <span>جاري التسجيل ({formatDuration(recordingDuration)})</span>
                    <button type="button" onClick={cancelRecording} className="mr-2 pr-1.5 border-r border-white/20 text-[9px] hover:underline">
                      إلغاء
                    </button>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={startRecording}
                    className="w-10 h-10 bg-slate-105 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-750 text-slate-500 hover:text-slate-700 dark:text-slate-350 rounded-xl flex items-center justify-center transition cursor-pointer"
                  >
                    <Mic className="w-4 h-4" />
                  </button>
                )}
              </div>
            ) : null}

            {/* Main Text Input */}
            <input
              type="text"
              value={text}
              onChange={(e) => setText(e.target.value)}
              disabled={activeGroup?.is_frozen && !isGroupOwner}
              placeholder={
                activeGroup?.is_frozen && !isGroupOwner
                  ? "الدردشة موقوفة مؤقتاً بالقرار الإداري للمجموعة..."
                  : "اكتب رسالتك للمجتمع الدراسي هنا..."
              }
              className="flex-1 bg-slate-100 hover:bg-slate-105 dark:bg-slate-850 dark:hover:bg-slate-850/80 p-3 h-10 rounded-xl text-xs outline-none focus:ring-1 focus:ring-amber-500 border border-transparent transition text-right"
            />

            {/* Submit Send Button */}
            <button
              type="submit"
              disabled={sending || (activeGroup?.is_frozen && !isGroupOwner)}
              className="w-10 h-10 bg-amber-500 hover:bg-amber-600 disabled:bg-slate-300 text-white rounded-xl flex items-center justify-center cursor-pointer transition shadow-sm shrink-0"
            >
              <Send className="w-4 h-4 transform rotate-180" />
            </button>
          </div>
        </form>
      </div>

      {/* MODAL: Create New Chat Group */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 transition-all" dir="rtl">
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="w-full max-w-md bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-3xl p-6 shadow-2xl text-right space-y-4"
          >
            <div className="space-y-1">
              <h3 className="text-sm font-black text-slate-800 dark:text-white">➕ إنشاء مجموعة دردشة جديدة</h3>
              <p className="text-[10px] text-slate-450">قم ببناء مجتمعات دراسية مصغرة حيث تكون أنت المدير والمشرف المطلق!</p>
            </div>

            {modalError && (
              <div className="p-3 bg-rose-50 text-rose-500 border border-rose-100 rounded-xl text-xs font-black">
                {modalError}
              </div>
            )}

            <form onSubmit={handleCreateGroup} className="space-y-4">
              <div className="space-y-1 text-right">
                <label className="text-[10px] font-black text-slate-500">اسم مجموعة الدردشة:</label>
                <input
                  type="text"
                  required
                  value={newGroupName}
                  onChange={(e) => setNewGroupName(e.target.value)}
                  placeholder="مثال: مجموعة حل أسئلة الفيزياء"
                  className="w-full p-2.5 bg-slate-50 border border-slate-100 dark:bg-slate-950 dark:border-slate-800 rounded-xl text-xs outline-none focus:ring-1 focus:ring-amber-500 text-right"
                />
              </div>

              {/* Toggle Privileges */}
              <div className="space-y-3">
                <div className="flex items-center justify-between bg-slate-50 dark:bg-slate-950 p-2.5 border border-slate-100 dark:border-slate-800 rounded-xl">
                  <span className="text-[10px] font-black text-slate-650 dark:text-slate-350">السماح بتداول الصور للطلاب:</span>
                  <input
                    type="checkbox"
                    checked={allowImages}
                    onChange={(e) => setAllowImages(e.target.checked)}
                    className="w-4 h-4 rounded cursor-pointer accent-amber-500"
                  />
                </div>

                <div className="flex items-center justify-between bg-slate-50 dark:bg-slate-950 p-2.5 border border-slate-100 dark:border-slate-800 rounded-xl">
                  <span className="text-[10px] font-black text-slate-650 dark:text-slate-350">السماح بالبصمات الصوتية للطلاب:</span>
                  <input
                    type="checkbox"
                    checked={allowAudio}
                    onChange={(e) => setAllowAudio(e.target.checked)}
                    className="w-4 h-4 rounded cursor-pointer accent-amber-500"
                  />
                </div>

                <div className="flex items-center justify-between bg-slate-50 dark:bg-slate-950 p-2.5 border border-slate-100 dark:border-slate-800 rounded-xl">
                  <span className="text-[10px] font-black text-slate-650 dark:text-slate-350">السماح بمقاطع الفيديو للطلاب:</span>
                  <input
                    type="checkbox"
                    checked={allowVideos}
                    onChange={(e) => setAllowVideos(e.target.checked)}
                    className="w-4 h-4 rounded cursor-pointer accent-amber-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 pt-2">
                <button
                  type="submit"
                  disabled={sending}
                  className="py-2.5 bg-amber-500 hover:bg-amber-600 text-white rounded-xl text-xs font-black cursor-pointer shadow"
                >
                  {sending ? 'جاري الحل...' : 'متابعة وإنشاء المجموعة'}
                </button>
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-600 dark:bg-slate-800 dark:text-slate-200 rounded-xl text-xs font-black cursor-pointer"
                >
                  إلغاء
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}

      {/* Lightbox Inline Media Viewer Modal */}
      <AnimatePresence>
        {activeMediaLightbox && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/95 backdrop-blur-md z-[9999] flex items-center justify-center p-4 select-none"
            onClick={() => setActiveMediaLightbox(null)}
          >
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              transition={{ type: 'spring', damping: 25, stiffness: 350 }}
              className="relative max-w-4xl w-full max-h-[85vh] flex flex-col items-center justify-center p-1"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Close Button on top-left */}
              <button 
                onClick={() => setActiveMediaLightbox(null)}
                className="absolute -top-12 left-0 p-2 bg-rose-600 hover:bg-rose-700 text-white rounded-full transition cursor-pointer flex items-center justify-center shadow-lg gap-1 px-3 focus:outline-none"
                title="إغلاق العرض"
                type="button"
              >
                <span className="text-[10px] font-black">✕ إغلاق نافذة العرض</span>
              </button>

              <div className="w-full overflow-hidden rounded-2xl bg-slate-950 flex items-center justify-center border border-white/10 shadow-2xl">
                {activeMediaLightbox.type === 'image' ? (
                  <img 
                    src={activeMediaLightbox.url} 
                    alt="Viewer Mode" 
                    className="max-w-full max-h-[75vh] object-contain rounded-2xl" 
                  />
                ) : (
                  <video 
                    src={activeMediaLightbox.url} 
                    controls 
                    autoPlay
                    className="max-w-full max-h-[75vh] rounded-2xl" 
                  />
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Sending Progress Overlay */}
      <AnimatePresence>
        {sending && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-[99999] flex items-center justify-center p-4 text-center select-none"
            dir="rtl"
            onClick={(e) => e.stopPropagation()}
          >
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-slate-900 border border-slate-150 dark:border-slate-800 rounded-3xl p-6 shadow-2xl max-w-sm w-full space-y-5 flex flex-col items-center"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="relative w-16 h-16 flex items-center justify-center">
                <span className="w-16 h-16 border-4 border-amber-500/25 border-t-amber-500 rounded-full animate-spin absolute" />
                <span className="text-2xl">🚀</span>
              </div>
              
              <div className="space-y-2">
                <h3 className="text-sm font-black text-slate-800 dark:text-white">جاري رفع وإرسال الملف...</h3>
                <p className="text-[10px] text-slate-500 dark:text-slate-400 leading-relaxed px-2">
                  يتم الآن رفع المرفقات والرسالة بأعلى سرعة شبكة متاحة. يرجى الانتظار ثوانٍ دون مغادرة الصفحة لضمان اكتمال عملية الإرسال بنجاح.
                </p>
              </div>

              {/* Cancel Button */}
              <button
                type="button"
                onClick={cancelSendingMessage}
                className="w-full py-2.5 bg-rose-500 hover:bg-rose-600 active:bg-rose-700 font-extrabold text-white text-xs rounded-xl shadow-md cursor-pointer transition select-none flex items-center justify-center gap-1.5"
              >
                <span>✕ إلغاء عملية الرفع</span>
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
