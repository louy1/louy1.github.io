import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../context/AppContext';
import { isDevLoggedIn, getDevToken } from '../lib/devToken';
import { 
  MessageSquare, Send, Shield, RefreshCw, MessageCircle, Clock, 
  Check, Users, Search, User, Sparkles, CheckCheck, Smartphone, HelpCircle,
  Trash2, X
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function ChatPage({ onExit }: { onExit?: () => void }) {
  const { student, privateMessages, students, uiSettings, refreshData } = useApp();
  const [text, setText] = useState('');
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  // Determine if the currently logged-in account is the Developer
  const devEmail = uiSettings['dev_email']?.trim() || 'Developer060@gmail.com';
  const isDev = student?.id === 'developer_main' || student?.display_name === devEmail || isDevLoggedIn();

  // If developer, keep track of which student conversation is currently selected in the sidebar
  const [selectedStudentId, setSelectedStudentId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [mobileView, setMobileView] = useState<'chat' | 'sidebar'>('chat');

  // 1. GATHER ALL CONVERSATIONS FOR THE DEVELOPER
  // Group all private messages in the DB by student_id to show a complete live support inbox
  const studentConversations = React.useMemo(() => {
    if (!isDev) return [];
    const grouped: Record<string, {
      studentId: string;
      studentName: string;
      lastMessageAt: string;
      lastText: string;
      unread: boolean;
      totalMessages: number;
    }> = {};

    // First populate from active student directories to ensure searchability
    students.forEach(s => {
      grouped[s.id] = {
        studentId: s.id,
        studentName: s.display_name,
        lastMessageAt: s.created_at || new Date().toISOString(),
        lastText: 'لا توجد رسائل بينكما حتى الآن.',
        unread: false,
        totalMessages: 0
      };
    });

    // Populate using actual private messages log
    (privateMessages || []).forEach(msg => {
      const sId = msg.student_id;
      if (!grouped[sId]) {
        // Fallback if student was deleted from DB but has chats
        grouped[sId] = {
          studentId: sId,
          studentName: `طالب سابق: (${sId.slice(0, 6)})`,
          lastMessageAt: msg.created_at,
          lastText: msg.text,
          unread: false,
          totalMessages: 0
        };
      }
      
      const current = grouped[sId];
      current.totalMessages += 1;
      if (new Date(msg.created_at).getTime() >= new Date(current.lastMessageAt).getTime()) {
        current.lastMessageAt = msg.created_at;
        current.lastText = msg.text;
        // Mark badge red if the student is the sender of the most recent message
        current.unread = msg.sender === 'student';
      }
    });

    return Object.values(grouped)
      .filter(item => item.studentName.toLowerCase().includes(searchQuery.toLowerCase()))
      // Sort so that the conversation with the newest activity is at the very top
      .sort((a, b) => new Date(b.lastMessageAt).getTime() - new Date(a.lastMessageAt).getTime());
  }, [isDev, privateMessages, students, searchQuery]);

  // Set initial selected student for developer on load
  useEffect(() => {
    if (isDev && !selectedStudentId && studentConversations.length > 0) {
      setSelectedStudentId(studentConversations[0].studentId);
    }
  }, [isDev, studentConversations, selectedStudentId]);

  // 2. CHOOSE CURRENT CONVERSATION TARGET ID
  // For normal students: Always their own student record ID
  // For developer: The actively selected student from the sidebar
  const activeStudentId = isDev ? selectedStudentId : student?.id;
  const activeStudentObj = isDev ? students.find(s => s.id === activeStudentId) : student;

  // Filter messages for current active conversation
  const chatMessages = React.useMemo(() => {
    if (!activeStudentId) return [];
    return (privateMessages || []).filter(m => m.student_id === activeStudentId);
  }, [privateMessages, activeStudentId]);

  // Scroll support chat context
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [chatMessages, activeStudentId]);

  // Poll for messages in real-time (Optimized to 1.2s for extremely fast replies)
  useEffect(() => {
    const handle = setInterval(() => {
      refreshData();
    }, 1200);
    return () => clearInterval(handle);
  }, [refreshData]);

  const handleSendMessage = async (e: React.FormEvent, customPrependText?: string) => {
    if (e) e.preventDefault();
    if (!activeStudentId) return;

    let payloadText = text.trim();
    if (customPrependText) {
      payloadText = customPrependText;
    }

    if (!payloadText) return;

    setLoading(true);
    setText('');

    try {
      const res = await fetch('/api/private-messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          studentId: activeStudentId,
          sender: isDev ? 'developer' : 'student',
          text: payloadText,
          token: isDev ? (getDevToken() || 'awdrgyjilplouyking-devms-token') : undefined
        })
      });

      if (res.ok) {
        await refreshData();
      } else {
        const errorData = await res.json();
        alert(errorData.error || 'عذراً، فشل إرسال وفحص الرسالة.');
      }
    } catch (err) {
      console.error('Failed to dispatch private message', err);
    } finally {
      setLoading(false);
    }
  };

  const handleDeletePrivateMessage = async (msgId: string) => {
    try {
      const roleParam = isDev ? 'developer' : 'student';
      const userIdParam = student?.id || 'guest';
      const res = await fetch(`/api/private-messages/${msgId}?userId=${userIdParam}&role=${roleParam}`, {
        method: 'DELETE'
      });
      if (res.ok) {
        await refreshData();
      } else {
        const data = await res.json();
        alert(data.error || 'فشل حذف الرسالة.');
      }
    } catch (e) {
      alert('خطأ بالاتصال أثناء حذف الرسالة.');
    }
  };

  const manualRefresh = async () => {
    setRefreshing(true);
    try {
      await refreshData();
    } catch (e) {
      console.error(e);
    } finally {
      setRefreshing(false);
    }
  };

  if (!student) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[400px] text-center" dir="rtl">
        <MessageSquare className="w-16 h-16 text-slate-350 dark:text-slate-800 mb-4 animate-bounce" />
        <h3 className="text-lg font-black text-slate-800 dark:text-white">الرجاء تسجيل الدخول أولاً</h3>
        <p className="text-xs text-slate-500 mt-1">يجب أن تكون عضواً مسجلاً لتتمكن من مراسلة المطور الفني.</p>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 bg-slate-50 dark:bg-slate-950 text-right font-bold overflow-hidden flex flex-col p-4 md:p-6 h-screen" dir="rtl">
      
      {/* Dynamic Header Block with Status Tags */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm shrink-0 mb-4">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 bg-gradient-to-tr from-emerald-500 to-emerald-600 rounded-2xl flex items-center justify-center text-white shadow-lg shrink-0">
            <MessageCircle className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-sm md:text-base font-black text-slate-900 dark:text-white">
              {isDev ? 'صندوق المطور: إدارة واستقبال مراسلات الطلاب المباشرة' : 'غرفة المحادثة الخاصة والمباشرة مع المطور والادارة'}
            </h1>
            <p className="text-[10px] md:text-xs text-slate-500 dark:text-slate-400 mt-1">
              {isDev 
                ? 'مرحباً بك مجدداً كمدير ومطور وموجه المناهج! تجيب من هنا على استفسارات الدعم الفني بشكل موحد.' 
                : 'قناة تواصل آمنة وفورية دقيقة بينك وبين مطور المنصة لحل المشاكل التقنية واستفسارات الأكواد.'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <span className="inline-flex items-center gap-1.5 text-[10px] text-emerald-600 dark:text-emerald-400 font-extrabold bg-emerald-500/10 px-3 py-1.5 rounded-xl border border-emerald-500/20 shadow-xs">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span>{isDev ? 'بث الخدمة والمدير نشط' : 'قناة المطور متصلة وآمنة'}</span>
          </span>
          <button
            onClick={manualRefresh}
            disabled={refreshing}
            className="p-2 bg-slate-50 hover:bg-slate-100 dark:bg-slate-950 dark:hover:bg-slate-900 text-slate-500 dark:text-slate-450 border border-slate-100 dark:border-slate-850 rounded-xl transition flex items-center justify-center cursor-pointer text-xs font-semibold"
            title="تحديث الرسائل يدويًا"
          >
            <RefreshCw className={`w-4 h-4 ${refreshing ? 'animate-spin' : ''}`} />
          </button>
          {onExit && (
            <button
              onClick={onExit}
              className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white font-black text-xs rounded-xl flex items-center gap-1.5 cursor-pointer transition shadow-sm"
              title="إغلاق والرجوع للرئيسية"
            >
              <X className="w-4 h-4" />
              <span>الخروج من الدردشة 👋</span>
            </button>
          )}
        </div>
      </div>

      {/* Mobile Segmented Tab Switcher */}
      <div className="lg:hidden flex bg-white dark:bg-slate-900 p-1.5 rounded-2xl border border-slate-100 dark:border-slate-800 mb-3 shrink-0">
        <button
          type="button"
          onClick={() => setMobileView('chat')}
          className={`flex-1 py-3 text-xs font-black rounded-xl text-center transition-all cursor-pointer ${
            mobileView === 'chat'
              ? 'bg-blue-600 text-white shadow-md'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-500/10'
          }`}
        >
          💬 {isDev ? 'المحادثة والردود' : 'صندوق المحادثة'}
        </button>
        <button
          type="button"
          onClick={() => setMobileView('sidebar')}
          className={`flex-1 py-3 text-xs font-black rounded-xl text-center transition-all cursor-pointer ${
            mobileView === 'sidebar'
              ? 'bg-blue-600 text-white shadow-md'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-500/10'
          }`}
        >
          {isDev ? '👥 قائمة محادثات الطلاب' : 'ℹ️ التعليمات والارشادات'}
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-stretch flex-1 min-h-0">
        
        {/* =======================================================
            SIDEBAR VIEW (In Dev mode: Students List. In Stud mode: Information)
            ======================================================= */}
        <div className={`lg:col-span-4 bg-white dark:bg-slate-900 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm p-4 flex flex-col h-full min-h-0 overflow-hidden ${mobileView === 'sidebar' ? 'flex' : 'hidden lg:flex'}`}>
          
          {isDev ? (
            // DEVELOPER MODE: LIVE INBOX OF STUDENTS
            <div className="space-y-4 flex flex-col h-full">
              <div className="border-b pb-3 space-y-1">
                <span className="text-[10px] bg-amber-500 text-white font-black px-2.5 py-0.5 rounded-full block w-max">لوحة مدير الرسائل</span>
                <h3 className="text-sm font-black text-slate-800 dark:text-white">قائمة المحادثات المستلمة ({studentConversations.length})</h3>
              </div>

              {/* Realtime filter input */}
              <div className="relative">
                <Search className="absolute right-3.5 top-3 w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  placeholder="ابحث باسم الطالب الراسل..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pr-10 pl-4 py-2.5 text-xs bg-slate-50 dark:bg-slate-950 text-slate-800 dark:text-white border border-slate-200 dark:border-slate-850 rounded-xl focus:outline-none"
                />
              </div>

              {/* Conversations scroll area */}
              <div className="flex-grow overflow-y-auto space-y-2 pr-1 custom-scroll">
                {studentConversations.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-center text-slate-400 py-12">
                    <span className="text-2xl">📥</span>
                    <span className="text-xs font-bold block mt-2">لا يوجد طلاب متوافقون مع اسم البحث</span>
                  </div>
                ) : (
                  studentConversations.map((item) => {
                    const isSelected = item.studentId === activeStudentId;
                    return (
                      <button
                        key={item.studentId}
                        onClick={() => setSelectedStudentId(item.studentId)}
                        className={`w-full p-3 rounded-2xl text-right transition border flex flex-col gap-1 cursor-pointer relative ${
                          isSelected
                            ? 'bg-amber-500/10 border-amber-500 text-slate-950 dark:text-white'
                            : 'bg-slate-50/50 hover:bg-slate-100/80 dark:bg-slate-950/20 border-slate-105/10 hover:border-slate-200 text-slate-600 dark:text-slate-400'
                        }`}
                      >
                        {/* Red Dot Unread badge indicator */}
                        {item.unread && (
                          <span className="absolute top-3.5 left-3.5 h-2 w-2 rounded-full bg-rose-500 animate-ping" />
                        )}

                        <div className="flex justify-between items-center w-full">
                          <span className="text-xs font-black truncate max-w-[80%]">{item.studentName}</span>
                          <span className="text-[8px] text-slate-400 font-bold font-mono">
                            {new Date(item.lastMessageAt).toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })}
                          </span>
                        </div>

                        <p className="text-[10px] text-slate-400 font-bold truncate max-w-xs">{item.lastText}</p>
                      </button>
                    );
                  })
                )}
              </div>
            </div>
          ) : (
            // REGULAR STUDENT MODE: USEFUL SUPPORT DIRECTORY & FAQ
            <div className="space-y-4 flex flex-col justify-between h-full">
              <div className="space-y-4">
                <div className="flex items-center gap-2 pb-3 border-b border-slate-100 dark:border-slate-850">
                  <Shield className="w-5 h-5 text-amber-500" />
                  <h3 className="text-sm font-black text-slate-900 dark:text-white">ضوابط المحادثة الفنيّة والمطور</h3>
                </div>
                
                <div className="space-y-3.5 text-xs text-slate-600 dark:text-slate-400 leading-relaxed font-bold">
                  <div className="p-3 bg-slate-50 dark:bg-slate-950/80 rounded-2xl border flex gap-2">
                    <Sparkles className="w-4 h-4 shrink-0 text-amber-500" />
                    <p className="text-[10px]"><strong>رؤية شفافة للطرفين:</strong> تم تصميم النظام ليتشارك الطرفان نفس التاريخ الدقيق بلحظته، ولذا لا تضيع رسالة مرسلة أبداً.</p>
                  </div>

                  <div className="p-3 bg-slate-50 dark:bg-slate-950/80 rounded-2xl border flex gap-2">
                    <Smartphone className="w-4 h-4 shrink-0 text-indigo-500 animate-pulse" />
                    <p className="text-[10px]"><strong>حماية أمان الأجهزة:</strong> يمكنك مراسلة المطور هنا لطلب تفويض جهاز تفعيل كود الـ QR الإضافي الخاص بك.</p>
                  </div>
                </div>

                <ul className="space-y-2 text-[11px] text-slate-400 font-semibold list-disc list-inside mr-2">
                  <li>المطور يجيب على الرسائل بنفسه بعبارة "أنا هو المطور".</li>
                  <li>تجنب إثارة الفوضى أو الإساءة فالمطور يملك حظر دائم.</li>
                </ul>
              </div>

              <div className="bg-slate-50 dark:bg-slate-950 p-4 rounded-2xl border border-slate-100 dark:border-slate-850 text-center space-y-1">
                <div className="text-[10px] text-slate-400 font-bold">المعرّف المسجل لطالب الأكاديمية</div>
                <div className="text-xs font-mono font-black text-blue-600 dark:text-blue-400 break-all select-all">{student.id}</div>
              </div>
            </div>
          )}

        </div>

        {/* =======================================================
            CHAT CONTENT WINDOW PANEL (Unified Messages Stream)
            ======================================================= */}
        <div className={`lg:col-span-8 bg-white dark:bg-slate-900 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-2xl overflow-hidden flex flex-col h-full min-h-0 ${mobileView === 'chat' ? 'flex' : 'hidden lg:flex'}`}>
          
          {/* Active Header indicator */}
          <div className="p-4 bg-slate-50 dark:bg-slate-950 border-b border-slate-150 dark:border-slate-850 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-blue-500/10 text-blue-500 flex items-center justify-center font-bold text-xs shrink-0">
                {activeStudentObj ? activeStudentObj.display_name.charAt(0) : '؟'}
              </div>
              <div>
                <h4 className="text-xs font-black text-slate-800 dark:text-white">
                  {isDev 
                    ? `جاري المراسلة مع: ${activeStudentObj ? activeStudentObj.display_name : 'بانتظار الاختيار'}`
                    : 'صندوق تواصل المطور الفني المباشر'}
                </h4>
                <p className="text-[9px] text-slate-450">مستكشف المحادثة مشفّر ومحفوظ بشكل دائم في البوابة</p>
              </div>
            </div>

            <span className="text-[9px] text-slate-400 italic">
              مجموع الرسائل: {chatMessages.length} رسالة
            </span>
          </div>

          {/* Messages Stream Container */}
          <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-slate-50/50 dark:bg-slate-950/40 custom-scroll">
            {chatMessages.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-3 text-slate-400">
                <div className="w-14 h-14 bg-white dark:bg-slate-900 rounded-full flex items-center justify-center text-slate-200 border">
                  <MessageSquare className="w-7 h-7" />
                </div>
                <div>
                  <h5 className="text-xs font-black text-slate-700 dark:text-slate-300">
                    {isDev ? 'اكتب أول رسالة تواصل وترحيب بالطالب الآن!' : 'أهلاً بك الموقر! ارسل استفسارك الأول للمطور'}
                  </h5>
                  <p className="text-[9px] text-slate-400 mt-1 max-w-sm mx-auto">
                    بموجب شروط وتوجيهات الأكاديمية يتم تسجيل جميع المحادثات وحصرها لفرز التداول.
                  </p>
                </div>
              </div>
            ) : (
              chatMessages.map((msg) => {
                // If msg sender is "student", student is the author. If "developer", developer is author.
                const isAuthSelf = isDev ? (msg.sender === 'developer') : (msg.sender === 'student');
                
                return (
                  <div
                    key={msg.id}
                    className={`flex flex-col ${isAuthSelf ? 'items-end' : 'items-start'}`}
                  >
                    <div className="flex items-center gap-1.5 text-[9px] text-slate-400 dark:text-slate-500 mb-1 font-bold px-1.5">
                      <span>
                        {msg.sender === 'developer' ? 'المطور (أنا المطور)' : 'الطالب الراسل'}
                      </span>
                      <span>•</span>
                      <Clock className="w-2.5 h-2.5" />
                      <span>{new Date(msg.created_at).toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })}</span>
                    </div>

                    <div className={`px-4 py-2.5 rounded-2xl max-w-[85%] text-xs font-bold leading-relaxed shadow-xs ${
                      isAuthSelf
                        ? 'bg-[#16a34a] text-white rounded-br-none text-right'
                        : 'bg-[#000000] text-white rounded-bl-none text-right border border-slate-800'
                    }`}>
                      {msg.text}
                    </div>

                    <div className="flex items-center gap-1.5 mt-1 px-1.5">
                      {isAuthSelf && (
                        <span className="text-[8px] text-blue-500 flex items-center gap-0.5 font-bold">
                          <CheckCheck className="w-3 h-3" />
                          <span>تم العرض في الطرفين</span>
                        </span>
                      )}
                      {(isAuthSelf || isDev) && (
                        <button
                          type="button"
                          onClick={() => handleDeletePrivateMessage(msg.id)}
                          title="حذف الرسالة للطرفين"
                          className="text-[9px] text-rose-500 hover:text-rose-600 font-bold transition flex items-center gap-0.5 cursor-pointer select-none"
                        >
                          <Trash2 className="w-3 h-3" />
                          <span>حذف الرسالة</span>
                        </button>
                      )}
                    </div>
                  </div>
                );
              })
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Quick Helpers bar for developer to append identity quickly */}
          {isDev && (
            <div className="px-4 py-2 bg-slate-100 dark:bg-slate-950 flex flex-wrap gap-2 items-center text-xs border-t">
              <span className="text-[9px] font-black text-slate-400 block shrink-0">💡 اختصارات المطور المباشرة للرد:</span>
              <button
                type="button"
                onClick={(e) => handleSendMessage(e, 'أنا هو المطور: مرحباً بك يا بطل! يسعدني حل مشكلتك فوراً، ما الذي تحتاجه؟')}
                className="px-2.5 py-1 bg-white hover:bg-slate-50 dark:bg-slate-900 border text-[9px] rounded-lg font-black text-amber-600 cursor-pointer transition shadow-xs"
              >
                أنا المطور: مرحبًا بك!
              </button>
              <button
                type="button"
                onClick={(e) => handleSendMessage(e, 'أنا هو المطور: تم الآن تحديث وفك حظر جهازك بنجاح! يرجى إعادة تحديث الصفحة والرمز.')}
                className="px-2.5 py-1 bg-white hover:bg-slate-50 dark:bg-slate-900 border text-[9px] rounded-lg font-black text-emerald-600 cursor-pointer transition shadow-xs"
              >
                أنا المطور: تم فك ترخيص جهازك!
              </button>
            </div>
          )}

          {/* Input writing Form Composer */}
          {isDev ? (
            <form onSubmit={(e) => handleSendMessage(e)} className="p-4 bg-white dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800 flex gap-3">
              <input
                type="text"
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="اكتب ردك الموجه باسم المطور الشامل للوضوح..."
                disabled={loading || !activeStudentId}
                className="flex-1 px-5 py-3.5 bg-slate-50 dark:bg-slate-950 text-xs text-slate-800 dark:text-slate-100 border border-slate-200 dark:border-slate-800 rounded-2xl focus:outline-none focus:ring-1 focus:ring-blue-500 font-semibold"
              />
              <button
                type="submit"
                disabled={loading || !text.trim() || !activeStudentId}
                className="px-5 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-2xl disabled:opacity-40 shrink-0 transition-all font-black flex items-center justify-center gap-1.5 cursor-pointer shadow hover:shadow-indigo-500/20 text-xs"
              >
                <span>إرسال الرسالة</span>
                <Send className="w-3.5 h-3.5 transform rotate-180" />
              </button>
            </form>
          ) : (
            <div className="p-5 bg-amber-500/5 dark:bg-slate-950/60 border-t border-slate-100 dark:border-slate-800 text-slate-600 dark:text-slate-400 text-xs font-black text-center leading-relaxed">
              💬 قسم المراسلة والدردشة هو للقراءة والتلقي فقط للطلاب. المطور الفني أو المشرف المعتمد هم فقط من يملكون صلاحيات إرسال وتوجيه الرسائل الخاصة من لوحة التحكم الشاملة لتسهيل الدعم!
            </div>
          )}

        </div>

      </div>

    </div>
  );
}
