import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { getDevToken, isDevLoggedIn, setDevToken, removeDevToken } from '../lib/devToken';
import { User, Sun, Moon, Database, ShieldAlert, Sparkles, AlertTriangle, CheckCircle } from 'lucide-react';
import { motion } from 'motion/react';

interface SettingsPageProps {
  onEnterDevMode: () => void;
}

export default function SettingsPage({ onEnterDevMode }: SettingsPageProps) {
  const { student, setTheme, theme, setStudent, resetLocalStudent, uiSettings } = useApp();
  
  const devEmail = uiSettings?.['dev_email']?.trim() || 'Developer060@gmail.com';
  const isDev = student?.id === 'developer_main' || student?.display_name === devEmail || isDevLoggedIn();

  // Student Name state
  const [editedName, setEditedName] = useState(student?.display_name || '');
  const [nameSuccess, setNameSuccess] = useState(false);
  const [nameError, setNameError] = useState('');

  // Dev state password
  const [devPassword, setDevPassword] = useState('');
  const [devSuccess, setDevSuccess] = useState(isDevLoggedIn());
  const [devError, setDevError] = useState('');
  const [devLoading, setDevLoading] = useState(false);

  // Purge modal control
  const [showPurgeConfirm, setShowPurgeConfirm] = useState(false);

  const handleSaveName = async () => {
    if (!editedName.trim()) {
      setNameError('الرجاء كتابة اسم صحيح ليس بفرغات');
      return;
    }
    
    try {
      const response = await fetch('/api/students/onboard', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          name: editedName.trim(),
          schoolPin: 'awdrgyjilp',
          studentPassword: (student as any)?.password || '123456'
        })
      });

      if (response.ok) {
        const data = await response.json();
        setStudent(data.student);
        setNameSuccess(true);
        setNameError('');
        setTimeout(() => setNameSuccess(false), 3000);
      } else {
        setNameError('حدث خطأ بالاتصال بالخادم لحفظ الاسم');
      }
    } catch (e) {
      setNameError('فشلت محاولة الاتصال بالخادم لحفظ الترقية الاسمية');
    }
  };

  const handleDevAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!devPassword.trim()) return;

    setDevLoading(true);
    setDevError('');

    try {
      const response = await fetch('/api/dev-auth', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password: devPassword.trim() })
      });

      if (response.ok) {
        const data = await response.json();
        setDevToken(data.token);
        setDevSuccess(true);
        setDevPassword('');
        // Trigger page refresh or callback immediately
        setTimeout(() => {
          onEnterDevMode();
        }, 1000);
      } else {
        const data = await response.json();
        setDevError(data.error || 'رمز المطور غير معتمد بالخادم.');
      }
    } catch (err) {
      setDevError('فشلت عملية التحقق في الخادم لرمز المرور.');
    } finally {
      setDevLoading(false);
    }
  };

  const handleDevLogout = () => {
    removeDevToken();
    setDevSuccess(false);
  };

  const handleResetData = async () => {
    await resetLocalStudent();
    setShowPurgeConfirm(false);
    window.location.reload();
  };

  return (
    <div className="max-w-3xl mx-auto space-y-8 text-right" dir="rtl">
      
      {/* Page Title */}
      <div>
        <h3 className="text-xl font-black text-slate-800 dark:text-white flex items-center gap-2">
          <Database className="w-5.5 h-5.5 text-blue-600" />
          <span>تخصيص الإعدادات والتحقق</span>
        </h3>
        <p className="text-xs text-slate-400 dark:text-slate-500 mt-1">تعديل حسابك الدراسي، تغيير المظهر، وإدارة الصلاحيات المطبقة:</p>
      </div>

      {/* Grid boxes settings list */}
      <div className="space-y-6">
        
        {/* Box 1: Update Student Name */}
        {student && (
          <div className="p-6 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-3xl shadow-sm space-y-4">
            <h4 className="text-sm font-black text-slate-800 dark:text-white flex items-center gap-2">
              <User className="w-4.5 h-4.5 text-blue-500" />
              <span>ترقية الملف التعريفي للطالب</span>
            </h4>
            <div className="flex flex-col sm:flex-row gap-3">
              <input
                id="edit-name-input"
                type="text"
                value={editedName}
                onChange={(e) => setEditedName(e.target.value)}
                className="flex-grow px-4 py-3 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 text-right"
              />
              <button
                id="btn-save-name"
                onClick={handleSaveName}
                className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl transition cursor-pointer shrink-0 text-sm"
              >
                حفظ اسم الهوية
              </button>
            </div>
            {nameSuccess && (
              <span className="text-xs text-green-500 font-bold flex items-center gap-1.5 justify-end">
                <CheckCircle className="w-4 h-4 text-green-500" />
                <span>تم تعديل هويتك الدراسية بنجاح!</span>
              </span>
            )}
            {nameError && <span className="text-xs text-rose-500 font-bold block">{nameError}</span>}
          </div>
        )}

        {/* Box 2: Styling theme selection */}
        <div className="p-6 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-3xl shadow-sm space-y-4">
          <h4 className="text-sm font-black text-slate-800 dark:text-white flex items-center gap-2">
            <Sun className="w-4.5 h-4.5 text-blue-500" />
            <span>تخصيص مظهر التطبيق</span>
          </h4>
          <p className="text-xs text-slate-400 leading-relaxed">تغيير الأسلوب اللوني لحماية العين وملاءمة ظروف الإضاءة المحيطة:</p>
          <div className="grid grid-cols-2 gap-4">
            <button
              onClick={() => setTheme('light')}
              className={`p-4 border rounded-2xl flex items-center justify-center gap-2.5 font-bold cursor-pointer transition ${
                theme === 'light'
                  ? 'border-blue-600 bg-blue-50/40 text-blue-600 dark:text-blue-400'
                  : 'border-slate-100 dark:border-slate-800 text-slate-500 dark:text-slate-400 hover:bg-slate-50'
              }`}
            >
              <Sun className="w-5 h-5 text-amber-500" />
              <span>الوضع المضيء</span>
            </button>
            <button
              onClick={() => setTheme('dark')}
              className={`p-4 border rounded-2xl flex items-center justify-center gap-2.5 font-bold cursor-pointer transition ${
                theme === 'dark'
                  ? 'border-blue-600 bg-blue-950/20 text-blue-400 font-black'
                  : 'border-slate-100 dark:border-slate-800 text-slate-500 dark:text-slate-400 hover:bg-slate-50'
              }`}
            >
              <Moon className="w-5 h-5 text-indigo-400" />
              <span>الوضع المظلم</span>
            </button>
          </div>
        </div>

        {/* Box 3: Reset current user statistics details */}
        <div className="p-6 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-3xl shadow-sm space-y-4">
          <h4 className="text-sm font-black text-rose-600 flex items-center gap-2">
            <Database className="w-4.5 h-4.5 text-rose-500" />
            <span>إدارة وتصفير البيانات</span>
          </h4>
          <p className="text-xs text-slate-400 leading-relaxed">تنظيف السجلات والبيانات المسجلة، من تقدم علمي وحصاد XP بجميع التحديات الكورسية:</p>
          
          {!showPurgeConfirm ? (
            <button
              id="btn-request-purge"
              onClick={() => setShowPurgeConfirm(true)}
              className="px-5 py-2.5 bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/20 text-rose-600 dark:text-rose-400 border border-rose-100 dark:border-rose-950/40 font-bold rounded-xl text-xs transition cursor-pointer"
            >
              تصفير حسابي وجميع مستوياتي
            </button>
          ) : (
            <div className="p-4 bg-rose-50 dark:bg-rose-950/10 border border-rose-100 dark:border-rose-900/40 rounded-2xl space-y-4 text-right">
              <div className="flex items-start gap-2 text-rose-600 dark:text-rose-400 text-xs font-bold leading-relaxed">
                <AlertTriangle className="w-5 h-5 shrink-0" />
                <span>تحذير: هذا الإجراء غير قابل للتراجع. سيتم حذف جميع تقدمك بجميع المواد والامتحانات فوراً! هل تود الاستمرار بالفعل؟</span>
              </div>
              <div className="flex gap-2 justify-end">
                <button
                  onClick={handleResetData}
                  className="px-4 py-2 bg-rose-600 text-white font-bold rounded-xl text-xs cursor-pointer"
                >
                  نعم، احذف وصفر كل شيء!
                </button>
                <button
                  onClick={() => setShowPurgeConfirm(false)}
                  className="px-4 py-2 bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-bold rounded-xl text-xs cursor-pointer"
                >
                  إلغاء التصفير
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Box 4: Developer pass gateway authentication */}
        {isDev && (
          <div className="p-6 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-3xl shadow-sm space-y-4">
            <h4 className="text-sm font-black text-amber-600 flex items-center gap-2">
              <ShieldAlert className="w-4.5 h-4.5 text-amber-500" />
              <span>بوابة التحقق ومصادقة المطورين</span>
            </h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              الرجاء كتابة كلمة المرور السريّة لكشف لوحة التحكم الشاملة وإضافة المواد والأسئلة التعليمية وتخصيص ثيم الأكاديمية:
            </p>

            {devSuccess ? (
              <div className="p-4 bg-emerald-50 dark:bg-emerald-950/20 border border-emerald-100 dark:border-emerald-950 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="flex items-center gap-2 text-emerald-700 dark:text-emerald-400 text-xs font-bold">
                  <Sparkles className="w-5 h-5 animate-spin text-emerald-500" />
                  <span>أنت مسجل حالياً كمسؤول نظام معتمد (مطور)!</span>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={onEnterDevMode}
                    className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-white font-bold rounded-xl text-xs transition cursor-pointer"
                  >
                    افتح لوحة المطور
                  </button>
                  <button
                    onClick={handleDevLogout}
                    className="px-4 py-2 bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-bold rounded-xl text-xs cursor-pointer"
                  >
                    خروج الصلاحية
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleDevAuth} className="flex flex-col sm:flex-row gap-3">
                <input
                  id="dev-pass-input"
                  type="password"
                  placeholder="ادخل كلمة المرور"
                  value={devPassword}
                  onChange={(e) => setDevPassword(e.target.value)}
                  className="flex-grow px-4 py-3 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 text-right text-sm font-mono"
                />
                <button
                  id="btn-dev-auth-submit"
                  type="submit"
                  disabled={devLoading}
                  className="px-6 py-3 bg-amber-500 hover:bg-amber-600 text-white font-bold rounded-xl transition cursor-pointer shrink-0 text-sm flex items-center justify-center gap-1"
                >
                  {devLoading ? (
                    <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <span>تحقق من الرمز</span>
                  )}
                </button>
              </form>
            )}

            {devError && <span className="text-xs text-rose-500 font-bold block">{devError}</span>}
          </div>
        )}

      </div>

    </div>
  );
}
