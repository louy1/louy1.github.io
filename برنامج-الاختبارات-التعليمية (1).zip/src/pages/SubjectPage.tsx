import { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { Question } from '../types';
import QuestionCard from '../components/QuestionCard';
import AchievementBadge from '../components/AchievementBadge';
import { 
  ArrowRight, Trophy, Sparkles, CheckCircle2, ChevronLeft, 
  Award, Flame, Cpu, Zap, Compass, Heart, Atom, Brain, Crown, Medal, X, Star, FileText, Check,
  MessageSquare, Send
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface SubjectPageProps {
  sectionSlug: string;
  onGoBack: () => void;
}

export default function SubjectPage({ sectionSlug, onGoBack }: SubjectPageProps) {
  const { sections, questions, updateProgress, achievements, studentAchievements, student, studentNotes, addNote } = useApp();
  
  // Find current active section
  const section = sections.find(s => s.slug === sectionSlug);
  
  // Filter questions for this section
  const sectionQuestions = questions.filter(q => q.section_id === (section?.id || ''));

  // Shuffling logic for Quiz Randomization
  const [isRandomized, setIsRandomized] = useState(false);
  const [shuffledQuestions, setShuffledQuestions] = useState<Question[]>([]);

  // Initialize and shuffle when section, randomization setting, or slug changes
  useEffect(() => {
    if (!section) return;
    let qList = [...sectionQuestions];
    if (isRandomized) {
      // Fisher-Yates shuffle
      for (let i = qList.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [qList[i], qList[j]] = [qList[j], qList[i]];
      }
    }
    setShuffledQuestions(qList);
    setCurrentIdx(0);
    setIsCompleted(false);
    setSessionCorrect(0);
    setSessionXpGained(0);
    setNewlyUnlockedBadgeIds([]);
    setFeedbackSent(false);
    setFeedbackText('');
  }, [isRandomized, sectionSlug]);

  // Keep shuffled questions in sync ONLY on first load (e.g. if queries were initially empty)
  // this prevents resetting index 0 during a live quiz on server updates (refreshData)
  useEffect(() => {
    if (shuffledQuestions.length === 0 && sectionQuestions.length > 0) {
      let qList = [...sectionQuestions];
      if (isRandomized) {
        for (let i = qList.length - 1; i > 0; i--) {
          const j = Math.floor(Math.random() * (i + 1));
          [qList[i], qList[j]] = [qList[j], qList[i]];
        }
      }
      setShuffledQuestions(qList);
      setCurrentIdx(0);
    }
  }, [sectionQuestions]);

  const activeQuestions = shuffledQuestions.length > 0 ? shuffledQuestions : sectionQuestions;

  // Progression Indices state
  const [currentIdx, setCurrentIdx] = useState(0);
  const [sessionCorrect, setSessionCorrect] = useState(0);
  const [sessionXpGained, setSessionXpGained] = useState(0);
  const [newlyUnlockedBadgeIds, setNewlyUnlockedBadgeIds] = useState<string[]>([]);
  const [showCelebration, setShowCelebration] = useState(false);
  const [celebrationBadges, setCelebrationBadges] = useState<string[]>([]);
  const [isCompleted, setIsCompleted] = useState(false);

  // Personal exam notes state
  const [noteText, setNoteText] = useState('');
  const [noteSaved, setNoteSaved] = useState(false);
  const [isSavingNote, setIsSavingNote] = useState(false);

  // Send message to developer/supervisor feedback state
  const [feedbackText, setFeedbackText] = useState('');
  const [feedbackSending, setFeedbackSending] = useState(false);
  const [feedbackSent, setFeedbackSent] = useState(false);

  const handleSendFeedback = async () => {
    if (!feedbackText.trim() || !student) return;
    try {
      setFeedbackSending(true);
      const res = await fetch('/api/private-messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          studentId: student.id,
          sender: 'student',
          text: `📝 [ملاحظة/تقييم اختبار ${section.title}]: ${feedbackText.trim()}`
        })
      });
      if (res.ok) {
        setFeedbackSent(true);
        setFeedbackText('');
      } else {
        alert('حدث خطأ أثناء إرسال الملاحظة. يرجى المحاولة لاحقاً.');
      }
    } catch (e) {
      console.error(e);
    } finally {
      setFeedbackSending(false);
    }
  };

  useEffect(() => {
    if (section && student && studentNotes) {
      const existing = studentNotes.find(
        n => n.student_id === student.id && n.section_id === section.id
      );
      if (existing) {
        setNoteText(existing.note_text);
        setNoteSaved(true);
      }
    }
  }, [section, student, studentNotes]);

  const handleSaveNote = async () => {
    if (!noteText.trim() || !section) return;
    try {
      setIsSavingNote(true);
      await addNote(section.id, section.title, noteText.trim());
      setNoteSaved(true);
    } catch (err: any) {
      console.error(err);
    } finally {
      setIsSavingNote(false);
    }
  };

  if (!section) {
    return (
      <div className="p-8 text-center bg-rose-50 dark:bg-rose-950/20 text-rose-600 dark:text-rose-400 rounded-3xl" dir="rtl">
        <span>هذا القسم غير معرّف أو تم مسحه بالآونة الأخيرة.</span>
        <button onClick={onGoBack} className="block mx-auto mt-4 px-4 py-2 bg-rose-600 text-white rounded-xl font-bold">العودة</button>
      </div>
    );
  }

  if (activeQuestions.length === 0) {
    return (
      <div className="p-12 text-center bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-3xl" dir="rtl">
        <Trophy className="w-12 h-12 text-slate-300 mx-auto mb-4" />
        <h3 className="text-lg font-bold text-slate-800 dark:text-white mb-2">لا توجد أسئلة مدرجة في قسم {section.title}</h3>
        <p className="text-xs text-slate-400 mb-6">يرجى الانتظار لحين إضافة المطور أسئلة تفاعلية.</p>
        <button
          onClick={onGoBack}
          className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-xs transition cursor-pointer"
        >
          العودة للرئيسية
        </button>
      </div>
    );
  }

  const handleQuestionAnswer = async (scoreChange: number, isCorrect: boolean) => {
    try {
      // Trigger progress endpoint on Express (returns newly unlocked achievements if any)
      const result = await updateProgress(section.id, scoreChange, isCorrect);
      
      // Update session statistics
      setSessionXpGained(prev => Math.max(0, prev + scoreChange));
      if (isCorrect) {
        setSessionCorrect(prev => prev + 1);
      }

      // Collect achievements
      if (result.newlyUnlockedIds && result.newlyUnlockedIds.length > 0) {
        setNewlyUnlockedBadgeIds(prev => [...prev, ...result.newlyUnlockedIds]);
      }
    } catch (e) {
      console.error('Error applying student progress calculation', e);
    }
  };

  const handleNextStep = () => {
    if (currentIdx === activeQuestions.length - 1) {
      setIsCompleted(true);
      // At the absolute end of the exam, trigger the congratulatory overlay!
      if (newlyUnlockedBadgeIds.length > 0) {
        setCelebrationBadges(newlyUnlockedBadgeIds);
        setShowCelebration(true);
      }
    } else {
      setCurrentIdx(prev => prev + 1);
    }
  };

  const activeQuestion = activeQuestions[currentIdx];

  return (
    <div className="space-y-6" dir="rtl">
      
      {/* Return to Dashboard header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <button
            onClick={onGoBack}
            className="p-2 bg-white dark:bg-slate-900 dark:hover:bg-slate-800 border border-slate-100 dark:border-slate-800 rounded-2xl text-slate-500 hover:text-slate-800 transition cursor-pointer"
            title="العودة للوحة الرئيسية"
          >
            <ArrowRight className="w-5 h-5" />
          </button>
          <div className="text-right">
            <h3 className="text-lg font-black text-slate-800 dark:text-white leading-tight">قسم مادة: {section.title}</h3>
            <p className="text-[10px] text-slate-400 uppercase tracking-widest mt-0.5">جلسة إجابة نشطة</p>
          </div>
        </div>

        {/* Randomizer Option Switch widget */}
        {!isCompleted && (
          <button
            onClick={() => setIsRandomized(prev => !prev)}
            className={`px-4 py-2 rounded-2xl border text-[11px] font-black cursor-pointer transition flex items-center justify-center gap-2 shadow-sm ${
              isRandomized
                ? 'bg-amber-500 text-white border-amber-600'
                : 'bg-white hover:bg-slate-50 dark:bg-slate-950 border-slate-205 text-slate-705 dark:text-slate-300'
            }`}
          >
            <span>🔀 ترتيب الأسئلة: {isRandomized ? 'عشوائي نشط 🔥' : 'متسلسل افتراضي 📋'}</span>
          </button>
        )}
      </div>

      {!isCompleted ? (
        <div className="space-y-6">
          {/* Visual Progression line */}
          <div className="flex justify-between items-center text-xs text-slate-400 font-bold px-1">
            <span>معدل تقدم الأسئلة</span>
            <span className="font-mono">{currentIdx + 1} / {activeQuestions.length}</span>
          </div>

          <div className="w-full h-1.5 bg-slate-100 dark:bg-slate-950 rounded-full overflow-hidden">
            <div
              className="h-full bg-blue-600 rounded-full transition-all duration-300"
              style={{ width: `${((currentIdx + 1) / activeQuestions.length) * 100}%` }}
            />
          </div>

          <QuestionCard
            key={activeQuestion.id}
            question={activeQuestion}
            questionIndex={currentIdx + 1}
            totalQuestions={activeQuestions.length}
            onAnswer={handleQuestionAnswer}
            onNext={handleNextStep}
          />

          {/* Trigger next manually if they resolved current question inside Card */}
          <div className="hidden">
            <button id="trigger-next-step" onClick={handleNextStep}>التالي</button>
          </div>
        </div>
      ) : (
        /* Majestic success final screen */
        <motion.div
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-3xl p-8 text-center max-w-2xl mx-auto space-y-8 shadow-xl"
        >
          <div className="relative inline-block">
            <div className="w-20 h-20 bg-amber-500 rounded-3xl flex items-center justify-center text-white shadow-lg shadow-amber-500/25 mx-auto">
              <Trophy className="w-10 h-10" />
            </div>
            <div className="absolute -top-2 -right-2">
              <Sparkles className="w-6 h-6 text-yellow-500 animate-bounce" />
            </div>
          </div>

          <div className="space-y-2">
            <h2 className="text-2xl font-black text-slate-900 dark:text-white">لقد أكملت اختبار {section.title}!</h2>
            <p className="text-xs text-slate-500 max-w-md mx-auto">
              أهلاً بالبطل! لقد تم رصد أدائك الدراسي ومطابقة مخرجات الإجابة فورياً بالخادم. إليك تفاصيل نتيجتك وحصاد هذه الجولة:
            </p>
          </div>

          {/* Redesigned stat card panel with 4 cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-2xl mx-auto">
            
            {/* 1. Score */}
            <div className="p-4 bg-emerald-50 dark:bg-emerald-950/20 border border-emerald-100 dark:border-emerald-900/40 rounded-2xl text-center">
              <span className="block text-[10px] font-bold text-emerald-600 dark:text-emerald-400 uppercase">النتيجة المحققة</span>
              <span className="text-xl font-black font-mono text-emerald-600 mt-1 block">
                {sessionCorrect} / {activeQuestions.length}
              </span>
            </div>

            {/* 2. Mistakes */}
            <div className="p-4 bg-rose-50 dark:bg-rose-950/20 border border-rose-100 dark:border-rose-900/30 rounded-2xl text-center">
              <span className="block text-[10px] font-bold text-rose-600 dark:text-rose-400 uppercase">عدد الأخطاء</span>
              <span className="text-xl font-black font-mono text-rose-600 mt-1 block">
                {activeQuestions.length - sessionCorrect} س
              </span>
            </div>

            {/* 3. Average Accuracy */}
            <div className="p-4 bg-blue-50 dark:bg-blue-950/20 border border-blue-105 dark:border-blue-900/30 rounded-2xl text-center">
              <span className="block text-[10px] font-bold text-blue-600 dark:text-blue-400 uppercase">معدل الإجابة</span>
              <span className="text-xl font-black font-mono text-blue-600 mt-1 block">
                {activeQuestions.length > 0 ? Math.round((sessionCorrect / activeQuestions.length) * 100) : 0}%
              </span>
            </div>

            {/* 4. Total points gained */}
            <div className="p-4 bg-amber-50 dark:bg-amber-950/20 border border-amber-100 dark:border-amber-900/30 rounded-2xl text-center">
              <span className="block text-[10px] font-bold text-amber-600 dark:text-amber-400 uppercase">النقاط المكتسبة</span>
              <span className="text-xl font-black font-mono text-amber-500 mt-1 block">
                +{sessionXpGained} XP
              </span>
            </div>

          </div>

          {/* Unlocked Achievements list trigger */}
          {newlyUnlockedBadgeIds.length > 0 && (
            <div className="space-y-4 pt-4 border-t border-slate-100 dark:border-slate-800">
              <h4 className="text-xs font-black text-amber-500 uppercase tracking-widest flex items-center justify-center gap-1.5">
                <Sparkles className="w-4 h-4 text-amber-500 animate-spin" />
                <span>إنجازات جديدة تم فتحها!</span>
              </h4>
              <div className="grid grid-cols-1 gap-4 max-w-md mx-auto">
                {newlyUnlockedBadgeIds.map(id => {
                  const ach = achievements.find(a => a.id === id);
                  if (!ach) return null;
                  return (
                    <AchievementBadge
                      key={ach.id}
                      achievement={ach}
                      isUnlocked={true}
                      unlockedAt={new Date().toISOString()}
                    />
                  );
                })}
              </div>
            </div>
          )}

          {/* Bento-grid of Actions: Personal Notes & Send Notes/Feedback to Dev/Supervisor */}
          <div className="pt-8 border-t border-slate-100 dark:border-slate-800 grid grid-cols-1 md:grid-cols-2 gap-6 max-w-3xl mx-auto text-right">
            
            {/* Column 1: Personal Notes */}
            <div className="p-5 bg-slate-50 dark:bg-slate-950 border border-slate-100 dark:border-slate-800 rounded-3xl space-y-3 shadow-xs flex flex-col justify-between">
              <div className="space-y-3">
                <div className="flex items-center gap-2 text-blue-600 dark:text-blue-400">
                  <FileText className="w-5 h-5 shrink-0" />
                  <h4 className="text-sm font-black">حفظ ملاحظة للمذاكرة الشخصية</h4>
                </div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed font-bold">
                  احفظ معلومة هامة أو قانوناً مرّ عليك بالاختبار لتتمكن من مراجعته في ملفك الإنجازي لاحقاً:
                </p>
                <textarea
                  value={noteText}
                  onChange={(e) => {
                    setNoteText(e.target.value);
                    setNoteSaved(false);
                  }}
                  placeholder="مثال: مراجعة قوانين الأسس والتسارع لرموز هذا القسم..."
                  maxLength={500}
                  className="w-full h-24 p-3 bg-white dark:bg-slate-900 border border-slate-205 dark:border-slate-800 rounded-xl text-xs text-slate-800 dark:text-slate-200 placeholder-slate-400 dark:placeholder-slate-600 focus:outline-none focus:ring-1 focus:ring-blue-500 resize-none transition"
                />
              </div>
              <div className="flex justify-between items-center pt-2">
                <span className="text-[10px] text-slate-400 font-mono font-bold">
                  {noteText.length} / 500 حرف
                </span>
                <button
                  onClick={handleSaveNote}
                  disabled={isSavingNote || !noteText.trim()}
                  className={`px-4 py-2 text-[11px] font-bold rounded-lg cursor-pointer transition flex items-center gap-1.5 ${
                    noteSaved 
                      ? 'bg-green-100 dark:bg-green-950/40 text-green-700 dark:text-green-400 border border-green-200 dark:border-green-800/30'
                      : 'bg-blue-600 hover:bg-blue-700 text-white shadow-md shadow-blue-500/10'
                  } disabled:opacity-50`}
                >
                  {isSavingNote ? (
                    <div className="w-3.5 h-3.5 border-2 border-current border-t-transparent rounded-full animate-spin" />
                  ) : noteSaved ? (
                    <Check className="w-3.5 h-3.5" />
                  ) : null}
                  <span>
                    {isSavingNote ? 'جاري الحفظ...' : noteSaved ? 'تم الحفظ بنجاح!' : 'حفظ الملاحظة الشخصية'}
                  </span>
                </button>
              </div>
            </div>

            {/* Column 2: Send Note/Feedback with Real Private message */}
            <div className="p-5 bg-slate-50 dark:bg-slate-950 border border-slate-100 dark:border-slate-800 rounded-3xl space-y-3 shadow-xs flex flex-col justify-between">
              <div className="space-y-3">
                <div className="flex items-center gap-2 text-indigo-600 dark:text-indigo-400 font-black">
                  <MessageSquare className="w-5 h-5 shrink-0 animate-pulse text-indigo-500" />
                  <h4 className="text-sm font-black">إرسال ملاحظة للمشرف أو المطور</h4>
                </div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed font-bold">
                  هل واجهت خطأ علمياً بالاختبار أو لديك اقتراح أو شكوى تقنية؟ أرسلها مباشرة هنا لتصل فورياً للمدير:
                </p>
                {feedbackSent ? (
                  <div className="p-4 bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 dark:text-emerald-400 rounded-xl text-center text-xs font-black flex flex-col items-center gap-2">
                    <CheckCircle2 className="w-8 h-8 text-emerald-500" />
                    <span>تم إرسال ملاحظتك بنجاح ومباشرة للمطور والمشرف! سيتم مراجعة رأيك الفني فوراً.</span>
                  </div>
                ) : (
                  <textarea
                    value={feedbackText}
                    onChange={(e) => setFeedbackText(e.target.value)}
                    placeholder="مثال: هناك خطأ علمي في السؤال الثالث، نرجو مراجعة الإجابة المقترحة..."
                    maxLength={1000}
                    className="w-full h-24 p-3 bg-white dark:bg-slate-900 border border-slate-205 dark:border-slate-800 rounded-xl text-xs text-slate-800 dark:text-slate-200 placeholder-slate-400 dark:placeholder-slate-600 focus:outline-none focus:ring-1 focus:ring-indigo-500 resize-none transition"
                  />
                )}
              </div>
              
              {!feedbackSent && (
                <div className="flex justify-between items-center pt-2">
                  <span className="text-[10px] text-slate-400 font-mono font-bold">
                    {feedbackText.length} / 1000 حرف
                  </span>
                  <button
                    onClick={handleSendFeedback}
                    disabled={feedbackSending || !feedbackText.trim()}
                    className="px-4 py-2 text-[11px] font-bold rounded-lg cursor-pointer transition flex items-center gap-1.5 bg-indigo-600 hover:bg-indigo-700 text-white shadow-md shadow-indigo-500/10 disabled:opacity-50"
                  >
                    {feedbackSending ? (
                      <div className="w-3.5 h-3.5 border-2 border-current border-t-transparent rounded-full animate-spin" />
                    ) : (
                      <Send className="w-3.5 h-3.5 rotate-180" />
                    )}
                    <span>
                      {feedbackSending ? 'جاري الإرسال للمشرف...' : 'إرسال للمطور والمشرف 📬'}
                    </span>
                  </button>
                </div>
              )}
            </div>

          </div>

          <div className="pt-6 border-t border-slate-100 dark:border-slate-800 flex justify-center gap-4">
            <button
              onClick={onGoBack}
              className="px-8 py-3.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-2xl shadow-lg hover:shadow-blue-500/20 cursor-pointer text-sm transition"
            >
              الذهاب للرئيسية
            </button>
          </div>

        </motion.div>
      )}

      {/* Real-time Badge Unlock Celebration Overlay */}
      <AnimatePresence>
        {showCelebration && celebrationBadges.length > 0 && (
          <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 30 }}
              animate={{ scale: 1, opacity: 1, y: 0, transition: { type: 'spring', damping: 15 } }}
              exit={{ scale: 0.9, opacity: 0, y: -30 }}
              className="bg-white dark:bg-slate-900 border-2 border-yellow-400 dark:border-yellow-600/50 rounded-3xl p-8 max-w-sm w-full text-center space-y-6 relative overflow-hidden shadow-2xl"
            >
              <div className="absolute -top-12 -left-12 w-24 h-24 bg-yellow-500/10 rounded-full blur-xl" />
              <div className="absolute -bottom-12 -right-12 w-24 h-24 bg-amber-500/10 rounded-full blur-xl" />

              {/* Sparking confetti indicators */}
              <div className="relative inline-block">
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ repeat: Infinity, duration: 10, ease: 'linear' }}
                  className="w-24 h-24 bg-gradient-to-tr from-amber-500 via-yellow-400 to-amber-600 rounded-full flex items-center justify-center border-4 border-yellow-300 shadow-xl shadow-amber-500/25 mx-auto"
                >
                  {(() => {
                    const firstBadgeId = celebrationBadges[0];
                    const ach = achievements.find(a => a.id === firstBadgeId);
                    if (!ach) return <Award className="w-12 h-12 text-white" />;
                    const iconMap: Record<string, any> = {
                      'Award': Award, 'Trophy': Trophy, 'Flame': Flame, 'Cpu': Cpu,
                      'Zap': Zap, 'Compass': Compass, 'Heart': Heart, 'Atom': Atom,
                      'Brain': Brain, 'Crown': Crown, 'Star': Star, 'Sparkles': Sparkles, 'Medal': Medal
                    };
                    const IconComp = iconMap[ach.icon] || Award;
                    return <IconComp className="w-12 h-12 text-white" />;
                  })()}
                </motion.div>
                <div className="absolute -top-3 -right-3 animate-bounce">
                  <Sparkles className="w-8 h-8 text-yellow-400" />
                </div>
              </div>

              {/* Congratulations message */}
              <div className="space-y-2">
                <h3 className="text-xl font-black text-amber-600 dark:text-yellow-400 animate-pulse">تم فك قفل وسام جديد!</h3>
                <h4 className="text-lg font-black text-slate-800 dark:text-white leading-tight">
                  {(() => {
                    const firstBadgeId = celebrationBadges[0];
                    const ach = achievements.find(a => a.id === firstBadgeId);
                    return ach?.title || 'إنجاز متميز';
                  })()}
                </h4>
                <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                  مبارك يا بطل العبقرية! لقد تم إضافة هذا الإنجاز لملف إنجازاتك الشخصي بالمنصة بنجاح وحصلت على:
                </p>
              </div>

              {/* Reward pill */}
              <div className="p-3 bg-amber-500/15 border border-amber-500/25 rounded-2xl flex items-center justify-center gap-2 max-w-xs mx-auto">
                <Sparkles className="w-4 h-4 text-amber-500 animate-spin" />
                <span className="text-xs font-black text-amber-700 dark:text-amber-400 font-mono">
                  +{(() => {
                    const firstBadgeId = celebrationBadges[0];
                    const ach = achievements.find(a => a.id === firstBadgeId);
                    return ach?.xp_reward || 100;
                  })()} XP مكافأة إضافية
                </span>
              </div>

              {/* Dismiss button */}
              <button
                onClick={() => {
                  if (celebrationBadges.length <= 1) {
                    setShowCelebration(false);
                  } else {
                    setCelebrationBadges(prev => prev.slice(1));
                  }
                }}
                className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white font-black rounded-xl text-xs shadow-md transition cursor-pointer"
              >
                تحديث والمتابعة
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
